## trace 日志
- https://github.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data/tree/main/dino/trace
- https://github.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data/tree/main/dino/attack/trace

## capcom Arcade Core technology analysis project readme

## 卡普空街机核心技术分析工程项目介绍v0.1 2020.12.12
https://gitee.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data/tree/main/dino/attack

### 任务:
-  一、核心打击技术分析：
打击框、打逻辑、被打逻辑、连击逻辑、帧命中、帧取消、外部取消、无敌取消
    - 1、汇编注释 		asm.txt
    - 2、1p内存偏移注释 	addr data.txt
    - 3、c源码注释		c source dir
    - 4、log日志分析  		log dir
    - 5、编写逻辑伪代码

----------------------------------------------------------------------------------------- 
## more data:
https://github.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data
https://gitee.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data
----------------------------------------------------------------------------------------- 
