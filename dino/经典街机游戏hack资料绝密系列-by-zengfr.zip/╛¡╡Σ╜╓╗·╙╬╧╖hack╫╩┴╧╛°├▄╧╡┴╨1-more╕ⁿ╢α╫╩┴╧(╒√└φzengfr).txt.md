---------------------------------------------------------------------------------------
## arcade game hacking经典街机游戏hack资料绝密系列

### hacking基础资料全集
- 卡普空cps1系统资料: https://github.com/zengfr/romhack/tree/master/CPS1
- 拳皇neogeo系统资料: https://github.com/zengfr/romhack/tree/master/neogeo
- 鈊象igs-pgm系统资料: https://github.com/zengfr/romhack/tree/master/igs
- M68000汇编学习资料: https://github.com/zengfr/romhack/tree/master/M68000
- Z80汇编学习资料: https://github.com/zengfr/romhack/tree/master/z80
- Arm汇编学习资料: https://github.com/zengfr/romhack/tree/master/arm
- x64汇编学习资料: https://github.com/zengfr/romhack/tree/master/x64
- 街机绝密数据资料: https://github.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data

### rom & video & demo
- hacking rom下载: https://github.com/zengfr/romhack/tree/master/hackrom
- hacking ips下载: https://github.com/zengfr/romhack/tree/master/ips
- hacking video演示视频: https://space.bilibili.com/492484080

### ida静态逆向分析
- ida 数据库: https://github.com/zengfr/ida-pro-idb-database/tree/main/ida-pro-databases
- winhex插件: https://github.com/zengfr/winhex_diff_viewer-plugin-for-ida-pro
- HexRaysCodeXplorer插件: https://github.com/zengfr/HexRaysCodeXplorer_plugin_for_ida_pro

### hacking开发工具tools 
- https://github.com/zengfr/romhack/tree/master/tool
- https://github.com/zengfr/arcade-romhacking-framework
- https://github.com/zengfr/romhack/tree/master/debuger/debuger-by-zengfr.txt

### more更多开源资料：
- 开源项目1: https://github.com/zengfr/romhack
- 开源项目2: https://github.com/zengfr/arcade_game_romhacking_sourcecode_top_secret_data
- 开源项目3: https://github.com/zengfr/ida-pro-idb-database
- 开源项目4: https://github.com/zengfr/arcade-romhacking-framework
---------------------------------------------------------------------------------------