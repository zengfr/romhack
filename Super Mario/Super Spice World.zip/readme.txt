-SUPER SPICE WORLD
-v1.0: November 3, 1997
-Language: English
-ROM ripped by Xx_PangentTechnologiesSisterLocation_xX
http://pangenttechnologies.tumblr.com/
Enjoy!
           _                 _      _     
          (_)               (_)    | |    
 ___ _ __  _  ___ ___   __ _ _ _ __| |___ 
/ __| '_ \| |/ __/ _ \ / _' | | '__| / __|
\__ \ |_) | | (_|  __/ |(_| | | |  | \__ \
|___/  __/|_|\___\___| \__  |_|_|  |_|___/
    | |                 __/ |             
    |_|                |___/              