Classic Mario World 3:The Finale 
by Bandicoot.
--------------------------------------------------------------
	After defeating the Great Alliance in the last adventure Mario took a long vacation but when he returned he discovers that Bowser has taken over Rosalina's Observatory and kidnapped her.
	Also there's a warp stars that works as a gateway to his space fortress hidden on his castle, so Mario decides to go on an adventure to save her.
	Levels in this hack are usually longer than the ones from the previous hacks and even SMW but dont worry, this hack features the Multiple Midway points patch.
	Also new to this update are the Longjump and High jump moves that can help the players in traversing the levels.
I hope you enjoy and have fun!
--------------------------------------------------------------
This hack includes:
-93 new long levels
-120 exits
-9 worlds
-Some Custom graphics
-Custom Music/ BTW the soundtrack has been updated fixing an old bug and adding new songs
-ASM
-Patches
-Etc.

Whats new in this update?
New gameplays improvements:
- Upward Fireballs Patch
- The player starts with 10 lives instead of 3
- Press START to save the game on the map 
- Level design improvements
- Some repetitive sections of the levels were edited or cut off
- Some secret exits locations are rearranged 
- The Click Clock Maze level now has adaptive music to each season 

Fixed some bugs like: 
- The music speeding up on the OW after finishing a level 
with less than a 100 seconds
- Wrong multi midway points entrances
--------------------------------------------------------------
Credits:
----------------------
Level Design:
Bandicoot
-----------------------
Beta Testers(Definitive Version):
N450
Erpster2
Fire Fast
N450
Erpster2
Fire Fast
Anorakun
The Morganah
MS
Lester Vine
CrazyTM

Beta Testers(Old Version):
ForthrightMC 
Bandicoot
KorayD
erpster2
--------------------------------------------------------------
Graphics:
Gamma V
Koyuki
Bandicoot
Aeon
Jimmy52905
Berkay
--------------------------------------------------------------
Current Update Custom Music:

HaruMKT/Harumi Makoto
Juniorsword448
HackerOfTheLegend
Sayuri
Gamma V
Unknown User
Jimmy52905
SNN
PinkGoldPeach
Samantha
KevinM
TCDW
RednGreen
Blind Devil
Fyord
Jimmy
Slash Man
Darius
Lui37
Joey
musicalman
Dark Mario Bros
Crispy
EDIT3333	
Masashi27
Atma
Masterlink
SiameseTwins
Lou
Nameless
Nobuo Uematsu
LadiesMan217
TheInsanity115
CrispyYoshi
MidiGuy
Mayonnai
Wakana
imamelia
ggamer77
Arctic Avenger
Jimmy
LemmyKoopa
Moose
Sinc-X
Torchkas
Tornado
Gloomy
Wyatt Croucher
Mrpinci19
MercuryPenny
Pinci
GrandChaos9000
Core
BeniBoD
marioVSshadow
AntiDuck
Iguy
Bandicoot
--------------------------------------------------------------
Old Version Custom Music:
Bandicoot
PinkGoldPeach 
Gamma V
Midiguy
JuniorSword448
HackerOfTheLegend
Wakana
CrispyYoshi
Joey
Maxodex
Dieghost
Coolmario
Izuna
S.N.N.
Masashi27
Slash Man
Sinc-X
Jimmy52905
Supertails
Sayuri
TheInsanity115
Kitaoji Satsuki
Iguy
TCDW
Masterlink
Lemmy Loopa
Lui37
Moose
Nameless
Tornado
Blind Devil
Arctic Avenger
Harumi Makoto
Mrpinci19
Dark Mario Bros
Gloomy Star
Imammelia
AntiDuck
--------------------------------------------------------------
Sprites:
Dahnamics
Romi
Mikeyk
YoshiCookiezeus
lolcats439
Lucario
andy_k_250
imamelia
Dispari Scuro
Davros
Manuz Ow Hacker
IceMan
Iceguy
leod
Alcaro
chdata
Ersanio
Kaijyuu
Shog
smkdan
ixtab
koyuki
MarioE
Thegag96
Noobisch Noobscicle
Ramp202
Nimono
Atma
BlindDevil
Jerry86
Megafonzie
Jimmy52905
NamelessProtagonist
Sonikku
Roy
Reallink
PercentN
Jagfillit
Maxx
1524
ICB
Davros
Schwa
Shinnok
xique
edit1754
andy_k_250
Reini
Unknow
Magus
682
ALEX
Stalex
Sukasa
--------------------------------------------------------------
ASM:
Fierce Deity Manuz Ow Hacker
Koopster
LX5
GreenhammerBro
LDA
--------------------------------------------------------------Patches:
Ladida
Imammelia
Aiyo
GreenHammerBro.
Manuz ow hacker
Romi
LX5 MarioE
Koopster
NeosZ
Ersanio
Alcaro
Iceman
wiiqwertyuiop
Nesquick Bunny
p4plus2
smkdan
MathOnNapkins
V'Lanta'la'mana'ma'nisha 
Kaijuu
MolSno
Discothebat
Romi
Erik
Edit1754/SMWEdit
MarioFanGamer
aCrowned
--------------------------------------------------------------
Blocks:
Lexi
Sonikku
Iceguy
Bandicoot
Koopster
JackThsSpades
GreenHammerBro
nick 139
Teo17
I8Strudel
Roy
lolcats439
Nesquik Bunny
--------------------------------------------------------------
Special Thanks:
N450
Sonikku
Koopster
Kitaoji Satsuki
Fusoya
KorayD
Mirann
ForthrightMC
Manuz Ow Hacker
TheInsanity115
LX5
GreenhammerBro
LDA
Gameplay&Detonados
allowiscous
erpster2
God
--------------------------------------------------------------
Special Thanks(Definitive Version)
N450 (For the massive help with the testing and feedback)
Anorakun (For the massive help with the testing and feedback)




