SMW The Crown Tale
by Bandicoot


SMW The Crown Tale is romhack of SMW based on the Bowsette memes around the internet, the hack is basically a traditional Mario adventure with a story involving Bowsette and the Super Crown.
While it have a story is not really a huge-super impressive one, but it can still be funny with the dialogues included.
Also I made sure to make the level design fresh and good as possible.
So have fun!  

Story:
While Mario was taking a vacation on a far away island Toadette suddenly appears before him with sudden news that her Super Crown was stolen by Bowser and that he used it to impersonate the Princess and fool everyone on the mushroom kingdom.
Later they discover that Kamek used its magic on the crown to allow anyone to use the crown since it had a magic seal to prevent anyone beside its guardian Toadette from using it.
But because of the magic a evil spirit awakened on the crown and took over Bowser's and Peach mind making them go crazy. 
Help Mario to return to the mushroom kingdom and save the day once again.

This hack includes:
-92 new levels
-112 exits
-48 moons to find(Optional)
-460 dragon coins to find between 92 levels(obligatory if you want to enter in the special world)
- Good level design
- Custom music
- Custom Sprites
- Custom graphics
- Custom blocks
- ASM
- Hdma
- DDA System
- New Moves: Walljump, Long Jump and High Jump
- 2 diferent endings
------------------------------------------------------
Credits:
_____________________________________________________________
Level Design:
Bandicoot
_____________________________________________________________
Special Thanks:
Moltz for making the Bowsette's and some of Peach custom graphics
N450 for the huge help with the testing and helping me with the english grammar.
_____________________________________________________________

Beta Testing:

N450
ForthRightMC
Erpster2
lordkronos100
Ninjaboy
Bandicoot
_____________________________________________________________
Custom Music:
Pinci
Dark Mario Bros
Decoy Blimp
NastCF
Wakana
EDIT3333
Wyatt Croucher
AnasMario130
Crispy
Blind Devil
Jimmy
LemmyKoopa
Lui37
Unkknown User
Teows
NastCF
CoolMario
SiameseTwins
spigmike
SNN
HarvettFox96
Darius
Moose
Gloomy
Nameless
RednGreen
S.N.N
Sinc-X
Torchkas
Tornado
Red Chameleon
Hiro
tcdw
KKevinM
Izuna
Pinkgoldpeach
Musicalman
Ladiesman217
Blue Warrior
Jead
KevinM
giftshaven
6646
Crispy
Masashi27
Ultima
Izuna
bebn legg
Dark Mario Bros
Core
Masterlink
Immamelia
Counterfeit
LemmyKoopa
RednGreen
ThinkOneMoreTime
EDIT3333
TCDW
Lui
Masashi27
_____________________________________________________________
Custom Graphics:
Bandicoot
Gamma V.
Twoka
The Hacking Yoshi
Dan
SuperMariaSis
blueyosh
superwiidude
GOP1994GOP
Yan
Pixelator
Hinalite
SafeDesire
Hadron
Secretchaos
Sans Sunday
Kotori
Broozer
Buu
GrandChaos9000
Mai
Luigi-san
Moltz
RykonV73
Dark Mario Bros
Kaching720
DragonFire6780
Idol
Nowieso
Pokerface
Cheeyev
Kotori
CapitanFrio09
Ralshi02
Epic_Stuff
luzak.64	
Ithos
Brutapode89
Digital Entertainment
_____________________________________________________________
Custom Sprites:
Iceguy
RussianMan
Erik
Tattletale
1524
Major Flare
Blind Devil
leod
imamelia
KKevinM
Mandew
yoshicookiezeus
Romi
Mikeyk
LX5
Davros
edit1754
Alcaro
TheBiob
Tsutarja
Thomas
smkdan
Biob
Thomas
Akaginite
NekohDot
Ixtab
Telinc1
GreenHammerBro
Sonikku
himajin
Dispari Scuro
Whiteyoshiegg
1524

_____________________________________________________________
ASM/Patches:
Ice Man
imamelia
MarioFanGamer
Alcaro
WhiteYoshiEgg
Chdata/Fakescaper
JackTheSpades
Ersanio
Edit1754
MathOnNapkins
WhiteYoshiEgg
Erik557
MarioE
mikeyk
aCrowned 
Minimay
Blind Devil
Mattrizzle
HuFlungDu
Roy
smkdan
Discobat
Erik
aCrowned
Minimay

_____________________________________________________________
Custom Blocks:

JackTheSpades
GreenHammerBro
EternityLarva
SuperMaks64
Sonikku
ImJake9
MarioE
Alcaro
Lexi
TheGreatBulzome
Superyoshi
Davros
Sind
Ersanio
Ramp202
Iceguy
Roy
Bandicoot

Thanks for playing the hack! 
Good luck and have fun! ;)