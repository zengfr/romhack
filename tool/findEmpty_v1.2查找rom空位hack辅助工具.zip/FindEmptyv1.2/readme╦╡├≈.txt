﻿findEmpty_v1.2查找rom空位hack辅助工具

Usage: ./findempty <file> [minimum=1024] 

cmd:findempty.exe fullFilePath findMinLength 

example:findempty.exe dino.rom 512

hack工具说明：主要用于查找rom或破解文件的连续空白处，
方便插入新hack程序.(一般程序中0x00或0xFF为空白)。
使用方法如上或看截图。

v1.2更新: 
1、新增0xFF空白段显示。
2、编译静态文件比上一版本大。
3、打包libwinpthread-1.dll。




