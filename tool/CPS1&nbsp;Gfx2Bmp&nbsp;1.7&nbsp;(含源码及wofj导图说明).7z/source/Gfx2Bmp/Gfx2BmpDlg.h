// Gfx2BmpDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CGfx2BmpDlg dialog
class CGfx2BmpDlg : public CDialog
{
// Construction
public:
	CGfx2BmpDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_GFX2BMP_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButton1();
	CStatic m_Static_config;
	CStatic m_Static_size;
	CStatic m_Static_addr;
	CStatic m_Static_len;
	CButton m_Button_export;
	CButton m_Button_exit;
	afx_msg void OnCbnSelchangeCombo1();
	CComboBox m_Combo_config;
	CComboBox m_Combo_size;
	afx_msg void OnCbnDropdownCombo1();
	afx_msg void OnCbnDropdownCombo2();
	afx_msg void OnCbnSelchangeCombo2();
	CEdit m_Edit_addr;
	CEdit m_Edit_len;
	CButton m_Button_import;
	afx_msg void OnBnClickedButton2();
	CButton m_Check_importPal;
	int m_intRadio_bpp;
	int m_nRadio1;
	int m_nRadio4;
	CEdit m_Edit_tileStart;
	CEdit m_Edit_tileWidth;
	CEdit m_Edit_tileHeight;
	CEdit m_Edit_lenHeight;
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	CEdit m_Edit_transcolor;
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	CStatic m_Static_pic;
	CEdit m_Edit_R;
	CEdit m_Edit_G;
	CEdit m_Edit_B;
	CButton m_Check_transcolor;
};
