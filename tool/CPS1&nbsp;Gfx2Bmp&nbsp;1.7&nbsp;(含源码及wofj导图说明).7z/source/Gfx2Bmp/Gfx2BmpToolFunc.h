#include <windows.h>
#include <vector>
#include <string>

using namespace std;



struct tConfigFile{
	CString filetitle;
	CString filename;
	CString filepathname;
};


struct tPAL{
	BYTE        B;
	BYTE        G;
	BYTE        R;
	BYTE        A;
};

// config requred variables
vector<tConfigFile> configfiles;
int configfile_idx;

CString palfile;
DWORD paloffset;
vector<tPAL> pal_RGBs;
int pal_type = 0;	// 1=[pal_rom], 2=[pal_RGB]

vector<CString> gfxFiles;
vector<DWORD> gfxOffsets;
vector<DWORD> gfxSizes;
vector<BYTE *> gfxMems;


// tile
DWORD tw = 16;	// tile width
DWORD th = 16;	// tile height
DWORD tn = 16;	// number of tiles in one line

// gfx and palette
BYTE *gfxdata = NULL;
DWORD gfxsize = 0;
BYTE *paldata = NULL;
DWORD palsize = 0;

bool alsoImportPal=false;

int codec=1;                                // "1": ʹ��SMS 4bpp��ʽ����/����
                                            // "0": ��ʹ���κη�ʽ����/����
                                            // Ŀǰû����������ѡ��

bool rom_16bit_byteswap=false;              // "false": ��ʹ�ö��ֽڽ��� (����rom�ļ�)
                                            // "true": ʹ�ö��ֽڽ��� (�ڴ�dumpģʽ��rom�ļ�)
                                            
int gfx_merge=4;                            // gfx����ϲ�, ÿ���� 4 ���ļ�Ϊ��λ���кϲ�
                                            // [gfx]������, ����Ҫ��4�ı������ļ�
                                            
int gfx_cross=2;                            // gfx����ϲ�, ÿ���� 2 ���ֽ�Ϊ��λ���н��� (������ֵΪ 2)
                                            // [gfx]������, offset������2�ı���
                                            
                                            // ����������gfx rom�Ѿ��Ǻϲ��õĵ�һ�ļ�
                                            // ��ô���÷����� gfx_merge="1" gfx_cross="0"


											// CPS1:   gfx_merge="4" gfx_cross="2"
											// NeoGeo: gfx_merge="2" gfx_cross="1"

// ָ��͸��ɫ
bool useTransColor = false;
BYTE transR=255;
BYTE transG=0;
BYTE transB=252;
CBrush *tcBrush = new CBrush(RGB(transR,transG,transB));;


// decode (copy from http://www.mamedev.org/source/src/mame/video/cps1.c.html line 1702)
// same as 4BPP SMS (Sega Master System) decode 
void cps1_gfx_decode(UINT8 *cps1_gfx,int size)
{
	//       int size = memregion("gfx")->bytes();
	int i, j, _gfxsize;
	//      UINT8 *cps1_gfx = memregion("gfx")->base();

	_gfxsize = size / 4;

	for (i = 0; i < _gfxsize; i++)
	{
		UINT32 src = cps1_gfx[4 * i] + (cps1_gfx[4 * i + 1] << 8) + (cps1_gfx[4 * i + 2] << 16) + (cps1_gfx[4 * i + 3] << 24);
		UINT32 dwval = 0;

		for (j = 0; j < 8; j++)
		{
			int n = 0;
			UINT32 mask = (0x80808080 >> j) & src;

			if (mask & 0x000000ff) n |= 1;
			if (mask & 0x0000ff00) n |= 2;
			if (mask & 0x00ff0000) n |= 4;
			if (mask & 0xff000000) n |= 8;

			dwval |= n << (j * 4);
		}
		cps1_gfx[4 *i    ] = dwval >> 0;
		cps1_gfx[4 *i + 1] = dwval >> 8;
		cps1_gfx[4 *i + 2] = dwval >> 16;
		cps1_gfx[4 *i + 3] = dwval >> 24;
	}
}


// reverse from cps1_gfx_decode()
void cps1_gfx_encode(UINT8 *cps1_gfx,int size)
{
	int i, j, _gfxsize;
	_gfxsize = size / 4;

	for (i = 0; i < _gfxsize; ++i)
	{
		UINT32 src = cps1_gfx[4 * i] + (cps1_gfx[4 * i + 1] << 8) + (cps1_gfx[4 * i + 2] << 16) + (cps1_gfx[4 * i + 3] << 24);
		UINT32 dwval = 0;

		for (j = 0; j < 8; ++j)
		{
			int n = 0;
			n = (src >> (j*4)) & 0x0000000f;
			if(n & 1) dwval |= (0x00000080 >> j);
			if(n & 2) dwval |= (0x00008000 >> j);
			if(n & 4) dwval |= (0x00800000 >> j);
			if(n & 8) dwval |= (0x80000000 >> j);

		}
		cps1_gfx[4 *i    ] = dwval >> 0;
		cps1_gfx[4 *i + 1] = dwval >> 8;
		cps1_gfx[4 *i + 2] = dwval >> 16;
		cps1_gfx[4 *i + 3] = dwval >> 24;
	}
}

// read file list in \ini folder
void   getConfigFiles()   
{   
	configfiles.clear();

	CFileFind   finder;   

	CString   strWildcard(_T("ini\\*.*"));   

	BOOL   bWorking   =   finder.FindFile(strWildcard);   
	while   (bWorking)   
	{   

		bWorking   =   finder.FindNextFile();   

		//   skip   .   and   ..
		if   (finder.IsDots())   
			continue;   

		//   skip directory
		if   (finder.IsDirectory())   
			continue;

		tConfigFile temp;
		temp.filetitle=finder.GetFileTitle();		
		temp.filename=finder.GetFileName();		
		temp.filepathname=finder.GetFilePath();
		//AfxMessageBox(temp.filename);
		//AfxMessageBox(temp.filepathname);

		configfiles.push_back(temp);

	}   
	finder.Close();   
}  

// tokenize a string line to RGB values
tPAL getRGB(char *str)
{
	vector<string> token;
	char *pointer = str;
	char *begin;
	while(1) {
		begin = pointer;
		while(*pointer != ' ' && *pointer != '\t' && *pointer != 0) {
			pointer++;
		}
		if(begin < pointer) {
			token.push_back(string(begin, pointer));
		}
		if(*pointer == 0) {
			break;
		}
		pointer++;
	}

	for(size_t i=token.size();i<=4;++i){
		token.push_back("0");
	}
	tPAL pal;
	pal.B=(BYTE)atoi(token[2].c_str());
	pal.G=(BYTE)atoi(token[1].c_str());
	pal.R=(BYTE)atoi(token[0].c_str());
	pal.A=(BYTE)atoi(token[3].c_str());

	return pal;
}

// read the config file
bool readConfig(){

	palfile=(TEXT(""));
	paloffset=0;

	pal_type = 0;
	pal_RGBs.clear();

	gfxFiles.clear();
	gfxOffsets.clear();
	gfxSizes.clear();
	gfxMems.clear();

	codec=1;
	rom_16bit_byteswap=false;              
	gfx_merge=4;                          
	gfx_cross=2;

	size_t i = 0;
	size_t j = 0;
	size_t k = 0;

	// ȡ�õ�ǰ�����ļ���
	CString configfile;
	if(configfile_idx<configfiles.size()){
		configfile = configfiles[configfile_idx].filepathname;
	}else{
		return false;
	}

	//AfxMessageBox(configfile);

	CFile fin;
	fin.Open(configfile, CFile::modeRead);

	char *text = NULL;
	DWORD finsize = fin.GetLength();
	text = new char[finsize+1];
	memset(text, 0, finsize+1);
	fin.Read(text,finsize); 
	fin.Close();


	vector<string> lines = splitLines(text);
	delete [] text;


	// ɾ��ע��
	removecomments(lines);
	//for(i=0;i<lines.size();++i){
	//	print(lines[i]);
	//}


	size_t pos, start, end;
	bool ok = false;
	int sec = 0; // 1: in [pal_rom], 2: in [pal_rgb], 3: in [gfx], 4: in [option] 
	for(i=0;i<lines.size();++i){
		lines[i] = 	toLowerCase(_trim(lines[i]));

		if(lines[i].size()<1)
			continue;

		pos = lines[i].find("[pal_rom]");
		if(pos != string::npos){
			sec = 1;
			if(pal_type==0){
				pal_type = 1;
			}
			continue;
		}

		pos = lines[i].find("[pal_rgb]");
		if(pos != string::npos){
			sec = 2;
			if(pal_type==0){
				pal_type = 2;
			}
			continue;
		}

		pos = lines[i].find("[gfx]");
		if(pos != string::npos){
			sec = 3;
			continue;
		}

		pos = lines[i].find("[option]");
		if(pos != string::npos){
			sec = 4;
			continue;
		}

		if(sec==1 || sec==3){
			pos = lines[i].find("name");
			if(pos != string::npos){

				start = lines[i].find('\"',pos+4);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				CString strtemp(lines[i].substr(start+1,end-start-1).c_str());
				if(sec==1){
					palfile = strtemp;
				}else if(sec==3){
					gfxFiles.push_back(strtemp);
				}

				pos = lines[i].find("offset");
				start = lines[i].find('\"',pos+6);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				DWORD offsettemp = 0;
				ok = HexStringToDword(lines[i].substr(start+1,end-start-1), &offsettemp);
				if(!ok){return false;};
				if(sec==1){
					paloffset = offsettemp;
				}else if(sec==3){
					gfxOffsets.push_back(offsettemp);
				}
			}
		}else if(sec==2){	// [pal_rgb]
			pal_RGBs.push_back(getRGB((char *)lines[i].c_str()));
		}else if(sec==4){	// [option]
			pos = lines[i].find("rom_16bit_byteswap");
			if(pos != string::npos){
				start = lines[i].find('\"',pos+4);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				string stmp = lines[i].substr(start+1,end-start-1);
				if(stmp.compare("true")==0){
					rom_16bit_byteswap=true;
				}else{
					rom_16bit_byteswap=false;
				}
				continue;
			}

			pos = lines[i].find("codec");
			if(pos != string::npos){
				start = lines[i].find('\"',pos+4);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				string stmp = lines[i].substr(start+1,end-start-1);
				codec = atoi(stmp.c_str());
				if(codec!=1 && codec!=0)
					codec=1;
				continue;
			}

			pos = lines[i].find("gfx_merge");
			if(pos != string::npos){
				start = lines[i].find('\"',pos+4);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				string stmp = lines[i].substr(start+1,end-start-1);
				gfx_merge = atoi(stmp.c_str());
				if(gfx_merge<1)
					gfx_merge=4;
				continue;
			}
			
			pos = lines[i].find("gfx_cross");
			if(pos != string::npos){
				start = lines[i].find('\"',pos+4);
				end = lines[i].find('\"',start+1);
				if(end-start-1<1){return false;};
				string stmp = lines[i].substr(start+1,end-start-1);
				gfx_cross = atoi(stmp.c_str());
				if(gfx_cross<0)
					gfx_cross=2;
				continue;
			}
		} // end of sec 4
	}// end of for loop

	//AfxMessageBox(palfile);
	//printHex(paloffset);
	//for(i=0;i<gfxFiles.size();++i){
	//	AfxMessageBox(gfxFiles[i]);
	//}
	//for(i=0;i<gfxOffsets.size();++i){
	//	printHex(gfxOffsets[i]);
	//}

	//printInt(rom_16bit_byteswap);
	//printInt(gfx_merge);
	//printInt(gfx_cross);
	return true;

}



bool readPal(){

	paldata = NULL;
	palsize=0;

	size_t i;

	CFile fin;
	DWORD finsize;
	if(pal_type==1){	// [pal_rom]
		fin.Open(palfile, CFile::modeRead|CFile::typeBinary);
		finsize = fin.GetLength();
		if(finsize<paloffset+32){
			fin.Close();
			return false;
		}
		BYTE *palDataOrg = NULL;
		palDataOrg = new BYTE[32];
		memset(palDataOrg, 0, 32);
		fin.Seek(paloffset,CFile::begin);
		fin.Read(palDataOrg,32); 
		fin.Close();


		// pal convertion
		paldata = new BYTE[64];
		for(i=0;i<32;++i){
			BYTE b = palDataOrg[i] & 0x0f;
			paldata[2*i] = b | (b<<4);
			b = palDataOrg[i] & 0xf0; 
			paldata[2*i+1] = b | (b>>4);
		}
		delete [] palDataOrg;

		palsize = 64;
	}else{  // pal_type==2 // [pal_RGB]
		paldata = new BYTE[64];
		memset(paldata, 0, 64);
		for(i=0;i<pal_RGBs.size() && i<16;++i){
			paldata[4*i+0]=pal_RGBs[i].B;
			paldata[4*i+1]=pal_RGBs[i].G;
			paldata[4*i+2]=pal_RGBs[i].R;
			paldata[4*i+3]=pal_RGBs[i].A;
		}

		palsize = 64;
	}
	return true;

}

void saveGfxData(){

	// save file data
	CFile* cFile = NULL;
	//cFile = NULL;
	cFile = new CFile();
	cFile->Open(TEXT("gfxromtemp.rom"), CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	cFile->Write(gfxdata,gfxsize);
	cFile->Close();
	delete cFile;
}


bool gfxMerge(){

	size_t i = 0;
	size_t j = 0;
	size_t k = 0;

	gfxdata = NULL;
	gfxsize=0;
	//paldata = NULL;
	//palsize=0;


	//if(!readConfig())
	//	return false;

	//// read pal
	//if(!readPal())
	//	return false;

	//	for(size_t kkk=0;kkk<*_palsize;++kkk){
	//	printHex((DWORD)palData[kkk]);
	//}

	// read gfx
	CFile fin;
	DWORD finsize;
	gfxsize=0;
	for(i=0;i<gfxFiles.size();++i){
		fin.Open(gfxFiles[i], CFile::modeRead|CFile::typeBinary);
		finsize = fin.GetLength();
		if(finsize<1){
			fin.Close();
			return false;
		}
		gfxSizes.push_back(finsize);
		gfxsize+=finsize;

		BYTE *gfxmemtmp = NULL;
		gfxmemtmp = new BYTE[finsize];
		//memset(gfxmemtmp, 0, finsize);
		fin.Read(gfxmemtmp,finsize); 
		fin.Close();

		gfxMems.push_back(gfxmemtmp);
	}


	// cps1
	//size_t merge = 4;
	//size_t cross = 2;

	// neogeo
	// size_t cross = 1;
	// size_t merge = 2;

	size_t merge = gfx_merge;
	size_t cross = gfx_cross;

	if(gfxFiles.size()<merge || gfxFiles.size()%merge!=0)
		return false;
	if(gfxFiles.size()!=gfxOffsets.size())
		return false;
	if(gfxFiles.size()!=gfxSizes.size())
		return false;
	if(gfxFiles.size()!=gfxMems.size()){
		for(i=0;i<gfxMems.size();++i){
			if(gfxMems[i]!=NULL)
				delete [] gfxMems[i];
		}
		return false;
	}



	// merge gfx roms
	gfxdata = new BYTE[gfxsize];
	for(i=0;i<gfxFiles.size();++i){
		size_t memsize = (size_t)gfxSizes[i];
		if(cross<=0)
			cross = memsize;
		DWORD memoffset = gfxOffsets[i];
		BYTE *mempointer = gfxMems[i];
		for(j=0;j<memsize/cross;++j){
			for(k=0;k<cross;++k){
				gfxdata[j*merge*cross + memoffset + k] = mempointer[cross*j + k];
			}
		}
	}

	//// save file data
	//CFile* cFile = NULL;
	////cFile = NULL;
	//cFile = new CFile();
	//cFile->Open(TEXT("gfxromtemp.rom"), CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	//cFile->Write(gfxdata,gfxsize);
	//cFile->Close();
	//delete cFile;


	for(i=0;i<gfxMems.size();++i){
		if(gfxMems[i]!=NULL)
			delete [] gfxMems[i];
	}

	return true;
}


bool writePal(){

	// write pal
	CFile fin;
	DWORD finsize;
	if(alsoImportPal==true && palfile.GetLength()>0 && palsize==64 && paldata!=NULL){	// [pal_rom]

		BYTE *palDataOrg = NULL;
		palDataOrg = new BYTE[32];
		memset(palDataOrg, 0, 32);

		// pal convertion
		for(size_t i=0;i<32;++i){
			BYTE b1 = paldata[2*i];
			BYTE b2 = paldata[2*i+1];
			b1 = (b1 & 0xf0) >> 4;
			b2 = (b2 & 0xf0);
			palDataOrg[i] = b1 | b2; 
		}

		fin.Open(palfile, CFile::modeWrite|CFile::typeBinary);
		finsize = fin.GetLength();
		if(finsize<paloffset+32){
			fin.Close();
			return false;
		}
		fin.Seek(paloffset,CFile::begin);
		fin.Write(palDataOrg,32); 
		fin.Close();

		delete [] palDataOrg;

	}
	return true;
}


bool gfxSplit(){

	gfxSizes.clear();
	gfxMems.clear();

	size_t i = 0;
	size_t j = 0;
	size_t k = 0;

	//if(gfxdata==NULL || paldata==NULL || gfxsize<=0 || palsize<=0){
	if(gfxdata==NULL || gfxsize<=0){
		return false;
	}




	// write gfx
	for(i=0;i<gfxFiles.size();++i){
		gfxSizes.push_back(gfxsize/gfxFiles.size());

		BYTE *gfxmemtmp = NULL;
		gfxmemtmp = new BYTE[gfxSizes[i]];
		//memset(gfxmemtmp, 0, finsize);

		gfxMems.push_back(gfxmemtmp);
	}

	// cps1
	// size_t merge = 4;
	// size_t cross = 2;

	size_t merge = gfx_merge;
	size_t cross = gfx_cross;

	if(gfxFiles.size()<merge || gfxFiles.size()%merge!=0)
		return false;
	if(gfxFiles.size()!=gfxOffsets.size())
		return false;
	if(gfxFiles.size()!=gfxSizes.size())
		return false;
	if(gfxFiles.size()!=gfxMems.size()){
		for(i=0;i<gfxMems.size();++i){
			if(gfxMems[i]!=NULL)
				delete [] gfxMems[i];
		}
		return false;
	}




	// split gfx roms
	for(i=0;i<gfxFiles.size();++i){
		size_t memsize = (size_t)gfxSizes[i];
		if(cross<=0)
			cross = memsize;
		DWORD memoffset = gfxOffsets[i];
		BYTE *mempointer = gfxMems[i];
		for(j=0;j<memsize/cross;++j){
			for(k=0;k<cross;++k){
				mempointer[cross*j + k] = gfxdata[j*merge*cross + memoffset + k];
			}
		}

		// save file data
		CFile* cFile = NULL;
		cFile = new CFile();
		cFile->Open(gfxFiles[i], CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
		cFile->Write(mempointer,memsize);
		cFile->Close();
		delete cFile;
	}

	//saveGfxData();


	for(i=0;i<gfxMems.size();++i){
		if(gfxMems[i]!=NULL)
			delete [] gfxMems[i];
	}

	return true;
}


bool bmp4bitTo8bit(BYTE *bmp4, size_t size4, BYTE *bmp8, size_t size8){



	DWORD bmp4_raw_size = size4 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*16;
	DWORD bmp8_raw_size = bmp4_raw_size * 2;

	if (size8 != bmp8_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*256){
		return false;
	}

	memcpy(bmp8, bmp4, size4 - bmp4_raw_size);

	BYTE *pointer8 = bmp8;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer8;
	pFHeader->bfSize = size8;
	pFHeader->bfOffBits = size8 - bmp8_raw_size;


	// bmp info header
	pointer8 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer8;
	pIHeader->biBitCount = 8;
	pIHeader->biSizeImage = bmp8_raw_size;     // unsure
	pIHeader->biXPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biYPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biClrUsed = 256;// unsure
	pIHeader->biClrImportant = 256;// unsure

	// palette
	pointer8 += sizeof(BITMAPINFOHEADER);
	// already copied using memcpy


	// bmp raw data
	pointer8 += 256 * 4;
	BYTE *pBmpRaw8 = pointer8;
	BYTE *pBmpRaw4 = bmp4 + (size4 - bmp4_raw_size);

	for(size_t i = 0; i < bmp4_raw_size; ++i){
		pBmpRaw8[2*i] = (pBmpRaw4[i] & 0xf0)>>4;
		pBmpRaw8[2*i+1] = pBmpRaw4[i] & 0x0f;
	}


	return true;
}


bool bmp4bitTo24bit(BYTE *bmp4, size_t size4, BYTE *bmp24, size_t size24){



	DWORD bmp4_raw_size = size4 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*16;
	DWORD bmp24_raw_size = bmp4_raw_size * 6;

	if (size24 != bmp24_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)){
		return false;
	}

	memcpy(bmp24, bmp4, sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

	BYTE *pointer24 = bmp24;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer24;
	pFHeader->bfSize = size24;
	pFHeader->bfOffBits = size24 - bmp24_raw_size;


	// bmp info header
	pointer24 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer24;
	pIHeader->biBitCount = 24;
	pIHeader->biSizeImage = bmp24_raw_size;     // unsure
	pIHeader->biXPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biYPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biClrUsed = 0;// unsure
	pIHeader->biClrImportant = 0;// unsure

	// no palette
	pointer24 += sizeof(BITMAPINFOHEADER);

	// bmp raw data
	BYTE *pBmpRaw24 = pointer24;
	BYTE *pBmpRaw4 = bmp4 + (size4 - bmp4_raw_size);
	BYTE *pPal16 = bmp4 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);

	size_t pal_idx1, pal_idx2;
	for(size_t i = 0; i < bmp4_raw_size; ++i){
		pal_idx1 = (pBmpRaw4[i] & 0xf0)>>4;
		pal_idx2 = pBmpRaw4[i] & 0x0f;
		pBmpRaw24[i*6] = pPal16[pal_idx1*4];		// B1
		pBmpRaw24[i*6+1] = pPal16[pal_idx1*4+1];	// G1
		pBmpRaw24[i*6+2] = pPal16[pal_idx1*4+2];	// R1
		pBmpRaw24[i*6+3] = pPal16[pal_idx2*4];		// B2
		pBmpRaw24[i*6+4] = pPal16[pal_idx2*4+1];	// G2
		pBmpRaw24[i*6+5] = pPal16[pal_idx2*4+2];	// R2
	}


	return true;
}



// given palette, and an rgb color, find the closet palette index
size_t findClosestColorIndex(BYTE *pal, size_t sizepal, BYTE rr, BYTE gg, BYTE bb, int colorMatchMode){

	// colorMatchMode = 0 => match higher 4 bits
	// colorMatchMode = 1 => color similarity

	size_t color_idx;
	if(colorMatchMode==1){
		// using YUV distance to decide color similarity 
		float R = (float)rr;
		float G = (float)gg;
		float B = (float)bb;

		float Y1,U1,V1,Y2,U2,V2,d,dmin;
		color_idx=0;

		Y1 = 0.299*R + 0.587*G + 0.114*B;
		U1 = -0.14713*R - 0.28886*G + 0.436*B;
		V1 = 0.615*R - 0.51499*G - 0.10001*B;

		for(size_t i=0; i < sizepal/4; ++i){

			Y2 = 0.299*pal[i*4+2] + 0.587*pal[i*4+1] + 0.114*pal[i*4];
			U2 = -0.14713*pal[i*4+2] - 0.28886*pal[i*4+1] + 0.436*pal[i*4];
			V2 = 0.615*pal[i*4+2] - 0.51499*pal[i*4+1] - 0.10001*pal[i*4];

			d = (Y1-Y2)*(Y1-Y2) + (U1-U2)*(U1-U2) + (V1-V2)*(V1-V2);
			//d = (R-pal[i*4+2])*(R-pal[i*4+2]) + (G-pal[i*4+1])*(G-pal[i*4+1]) + (B-pal[i*4])*(B-pal[i*4]);
			if(i==0){
				dmin=d;
				color_idx=0;
			}else if(d<dmin){
				dmin = d;
				color_idx = i;
			}

		}

	}else{

		// match higher 4 bit

		rr = rr >> 4;
		gg = gg >> 4;
		bb = bb >> 4;

		BYTE bR,bG,bB;

		color_idx = sizepal/4 - 1;

		for(size_t i=0; i < sizepal/4; ++i){
			bB = pal[4*i] >> 4;
			bG = pal[4*i+1] >> 4;
			bR = pal[4*i+2] >> 4;
			if(bR==rr && bG==gg && bB==bb){
				color_idx = i;
				break;
			}

		}
	}

	return color_idx;

}



// given palette, and an rgb color, find the closet palette index
// �ڶ���, ����͸��ɫ, ��ɫ������ƥ��, ֱ�ӵ��ɵ�16ɫ
size_t findClosestColorIndex2(BYTE *pal, size_t sizepal, BYTE rr, BYTE gg, BYTE bb, int colorMatchMode){

	// colorMatchMode = 0 => match higher 4 bits
	// colorMatchMode = 1 => color similarity


//BYTE transR=255;
//BYTE transG=0;
//BYTE transB=252;
if(useTransColor && rr == transR && gg ==transG && bb == transB){
	return sizepal/4-1;
}

//if(rr == 0 && gg == 0 && bb == 0){
//	return 0;
//}
//if(rr == 0 && gg == 0 && bb == 0){
//	return 15;
//}

	size_t color_idx;
	if(colorMatchMode==1){
		// using YUV distance to decide color similarity 
		float R = (float)rr;
		float G = (float)gg;
		float B = (float)bb;

		float Y1,U1,V1,Y2,U2,V2,d,dmin;
		color_idx=0;

		Y1 = 0.299*R + 0.587*G + 0.114*B;
		U1 = -0.14713*R - 0.28886*G + 0.436*B;
		V1 = 0.615*R - 0.51499*G - 0.10001*B;

		for(size_t i=0; i < sizepal/4-1; ++i){

			Y2 = 0.299*pal[i*4+2] + 0.587*pal[i*4+1] + 0.114*pal[i*4];
			U2 = -0.14713*pal[i*4+2] - 0.28886*pal[i*4+1] + 0.436*pal[i*4];
			V2 = 0.615*pal[i*4+2] - 0.51499*pal[i*4+1] - 0.10001*pal[i*4];

			d = (Y1-Y2)*(Y1-Y2) + (U1-U2)*(U1-U2) + (V1-V2)*(V1-V2);
			//d = (R-pal[i*4+2])*(R-pal[i*4+2]) + (G-pal[i*4+1])*(G-pal[i*4+1]) + (B-pal[i*4])*(B-pal[i*4]);
			if(i==0){
				dmin=d;
				color_idx=0;
			}else if(d<dmin){
				dmin = d;
				color_idx = i;
			}

		}

	}else{

		// match higher 4 bit

		rr = rr >> 4;
		gg = gg >> 4;
		bb = bb >> 4;

		BYTE bR,bG,bB;

		color_idx = sizepal/4 - 1;

		for(size_t i=0; i < sizepal/4-1; ++i){
			bB = pal[4*i] >> 4;
			bG = pal[4*i+1] >> 4;
			bR = pal[4*i+2] >> 4;
			if(bR==rr && bG==gg && bB==bb){
				color_idx = i;
				break;
			}

		}
	}

	return color_idx;

}










bool bmp8bitTo4bit(BYTE *bmp8, size_t size8, BYTE *bmp4, size_t size4, BYTE *pal16, size_t sizepal16, int colorMatchMode){



	DWORD bmp8_raw_size = size8 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*256;
	DWORD bmp4_raw_size = bmp8_raw_size / 2;

	if(size4 != bmp4_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*16){
		return false;
	}
	if(sizepal16 != 64){
		return false;
	}

	memcpy(bmp4, bmp8, size8 - bmp8_raw_size - 4*256);

	BYTE *pointer4 = bmp4;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer4;
	pFHeader->bfSize = size4;
	pFHeader->bfOffBits = size4 - bmp4_raw_size;


	// bmp info header
	pointer4 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer4;
	pIHeader->biBitCount = 4;
	pIHeader->biSizeImage = bmp4_raw_size;     // unsure
	pIHeader->biXPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biYPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biClrUsed = 0;// unsure
	pIHeader->biClrImportant = 0;// unsure

	// palette
	pointer4 += sizeof(BITMAPINFOHEADER);
	memcpy(pointer4, pal16, sizepal16);


	// bmp raw data
	pointer4 += 16 * 4;
	BYTE *pBmpRaw4 = pointer4;
	BYTE *pBmpRaw8 = bmp8 + (size8 - bmp8_raw_size);
	BYTE *pal256 = bmp8 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);

	BYTE b1, b2, bb, gg, rr, aa, color_idx1, color_idx2;
	for(size_t i = 0; i < bmp4_raw_size; ++i){

		// find color
		bb = pal256[pBmpRaw8[2*i]*4 + 0];
		gg = pal256[pBmpRaw8[2*i]*4 + 1];
		rr = pal256[pBmpRaw8[2*i]*4 + 2];
		//aa = pal256[pBmpRaw8[2*i]*4 + 3];
		
		if(!useTransColor)
			color_idx1 = (BYTE)findClosestColorIndex(pal16,sizepal16,rr,gg,bb,colorMatchMode);
		else
			color_idx1 = (BYTE)findClosestColorIndex2(pal16,sizepal16,rr,gg,bb,colorMatchMode);

		bb = pal256[pBmpRaw8[2*i+1]*4 + 0];
		gg = pal256[pBmpRaw8[2*i+1]*4 + 1];
		rr = pal256[pBmpRaw8[2*i+1]*4 + 2];
		//aa = pal256[pBmpRaw8[2*i+1]*4 + 3];
		if(!useTransColor)
			color_idx2 = (BYTE)findClosestColorIndex(pal16,sizepal16,rr,gg,bb,colorMatchMode);
		else
			color_idx2 = (BYTE)findClosestColorIndex2(pal16,sizepal16,rr,gg,bb,colorMatchMode);

		b1 = (color_idx1<<4) & 0xf0;
		b2 = color_idx2 & 0x0f;
		pBmpRaw4[i] = b1 | b2;
	}


	return true;
}



bool bmp24bitTo4bit(BYTE *bmp24, size_t size24, BYTE *bmp4, size_t size4, BYTE *pal16, size_t sizepal16, int colorMatchMode){

	DWORD bmp24_raw_size = size24 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER);
	DWORD bmp4_raw_size = bmp24_raw_size / 6;

	if(size4 != bmp4_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*16){
		return false;
	}
	if(sizepal16 != 64){
		return false;
	}

	memcpy(bmp4, bmp24, sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

	BYTE *pointer4 = bmp4;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer4;
	pFHeader->bfSize = size4;
	pFHeader->bfOffBits = size4 - bmp4_raw_size;


	// bmp info header
	pointer4 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer4;
	pIHeader->biBitCount = 4;
	pIHeader->biSizeImage = bmp4_raw_size;     // unsure
	pIHeader->biXPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biYPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biClrUsed = 0;// unsure
	pIHeader->biClrImportant = 0;// unsure

	// palette
	pointer4 += sizeof(BITMAPINFOHEADER);
	memcpy(pointer4, pal16, sizepal16);


	// bmp raw data
	pointer4 += 16 * 4;
	BYTE *pBmpRaw4 = pointer4;
	BYTE *pBmpRaw24 = bmp24 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);

	BYTE b1, b2, bb, gg, rr, aa, color_idx1, color_idx2;
	for(size_t i = 0; i < bmp4_raw_size; ++i){

		// find color
		bb = pBmpRaw24[i*6 + 0];
		gg = pBmpRaw24[i*6 + 1];
		rr = pBmpRaw24[i*6 + 2];
		//aa = pal256[pBmpRaw8[2*i]*4 + 3];
		if(!useTransColor)
			color_idx1 = (BYTE)findClosestColorIndex(pal16,sizepal16,rr,gg,bb,colorMatchMode);
		else
			color_idx1 = (BYTE)findClosestColorIndex2(pal16,sizepal16,rr,gg,bb,colorMatchMode);

		bb = pBmpRaw24[i*6 + 3];
		gg = pBmpRaw24[i*6 + 4];
		rr = pBmpRaw24[i*6 + 5];
		//aa = pal256[pBmpRaw8[2*i+1]*4 + 3];
		if(!useTransColor)
			color_idx2 = (BYTE)findClosestColorIndex(pal16,sizepal16,rr,gg,bb,colorMatchMode);
		else
			color_idx2 = (BYTE)findClosestColorIndex2(pal16,sizepal16,rr,gg,bb,colorMatchMode);

		b1 = (color_idx1<<4) & 0xf0;
		b2 = color_idx2 & 0x0f;
		pBmpRaw4[i] = b1 | b2;
	}


	return true;
}

// expand width to 4's multiple
BYTE *bmp24bitWidthExpand(BYTE *pBmp24, DWORD *pSize24, BYTE bR, BYTE bG, BYTE bB){

//bR=255;
//bG=255;
//bB=255;
	//DWORD bmp24_raw_size = *pSize24 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER);
	//DWORD bmp24_raw_size = bmp4_raw_size * 6;

	//if (size24 != bmp24_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)){
	//	return false;
	//}

	//memcpy(bmp24, bmp4, sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

	BYTE *pointer24 = pBmp24;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer24;



	// bmp info header
	pointer24 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer24;



	// no palette
	pointer24 += sizeof(BITMAPINFOHEADER);


	// bmp raw data
	BYTE *pBmpRaw24 = pointer24;


	// create new bmp
	if(pIHeader->biWidth%4==0){
		return pBmp24;
	}

	LONG extra_w = 4 - (pIHeader->biWidth%4);
	size_t oldWidth = pIHeader->biWidth;
	size_t newWidth = oldWidth + extra_w;
	pIHeader->biWidth = newWidth;	
	size_t newsize = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER) + (newWidth * pIHeader->biHeight * 3);

	pFHeader->bfSize = newsize;
	pIHeader->biSizeImage = newsize- sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER);     // unsure

	BYTE *newbmp=NULL;
	newbmp = new BYTE[newsize];
	memset(newbmp,0,newsize);
	memcpy(newbmp,pBmp24,sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

	BYTE *pNewBmpRaw = newbmp+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);


	DWORD bytesInOldRow = oldWidth*3;

	// DWORD-aligned for each row
	DWORD dwordAlignExtra = 0;	// extra dummy bytes for DWORD-aligned
	if(bytesInOldRow%4>0){
		dwordAlignExtra = 4 - (bytesInOldRow%4);
	}

	for(size_t i = 0; i < pIHeader->biHeight; ++i){
		memcpy(pNewBmpRaw, pBmpRaw24, bytesInOldRow);
		pNewBmpRaw += bytesInOldRow;
		pBmpRaw24 += (bytesInOldRow+dwordAlignExtra);
		for(size_t j=0; j < extra_w; ++j){
			*pNewBmpRaw = bB;
			pNewBmpRaw++;
			*pNewBmpRaw = bG;
			pNewBmpRaw++;
			*pNewBmpRaw = bR;
			pNewBmpRaw++;
		}	
	}



*pSize24 = newsize;

if(pBmp24 != NULL){
	delete [] pBmp24;
}
//pBmp24 = &newbmp;


	return newbmp;
}


// expand width to 4's multiple
BYTE *bmp8bitWidthExpand(BYTE *pBmp24, DWORD *pSize24, BYTE bR, BYTE bG, BYTE bB){

//bR=255;
//bG=255;
//bB=255;
	//DWORD bmp24_raw_size = *pSize24 - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER);
	//DWORD bmp24_raw_size = bmp4_raw_size * 6;

	//if (size24 != bmp24_raw_size + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)){
	//	return false;
	//}

	//memcpy(bmp24, bmp4, sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER));

	BYTE *pointer24 = pBmp24;

	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer24;



	// bmp info header
	pointer24 += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer24;



	// no palette
	pointer24 += sizeof(BITMAPINFOHEADER);
	BYTE *pPal256 = pointer24;
	//find background color index
	BYTE bColorIdx = 0;
	bColorIdx =  findClosestColorIndex(pPal256, 4*256, bR,bG,bB, 1);




	// bmp raw data
	pointer24 += 4*256;
	BYTE *pBmpRaw24 = pointer24;


	// create new bmp
	if(pIHeader->biWidth%4==0){
		return pBmp24;
	}

	LONG extra_w = 4 - (pIHeader->biWidth%4);
	size_t oldWidth = pIHeader->biWidth;
	size_t newWidth = oldWidth + extra_w;
	pIHeader->biWidth = newWidth;	
	size_t newsize = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+4*256 + (newWidth * pIHeader->biHeight);

	pFHeader->bfSize = newsize;
	pIHeader->biSizeImage = newsize- sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)-4*256;     // unsure

	BYTE *newbmp=NULL;
	newbmp = new BYTE[newsize];
	memset(newbmp,0,newsize);
	memcpy(newbmp,pBmp24,sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+4*256);

	BYTE *pNewBmpRaw = newbmp+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+4*256;


	DWORD bytesInOldRow = oldWidth;

	// DWORD-aligned for each row
	DWORD dwordAlignExtra = 0;	// extra dummy bytes for DWORD-aligned
	if(bytesInOldRow%4>0){
		dwordAlignExtra = 4 - (bytesInOldRow%4);
	}

	for(size_t i = 0; i < pIHeader->biHeight; ++i){
		memcpy(pNewBmpRaw, pBmpRaw24, bytesInOldRow);
		pNewBmpRaw += bytesInOldRow;
		pBmpRaw24 += (bytesInOldRow+dwordAlignExtra);
		for(size_t j=0; j < extra_w; ++j){
			*pNewBmpRaw = bColorIdx;
			pNewBmpRaw++;
		}	
	}



*pSize24 = newsize;

if(pBmp24 != NULL){
	delete [] pBmp24;
}
//pBmp24 = &newbmp;


	return newbmp;
}


