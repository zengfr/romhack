// Gfx2BmpDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Gfx2Bmp.h"
#include "Gfx2BmpDlg.h"

#include <string>
#include <vector>
#include "tools.h"
#include "Gfx2BmpToolFunc.h"
using namespace std;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CGfx2BmpDlg dialog




CGfx2BmpDlg::CGfx2BmpDlg(CWnd* pParent /*=NULL*/)
: CDialog(CGfx2BmpDlg::IDD, pParent)
, m_intRadio_bpp(0)
, m_nRadio1(0)
, m_nRadio4(0)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGfx2BmpDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_config, m_Static_config);
	DDX_Control(pDX, IDC_STATIC_size, m_Static_size);
	//	DDX_Control(pDX, IDC_STATIC_addr, m_Static_addr);
	//DDX_Control(pDX, IDC_STATIC_len, m_Static_len);
	DDX_Control(pDX, IDC_BUTTON1, m_Button_export);
	DDX_Control(pDX, IDOK, m_Button_exit);
	DDX_Control(pDX, IDC_COMBO1, m_Combo_config);
	DDX_Control(pDX, IDC_COMBO2, m_Combo_size);
	DDX_Control(pDX, IDC_EDIT1, m_Edit_addr);
	DDX_Control(pDX, IDC_EDIT2, m_Edit_len);
	DDX_Control(pDX, IDC_BUTTON2, m_Button_import);
	DDX_Control(pDX, IDC_CHECK1, m_Check_importPal);
	DDX_Radio(pDX, IDC_RADIO1, m_nRadio1);
	DDX_Radio(pDX, IDC_RADIO4, m_nRadio4);
	DDX_Control(pDX, IDC_EDIT3, m_Edit_tileStart);
	DDX_Control(pDX, IDC_EDIT4, m_Edit_tileWidth);
	DDX_Control(pDX, IDC_EDIT5, m_Edit_tileHeight);
	DDX_Control(pDX, IDC_EDIT6, m_Edit_lenHeight);
	DDX_Control(pDX, IDC_EDIT_transcolor, m_Edit_transcolor);
	DDX_Control(pDX, IDC_STATIC_pic, m_Static_pic);
	DDX_Control(pDX, IDC_EDIT8, m_Edit_R);
	DDX_Control(pDX, IDC_EDIT9, m_Edit_G);
	DDX_Control(pDX, IDC_EDIT10, m_Edit_B);
	DDX_Control(pDX, IDC_CHECK2, m_Check_transcolor);
}

BEGIN_MESSAGE_MAP(CGfx2BmpDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CGfx2BmpDlg::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON1, &CGfx2BmpDlg::OnBnClickedButton1)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CGfx2BmpDlg::OnCbnSelchangeCombo1)
	ON_CBN_DROPDOWN(IDC_COMBO1, &CGfx2BmpDlg::OnCbnDropdownCombo1)
	ON_CBN_DROPDOWN(IDC_COMBO2, &CGfx2BmpDlg::OnCbnDropdownCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO2, &CGfx2BmpDlg::OnCbnSelchangeCombo2)
	ON_BN_CLICKED(IDC_BUTTON2, &CGfx2BmpDlg::OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, &CGfx2BmpDlg::OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, &CGfx2BmpDlg::OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, &CGfx2BmpDlg::OnBnClickedButton5)
	ON_WM_CTLCOLOR()
END_MESSAGE_MAP()


// CGfx2BmpDlg message handlers

BOOL CGfx2BmpDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	// load string 
	CString cs;
	cs.LoadStringW(129);
	m_Static_config.SetWindowTextW(cs);

	cs.LoadStringW(130);
	m_Static_size.SetWindowTextW(cs);

	//cs.LoadStringW(131);
	//m_Static_addr.SetWindowTextW(cs);

	//cs.LoadStringW(132);
	//m_Static_len.SetWindowTextW(cs);

	cs.LoadStringW(133);
	m_Button_export.SetWindowTextW(cs);

	cs.LoadStringW(134);
	m_Button_exit.SetWindowTextW(cs);

	cs.LoadStringW(135);
	m_Button_import.SetWindowTextW(cs);

	cs.LoadStringW(136);
	m_Check_importPal.SetWindowTextW(cs);

	OnCbnDropdownCombo1();
	m_Combo_config.SetCurSel(0);
	OnCbnSelchangeCombo1();

	OnCbnDropdownCombo2();
	m_Combo_size.SetCurSel(0);
	OnCbnSelchangeCombo2();

	//m_Edit_addr.SetWindowTextW(TEXT("0"));
	//m_Edit_len.SetWindowTextW(TEXT("128"));
	//m_Edit_lenHeight.SetWindowTextW(TEXT("128"));
	m_Edit_tileStart.SetWindowTextW(TEXT("0"));
	m_Edit_tileWidth.SetWindowTextW(TEXT("16"));
	m_Edit_tileHeight.SetWindowTextW(TEXT("16"));


	// radio button init
	m_nRadio1 = 2;	// select 24-bit bmp
	m_nRadio4 = 0;	// color match mode
	UpdateData(false);



	//// picture
	//CStatic   *pStatic   =   (CStatic  *)GetDlgItem(IDC_STATIC_pic);//���xIDC_SHOW�@��picture control���
	//CDC *pDC = pStatic->GetDC();//pDC�����pStatic�@�������device
	//CRect rct;//����һ����������ϵ,���ϽǞ�(0,0) ��������(x,y)�f��
	//pStatic->GetWindowRect(&rct);//ץ��pStatic�@������ڮ����ϵĹ���
	//CBrush brs;//���x�Pˢʹ��e
	////����һ���Pˢ �e�^RGB��ֵ Ո���Ѕ��ɫ�a�� 
	//brs.CreateSolidBrush(RGB(255, 0, 0));

	//CRect picrct;//���xһ������picrct�ľ�������ϵ ׌���Ĺ����cIDC_SHOW�@��picture control��С��ͬ
	//picrct.top = 0;
	//picrct.left = 0;
	//picrct.bottom = rct.Height();
	//picrct.right = rct.Width();
	//pDC->FillRect(&picrct, &brs);//�����ɫ


	m_Edit_R.SetWindowTextW(TEXT("255"));
	m_Edit_G.SetWindowTextW(TEXT("0"));
	m_Edit_B.SetWindowTextW(TEXT("252"));


	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGfx2BmpDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGfx2BmpDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CGfx2BmpDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	OnOK();
}


// export bmp
void CGfx2BmpDlg::OnBnClickedButton1()
{
	/*
	// open
	CFileDialog pCFileDialog(true,NULL,NULL,0,TEXT("ALL(*.*)|*.*||"));
	//CFileDialog pCFileDialog(true,NULL,NULL,0,TEXT("ALL(*.*)|*.*||"));
	//CFileDialog pCFileDialog���һ�������Ǵ��ļ��Ի����ɸѡ������,�����ļ�·��
	pCFileDialog.m_ofn.lpstrTitle = TEXT("ѡ���ļ�");  

	if(pCFileDialog.DoModal()!=IDOK)
	{
	return;
	}
	CString filename = pCFileDialog.GetPathName();

	// read file data
	CFile* cFile = NULL;
	DWORD filesize=0;
	BYTE *codedata = NULL;
	cFile = new CFile();
	cFile->Open( filename, CFile::modeRead | CFile::typeBinary);
	filesize = (DWORD)cFile->GetLength();
	codedata = new BYTE[filesize];
	UINT bytesRead=cFile->Read(codedata, filesize);
	cFile->Close();
	delete cFile;
	*/


	// read config file and pal
	if(!readConfig()){
		AfxMessageBox(TEXT("��ȡ�����ļ�ʧ��"));
		return;
	}
	if(!readPal()){
		AfxMessageBox(TEXT("��ȡɫ��ʧ��"));
		return;
	}


	if(!gfxMerge()){
		AfxMessageBox(TEXT("Rom �ϲ�ʧ��"));
		return;
	}

	DWORD filesize=0;
	DWORD offset=0;
	CString strtmpC;
	string strtmp;

	// tiles start number (hex)
	DWORD tilesStart=0;
	m_Edit_tileStart.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	if(!HexStringToDword(strtmp, &tilesStart)){
		AfxMessageBox(TEXT("not a hex"));
		return;
	}

	// tiles width number
	DWORD tilesWidth=0;
	m_Edit_tileWidth.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	tilesWidth = atoi(strtmp.c_str());
	if(tilesWidth > tn - (tilesStart%tn))
		tilesWidth = tn - (tilesStart%tn);
	if(tilesWidth < 1)
		tilesWidth = 1;


	// tiles hieght number
	DWORD tilesHeight=0;
	m_Edit_tileHeight.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	tilesHeight = atoi(strtmp.c_str());
	if(tilesHeight < 1)
		tilesHeight = 1;

	//printHex(tilesStart);
	//printInt(tilesWidth);
	//printInt(tilesHeight);

	// tile start address
	//m_Edit_addr.GetWindowTextW(strtmpC);
	//strtmp = CStringA(strtmpC);
	//if(!HexStringToDword(strtmp, &offset)){
	//	AfxMessageBox(TEXT("not a hex"));
	//	return;
	//}
	offset = (tilesStart/tn)*tn * tw*th/2;


	// byte length
	//m_Edit_len.GetWindowTextW(strtmpC);
	//strtmp = CStringA(strtmpC);
	//if(!HexStringToDword(strtmp, &filesize)){
	//	AfxMessageBox(TEXT("not a hex"));
	//	return;
	//}

	DWORD tileRowBytes = tw*th*tn/2; // one pixel = half byte
	filesize = tileRowBytes * tilesHeight;
	//if(filesize%tileRowBytes>0){
	//	filesize=(filesize/tileRowBytes+1)*tileRowBytes;
	//}

	if(offset+filesize>gfxsize){
		AfxMessageBox(TEXT("exceed gfx size"));
		return;
	}

	//printHex(offset);
	//printHex(filesize);


	BYTE *gfxpointer = gfxdata + offset;

	//filesize=gfxsize;

	//printHex(gfxsize);
	//printHex(palsize);
	//for(size_t kkk=0;kkk<palsize;++kkk){
	//	printHex((DWORD)paldata[kkk]);
	//}


	//DWORD tw = 32;	// tile width
	//DWORD th = 32;	// tile height
	//DWORD tn = 16;	// number of tiles in one line

	// 8x8 has 2 sets
	//DWORD tw = 8;	// tile width
	//DWORD th = 8;	// tile height
	//DWORD tn = 16;	// number of tiles in one line


	// create 4 bit bitmap
	DWORD pal_num = 16;
	DWORD bmp_raw_size = (tw*tilesWidth)*(th*tilesHeight)/2;
	DWORD bmpsize = bmp_raw_size+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ pal_num * sizeof(tagPALETTEENTRY);
	BYTE *bmpdata = NULL;
	bmpdata = new BYTE[bmpsize];
	memset(bmpdata,0,bmpsize);

	BYTE *pointer = bmpdata;
	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer;
	pFHeader->bfType = 0x4d42; // "BM"
	pFHeader->bfSize = bmpsize;
	pFHeader->bfReserved1=0;
	pFHeader->bfReserved2=0;
	pFHeader->bfOffBits = bmpsize - bmp_raw_size;


	// bmp info header
	pointer += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer;
	pIHeader->biSize = sizeof(BITMAPINFOHEADER);
	//pIHeader->biWidth = tw*tn; // (tile pixel width) * (16 tiles per line) 
	//pIHeader->biHeight = filesize*2/pIHeader->biWidth;
	pIHeader->biWidth = tw*tilesWidth; 
	pIHeader->biHeight = th*tilesHeight;
	pIHeader->biPlanes = 1;
	pIHeader->biBitCount = 4;
	pIHeader->biCompression = 0;
	pIHeader->biSizeImage = bmp_raw_size;     // unsure
	pIHeader->biXPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biYPelsPerMeter = 0; // 0x0ec4; // unsure
	pIHeader->biClrUsed = 0;// unsure
	pIHeader->biClrImportant = 0;// unsure

	// palette
	pointer += sizeof(BITMAPINFOHEADER);

	//BYTE default_pal[64] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x80, 0x00, 0x80, 0x00, 0x00, 0x00, 0x80, 0x00, 0x80, 0x00, 0x80, 0x80, 0x00, 0x00, 0x80, 0x80, 0x80, 0x00, 0xC0, 0xC0, 0xC0, 0x00, 0x00, 0x00, 0xFF, 0x00, 0x00, 0xFF, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0xFF, 0x00, 0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00, 0xFF, 0xFF, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0x00};
	memcpy(pointer,paldata,64);


	// bmp raw data
	pointer += pal_num * sizeof(tagPALETTEENTRY);
	//BYTE *pBmpRaw = pointer;

	// rom_16bit_byteswap
	if(rom_16bit_byteswap == true){
		size_t ite=filesize/2;
		BYTE btmp;
		for(size_t i=0;i<ite;++i){
			btmp = gfxpointer[i*2];
			gfxpointer[i*2] = gfxpointer[i*2+1];
			gfxpointer[i*2+1] = btmp;
		}
	}

	// decode (copy from http://www.mamedev.org/source/src/mame/video/cps1.c.html line 1702)
	if(codec==1){
		cps1_gfx_decode((UINT8 *)gfxpointer,filesize);
	}

	// convert tiled gfx to bmp
	BYTE *pBmpRaw = NULL;
	pBmpRaw = new BYTE[filesize];
	memset(pBmpRaw,0,filesize);
	DWORD pixelRowBytes = tn*tw/2;
	for (DWORD i = 0; i < filesize; ++i){

		DWORD tile_idx = i/(tw*th/2);
		DWORD byte_idx_in_tile = i%(tw*th/2);
		DWORD y = (tile_idx/tn)*th + byte_idx_in_tile/(tw/2);
		DWORD x = (tile_idx%tn)*(tw/2) + (byte_idx_in_tile%(tw/2));

		y = pIHeader->biHeight - y - 1;

		//DWORD k = y*pIHeader->biWidth/2 + x;
		DWORD k = y*pixelRowBytes + x;

		*(pBmpRaw+k) = ((gfxpointer[i] & 0x0f)<<4) | ((gfxpointer[i] & 0xf0)>>4);
	}

	// crop tiles out of bmp raw data
	DWORD tilesStartOffset = (tilesStart%tn) * tw/2;
	DWORD tilesWidthBytes = tilesWidth * tw/2;
	for(DWORD i = 0; i < tilesHeight*th; ++i){
		memcpy(pointer + tilesWidthBytes*i, pBmpRaw + pixelRowBytes*i + tilesStartOffset, tilesWidthBytes);
	}
	delete [] pBmpRaw;



	int bpp = 4; // bits per pixel
	UpdateData(true);
	if(m_nRadio1==0){
		bpp = 4;
	}else if(m_nRadio1==1){
		bpp = 8;
	}else if(m_nRadio1==2){
		bpp = 24;
	}

	// bmp conversion
	BYTE *bmp2data = NULL;
	DWORD bmp2size = 0;

	if(bpp == 8){
		// convert 4-bit bmp to 8-bit bmp
		bmp2size = (bmpsize - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*16)*2 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*256;
		bmp2data = new BYTE[bmp2size];
		memset(bmp2data,0,bmp2size);

		if(!bmp4bitTo8bit(bmpdata,bmpsize,bmp2data,bmp2size)){
			AfxMessageBox(TEXT("bmp conversion error"));
			return;
		}
	}else if(bpp == 24){
		// convert 4-bit bmp to 24-bit bmp
		bmp2size = (bmpsize - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*16)*6 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER);
		bmp2data = new BYTE[bmp2size];
		memset(bmp2data,0,bmp2size);

		if(!bmp4bitTo24bit(bmpdata,bmpsize,bmp2data,bmp2size)){
			AfxMessageBox(TEXT("bmp conversion error"));
			return;
		}
	}else{
		// 4-bit, no change
		bmp2data = bmpdata;
		bmp2size = bmpsize;
	}





	// save
	CFileDialog pCFileDialogS(false,NULL,NULL,0,TEXT("BMP(*.bmp)|*.bmp|ALL(*.*)|*.*||"));
	//CFileDialog pCFileDialog���һ�������Ǵ��ļ��Ի����ɸѡ������,�����ļ�·��
	pCFileDialogS.m_ofn.lpstrTitle = TEXT("�����ļ�");  

	if(pCFileDialogS.DoModal()!=IDOK)
	{
		return;
	}
	CString filepathnameS = pCFileDialogS.GetPathName();
	CString ext = pCFileDialogS.GetFileExt();
	if(ext.GetLength()<=0){
		filepathnameS += TEXT(".bmp");
	}

	//AfxMessageBox(filepathnameS);
	//saveFile(filepathname);

	// save file data
	CFile* cFile = NULL;
	//cFile = NULL;
	cFile = new CFile();
	cFile->Open( filepathnameS, CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	//	cFile->Write(bmpdata,bmpsize);
	cFile->Write(bmp2data,bmp2size);
	cFile->Close();
	delete cFile;





	if(paldata!=NULL){
		delete [] paldata;
		paldata = NULL;
		palsize = 0;
	}
	if(gfxdata!=NULL){
		delete [] gfxdata;
		gfxdata = NULL;
		gfxsize = 0;
	}
	if(bmpdata!=NULL){
		delete [] bmpdata;
		bmpdata = NULL;
		bmpsize = 0;
	}
	if(bmp2data!=NULL){
		if(bpp!=4)
			delete [] bmp2data;
		bmp2data = NULL;
		bmp2size = 0;
	}

}




// config combobox drop down
void CGfx2BmpDlg::OnCbnDropdownCombo1()
{
	m_Combo_config.ResetContent();


	getConfigFiles();
	for(int i = 0; i < configfiles.size(); i++){

		m_Combo_config.AddString(configfiles[i].filetitle);
		//m_Combo_config.AddString(configfiles[i].filepathname);
		//m_Combo_config.AddString(configfiles[i].filename);


	}
}

// config combobox selection changed
void CGfx2BmpDlg::OnCbnSelchangeCombo1()
{
	UpdateData(FALSE);

	//��ȡComboBox�ĵ�ǰֵ
	int n = m_Combo_config.GetCurSel();                             //��ǰѡ�е�Ԫ������
	CString name;
	m_Combo_config.GetLBText(n,name);    //��ǰѡ�е��ַ���

	for(size_t i=0;i<configfiles.size();++i){
		if(configfiles[i].filetitle.Compare(name)==0)
			configfile_idx=i;
	}
	//AfxMessageBox(filename);

}




// tile size combobox drop down
void CGfx2BmpDlg::OnCbnDropdownCombo2()
{
	m_Combo_size.ResetContent();

	m_Combo_size.AddString(TEXT("16x16"));
	m_Combo_size.AddString(TEXT("32x32"));
	m_Combo_size.AddString(TEXT("8x8"));
}

// tile size combobox selection changed
void CGfx2BmpDlg::OnCbnSelchangeCombo2()
{
	UpdateData(FALSE);


	//��ȡComboBox�ĵ�ǰֵ
	int iPos = m_Combo_size.GetCurSel();                             //��ǰѡ�е�Ԫ������

	if(iPos == 0){	
		tw = 16;	// tile width
		th = 16;	// tile height
		tn = 16;	// number of tiles in one line
	}else if(iPos == 1){
		tw = 32;	// tile width
		th = 32;	// tile height
		tn = 16;	// number of tiles in one line   
	}else{
		tw = 8;	// tile width
		th = 8;	// tile height
		//tn = 16;	// number of tiles in one line
		tn = 32;	// number of tiles in one line
	}
}




// import bmp
void CGfx2BmpDlg::OnBnClickedButton2()
{

	// open
	CFileDialog pCFileDialog(true,NULL,NULL,0,TEXT("BMP(*.bmp)|*.bmp|ALL(*.*)|*.*||"));
	pCFileDialog.m_ofn.lpstrTitle = TEXT("ѡ��BMP�ļ�");  

	if(pCFileDialog.DoModal()!=IDOK)
	{
		return;
	}
	CString bmpfilename = pCFileDialog.GetPathName();

	// read file data
	CFile* cFile = NULL;
	DWORD bmp2size=0;
	BYTE *bmp2data = NULL;
	cFile = new CFile();
	cFile->Open( bmpfilename, CFile::modeRead | CFile::typeBinary);
	bmp2size = (DWORD)cFile->GetLength();
	bmp2data = new BYTE[bmp2size];
	UINT bytesRead=cFile->Read(bmp2data, bmp2size);
	cFile->Close();
	delete cFile;



	CString strtmpC;
	string strtmp;

	// tiles start number (hex)
	DWORD tilesStart=0;
	m_Edit_tileStart.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	if(!HexStringToDword(strtmp, &tilesStart)){
		AfxMessageBox(TEXT("not a hex"));
		return;
	}

	// tiles width number
	DWORD tilesWidth=0;
	m_Edit_tileWidth.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	tilesWidth = atoi(strtmp.c_str());
	if(tilesWidth > tn - (tilesStart%tn))
		tilesWidth = tn - (tilesStart%tn);
	if(tilesWidth < 1)
		tilesWidth = 1;


	// tiles hieght number
	DWORD tilesHeight=0;
	m_Edit_tileHeight.GetWindowTextW(strtmpC);
	strtmp = CStringA(strtmpC);
	tilesHeight = atoi(strtmp.c_str());
	if(tilesHeight < 1)
		tilesHeight = 1;

	// transparent color
	useTransColor = false;
	if(m_Check_transcolor.GetCheck() == BST_CHECKED)
		useTransColor = true;
	if(useTransColor){
		m_Edit_R.GetWindowTextW(strtmpC);
		strtmp = CStringA(strtmpC);
		transR = atoi(strtmp.c_str());
		if(transR > 255)
			transR = 255;
		if(transR < 0)
			transR = 0;


		m_Edit_G.GetWindowTextW(strtmpC);
		strtmp = CStringA(strtmpC);
		transG = atoi(strtmp.c_str());
		if(transG > 255)
			transG = 255;
		if(transG < 0)
			transG = 0;


		m_Edit_B.GetWindowTextW(strtmpC);
		strtmp = CStringA(strtmpC);
		transB = atoi(strtmp.c_str());
		if(transB > 255)
			transB = 255;
		if(transB < 0)
			transB = 0;

		//printInt(transR);
		//printInt(transG);
		//printInt(transB);
	}

	// read config file and pal
	if(!readConfig()){
		AfxMessageBox(TEXT("��ȡ�����ļ�ʧ��"));
		return;
	}
	if(!readPal()){
		AfxMessageBox(TEXT("��ȡɫ��ʧ��"));
		return;
	}

	// background color
	BYTE bB = paldata[15*4];
	BYTE bG = paldata[15*4+1];
	BYTE bR = paldata[15*4+2];


	// check color match mode
	int colorMatchMode = 0;
	UpdateData(true);
	colorMatchMode = m_nRadio4;

	// check if it's a bmp
	if(*(bmp2data) != 0x42 | *(bmp2data+1) != 0x4d){
		AfxMessageBox(TEXT("ֻ֧��BMP��ʽ"));
		return;
	}

	// check bmp Compression value
	if(*(bmp2data+0x1e) != 0){
		AfxMessageBox(TEXT("��֧��ѹ��BMP"));
		return;
	}

	// check bmp bpp (bits per pixel)
	BYTE *bmpdata = NULL;
	DWORD bmpsize = 0;
	BYTE bpp = *(bmp2data+0x1c);
	if(bpp == 4){
		bmpdata = bmp2data;
		bmpsize = bmp2size;

	}else if(bpp == 8){
		// ����������չΪ 4 pixel �ı���
		bmp2data = bmp8bitWidthExpand(bmp2data,&bmp2size, bR,bG,bB);

		// convert 8-bit bmp to 4-bit bmp
		bmpsize = (bmp2size - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER)- 4*256)/2 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*16;
		bmpdata = new BYTE[bmpsize];
		memset(bmpdata,0,bmpsize);
		if(!bmp8bitTo4bit(bmp2data,bmp2size,bmpdata,bmpsize,paldata,palsize,colorMatchMode)){
			AfxMessageBox(TEXT("BMPת��ʧ��"));
			return;
		}
	}else if(bpp == 24){

		// ����������չΪ 4 pixel �ı���
		bmp2data = bmp24bitWidthExpand(bmp2data,&bmp2size, bR,bG,bB);

	//// save file data
	//CFile* fin = NULL;
	//fin = new CFile();
	//fin->Open( TEXT("temp.bmp"), CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	//fin->Write(bmp2data,bmp2size);
	//fin->Close();
	//delete fin;

		// convert 24-bit bmp to 4-bit bmp
		bmpsize = (bmp2size - sizeof(BITMAPFILEHEADER)-sizeof(BITMAPINFOHEADER))/6 + sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+ 4*16;
		bmpdata = new BYTE[bmpsize];
		memset(bmpdata,0,bmpsize);
		if(!bmp24bitTo4bit(bmp2data,bmp2size,bmpdata,bmpsize,paldata,palsize,colorMatchMode)){
			AfxMessageBox(TEXT("BMPת��ʧ��"));
			return;
		}
	}else{
		AfxMessageBox(TEXT("ֻ֧��4-bit, 8-bit,��24-bit BMP��ʽ"));
		return;
	}

	// check if it's 4-bit bitmap
	BYTE *pointer = bmpdata;
	// bmp file header
	BITMAPFILEHEADER *pFHeader = (BITMAPFILEHEADER *)pointer;
	if(pFHeader->bfType != 0x4d42){  // "BM"
		AfxMessageBox(TEXT("bmp file error"));
		return;
	}

	DWORD offsetToBmpRaw = pFHeader->bfOffBits; 
	DWORD bmp_raw_size = bmpsize - offsetToBmpRaw;

	// bmp info header
	pointer += sizeof(BITMAPFILEHEADER);
	BITMAPINFOHEADER *pIHeader = (BITMAPINFOHEADER *)pointer;
//printInt(pIHeader->biWidth);
	if(pIHeader->biWidth % 4 != 0){ // (tile pixel width) * (16 tiles per line) 
		AfxMessageBox(TEXT("BMP֮����(PIXEL)���ȱ�����4�ı���"));
		return;
	}
	if(pIHeader->biWidth > tw*tilesWidth){ // (tile pixel width) * (16 tiles per line) 
		AfxMessageBox(TEXT("BMP���ȳ���ש���ꇿ���"));
		return;
	}
	if(pIHeader->biHeight > th*tilesHeight){
		AfxMessageBox(TEXT("BMP�߶ȳ���ש���ꇸ߶�"));
		return;
	}
	if(pIHeader->biBitCount != 4){	// 4-bit bmp (16 colors)
		AfxMessageBox(TEXT("bmp file error"));
		return;
	}

	// palette
	pointer += sizeof(BITMAPINFOHEADER);
	BYTE *pPal = pointer;

	// bmp raw data
	//pointer += pal_num * sizeof(tagPALETTEENTRY);
	pointer = bmpdata + offsetToBmpRaw;
	//BYTE *pBmpRaw = pointer;


	// get original gfx
	if(!gfxMerge()){
		AfxMessageBox(TEXT("gfx merge failed"));
		return;
	}

	DWORD gfx_offset=0;
	//CString edittmpC;
	//string edittmp;
	//m_Edit_addr.GetWindowTextW(edittmpC);
	//edittmp = CStringA(edittmpC);
	//if(!HexStringToDword(edittmp, &gfx_offset)){
	//	AfxMessageBox(TEXT("not a hex"));
	//	return;
	//}

	gfx_offset = (tilesStart/tn)*tn * tw*th/2;

	DWORD tileRowBytes = tw*th*tn/2; // one pixel = half byte
	DWORD bmp_raw_sizeEX = tileRowBytes * tilesHeight;

	//if(bmp_raw_size%tileRowBytes>0){
	//	bmp_raw_size=bmp_raw_size/tileRowBytes*tileRowBytes;
	//}

	if(gfx_offset+bmp_raw_sizeEX>gfxsize){
		AfxMessageBox(TEXT("exceed gfx size"));
		return;
	}

	BYTE *pBmpRaw = NULL;
	pBmpRaw = new BYTE[bmp_raw_sizeEX];
	memset(pBmpRaw,0xff,bmp_raw_sizeEX);
	//BYTE *gfxpointer = gfxdata + gfx_offset;
	DWORD pixelRowBytes = tn*tw/2;
	//for (DWORD i = 0; i < bmp_raw_sizeEX; ++i){

	//	DWORD tile_idx = i/(tw*th/2);
	//	DWORD byte_idx_in_tile = i%(tw*th/2);
	//	DWORD y = (tile_idx/tn)*th + byte_idx_in_tile/(tw/2);
	//	DWORD x = (tile_idx%tn)*(tw/2) + (byte_idx_in_tile%(tw/2));

	//	y = pIHeader->biHeight - y - 1;

	//	//DWORD k = y*pIHeader->biWidth/2 + x;
	//	DWORD k = y*pixelRowBytes + x;

	//	*(pBmpRaw+k) = ((gfxpointer[i] & 0x0f)<<4) | ((gfxpointer[i] & 0xf0)>>4);
	//}

	// decode (copy from http://www.mamedev.org/source/src/mame/video/cps1.c.html line 1702)
	//cps1_gfx_decode((UINT8 *)codedata,filesize);
	//cps1_gfx_decode((UINT8 *)pBmpRaw,bmp_raw_sizeEX);




	// copy to expanded bmp raw data
	DWORD tilesStartOffset = (tilesStart%tn) * tw/2;
	DWORD actualWidthBytes = pIHeader->biWidth/2;
	//for(DWORD i = pIHeader->biHeight - 1; i >= 0; --i){
	//	memcpy(pBmpRaw + pixelRowBytes*(i+th*tilesHeight-pIHeader->biHeight) + tilesStartOffset, pointer + actualWidthBytes*i, actualWidthBytes);
	//}
	for(DWORD i = 0; i < pIHeader->biHeight; ++i){
		//���϶���
		//memcpy(pBmpRaw + pixelRowBytes*(i+th*tilesHeight-pIHeader->biHeight) + tilesStartOffset, pointer + actualWidthBytes*i, actualWidthBytes);
		//���¶���
		memcpy(pBmpRaw + pixelRowBytes*i + tilesStartOffset, pointer + actualWidthBytes*i, actualWidthBytes);
	}

	//// encode the new part
	////cps1_gfx_encode((UINT8 *)gfxpointer,bmp_raw_size);
	//cps1_gfx_encode((UINT8 *)pBmpRaw,bmp_raw_sizeEX);


	BYTE *gfxpointer = gfxdata + gfx_offset;
	//*gfxpointer = NULL;
	//gfxpointer = new BYTE[bmp_raw_sizeEX];
	//memset(gfxpointer,0,bmp_raw_sizeEX);

	// rom_16bit_byteswap
	if(rom_16bit_byteswap == true){
		size_t ite=bmp_raw_sizeEX/2;
		BYTE btmp;
		for(size_t i=0;i<ite;++i){
			btmp = gfxpointer[i*2];
			gfxpointer[i*2] = gfxpointer[i*2+1];
			gfxpointer[i*2+1] = btmp;
		}
	}

	if(codec==1){
		cps1_gfx_decode((UINT8 *)gfxpointer,bmp_raw_sizeEX);
	}

	// reverse bmp to tiled gfx
	DWORD tilesWidthBytes = tilesWidth * tw/2;
	for (DWORD i = 0; i < bmp_raw_sizeEX; ++i){

		DWORD tile_idx = i/(tw*th/2);
		DWORD byte_idx_in_tile = i%(tw*th/2);
		DWORD y = (tile_idx/tn)*th + byte_idx_in_tile/(tw/2);
		DWORD x = (tile_idx%tn)*(tw/2) + (byte_idx_in_tile%(tw/2));

		//y = pIHeader->biHeight - y - 1;
		y = th*tilesHeight - y - 1;

		//if(x>=tilesStartOffset && x<(tilesStartOffset+actualWidthBytes) && y>=(th*tilesHeight-pIHeader->biHeight)){
		if(x>=tilesStartOffset && x<(tilesStartOffset+tilesWidthBytes)){
			//DWORD k = y*pIHeader->biWidth/2 + x;
			DWORD k = y*pixelRowBytes + x;

			gfxpointer[i] = ((pBmpRaw[k] & 0x0f)<<4) | ((pBmpRaw[k] & 0xf0)>>4);
		}
	}

	// crop tiles out of bmp raw data
	//DWORD tilesWidthBytes = tilesWidth * tw/2;
	//for(DWORD i = 0; i < tilesHeight*th; ++i){
	//	memcpy(gfxdata + gfx_offset + tilesWidthBytes*i, gfxpointer + pixelRowBytes*i + tilesStartOffset, tilesWidthBytes);
	//}
	delete [] pBmpRaw;
	//delete [] gfxpointer;


	//// encode the new part
	if(codec==1){
		cps1_gfx_encode((UINT8 *)gfxpointer,bmp_raw_sizeEX);
	}


	// write new palette
	// get new palette
	alsoImportPal=false;
	if(m_Check_importPal.GetCheck()==1){
		if(paldata!=NULL)
			delete [] paldata;
		paldata = NULL;
		paldata = new BYTE[64];
		memset(paldata, 0, 64);
		memcpy(paldata,pPal,64);
		palsize=64;
		alsoImportPal=true;

		if(!writePal()){
			AfxMessageBox(TEXT("д��ɫ��ʧ��"));
			return;
		}
	}


	// write to gfx roms
	if(!gfxSplit()){
		AfxMessageBox(TEXT("failed to split gfx"));
		return;
	}



	if(paldata!=NULL){
		delete [] paldata;
		paldata = NULL;
		palsize = 0;
	}
	if(gfxdata!=NULL){
		delete [] gfxdata;
		gfxdata = NULL;
		gfxsize = 0;
	}
	if(bmpdata!=NULL){
		delete [] bmpdata;
		bmpdata = NULL;
		bmpsize = 0;
	}
	if(bmp2data!=NULL){
		if(bpp!=4)
			delete [] bmp2data;
		bmp2data = NULL;
		bmp2size = 0;
	}


}

// ֻ����ϲ��� Rom
void CGfx2BmpDlg::OnBnClickedButton3()
{

	// read config file
	if(!readConfig()){
		AfxMessageBox(TEXT("��ȡ�����ļ�ʧ��"));
		return;
	}

	// �ϲ�
	if(!gfxMerge()){
		AfxMessageBox(TEXT("Rom �ϲ�ʧ��"));
		return;
	}

	if(gfxdata == NULL || gfxsize == 0){
		AfxMessageBox(TEXT("Rom �ϲ�ʧ��"));
		return;
	}

	// select save file
	CFileDialog pCFileDialogS(false,NULL,NULL,0,TEXT("ALL(*.*)|*.*||"));
	//CFileDialog pCFileDialog���һ�������Ǵ��ļ��Ի����ɸѡ������,�����ļ�·��
	pCFileDialogS.m_ofn.lpstrTitle = TEXT("����ϲ���Rom");  

	if(pCFileDialogS.DoModal()!=IDOK)
	{
		return;
	}
	CString filepathnameS = pCFileDialogS.GetPathName();


	// save file data
	CFile* cFile = NULL;
	cFile = new CFile();
	cFile->Open( filepathnameS, CFile::modeCreate|CFile::modeWrite | CFile::typeBinary);
	cFile->Write(gfxdata,gfxsize);
	cFile->Close();
	delete cFile;


	if(gfxdata!=NULL){
		delete [] gfxdata;
		gfxdata = NULL;
		gfxsize = 0;
	}

}

void CGfx2BmpDlg::OnBnClickedButton4()
{

	// read config file
	if(!readConfig()){
		AfxMessageBox(TEXT("��ȡ�����ļ�ʧ��"));
		return;
	}

	// open
	CFileDialog pCFileDialog(true,NULL,NULL,0,TEXT("ALL(*.*)|*.*||"));
	pCFileDialog.m_ofn.lpstrTitle = TEXT("ѡ��Rom���зָ�");  

	if(pCFileDialog.DoModal()!=IDOK)
	{
		return;
	}
	CString filename = pCFileDialog.GetPathName();

	gfxdata = NULL;
	gfxsize=0;

	// read file data
	CFile* cFile = NULL;
	cFile = new CFile();
	cFile->Open( filename, CFile::modeRead | CFile::typeBinary);
	gfxsize = (DWORD)cFile->GetLength();
	gfxdata = new BYTE[gfxsize];
	UINT bytesRead=cFile->Read(gfxdata, gfxsize);
	cFile->Close();
	delete cFile;


	// write to gfx roms
	if(!gfxSplit()){
		AfxMessageBox(TEXT("�ָ�ʧ��"));
		return;
	}


	if(gfxdata!=NULL){
		delete [] gfxdata;
		gfxdata = NULL;
		gfxsize = 0;
	}

}




void CGfx2BmpDlg::OnBnClickedButton5()
{
	// Get the selected color from the CColorDialog.
	CColorDialog dlg;
	if (dlg.DoModal() == IDOK)
	{
		COLORREF color = dlg.GetColor();
		//TRACE("RGB value of the selected color - red = %u, 
		//   green = %u, blue = %u\n",
		//   GetRValue(color), GetGValue(color), GetBValue(color));
		//  printInt(GetRValue(color));
		//  printInt(GetGValue(color));
		//  printInt(GetBValue(color));

		transR=GetRValue(color);
		transG=GetGValue(color);
		transB=GetBValue(color);

		//tcBrush = new CBrush(color);
		//tcBrush = new CBrush(RGB(49,49,49));


		CStatic   *pStatic   =   (CStatic  *)GetDlgItem(IDC_STATIC_pic);//���xIDC_SHOW�@��picture control���
		CDC *pDC = pStatic->GetDC();//pDC�����pStatic�@�������device
		CRect rct;//����һ����������ϵ,���ϽǞ�(0,0) ��������(x,y)�f��
		pStatic->GetWindowRect(&rct);//ץ��pStatic�@������ڮ����ϵĹ���
		CBrush brs;//���x�Pˢʹ��e
		//����һ���Pˢ �e�^RGB��ֵ Ո���Ѕ��ɫ�a�� 
		brs.CreateSolidBrush(color);

		CRect picrct;//���xһ������picrct�ľ�������ϵ ׌���Ĺ����cIDC_SHOW�@��picture control��С��ͬ
		picrct.top = 0;
		picrct.left = 0;
		picrct.bottom = rct.Height();
		picrct.right = rct.Width();
		pDC->FillRect(&picrct, &brs);//�����ɫ



	}
	//printInt(m_Edit_transcolor.GetDlgCtrlID());
}

HBRUSH CGfx2BmpDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	return hbr;
	//UINT cid = (UINT)m_Edit_transcolor.GetDlgCtrlID();
	//switch (nCtlColor) {
	//
	//	case IDC_STATIC4:
	//		pDC->SetTextColor(RGB(0, 255, 0));
	//		pDC->SetBkColor(RGB(255, 0, 0));
	//		return (HBRUSH)(tcBrush->GetSafeHandle());
	//	default:
	//		//pDC->SetTextColor(RGB(0, 255, 0));
	//		//pDC->SetBkColor(RGB(255, 0, 0));
	//		//return (HBRUSH)(tcBrush->GetSafeHandle());
	//		return CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	//	}

	//if ((CTLCOLOR_EDIT == nCtlColor) &&
	//    (IDC_STATIC_pic == pWnd->GetDlgCtrlID()))
	//{
	//    return (HBRUSH)(tcBrush->GetSafeHandle()); //Create this brush in OnInitDialog() and destroy in destructor
	//}
	//return CDialog::OnCtlColor(pDC, pWnd, nCtlColor);


}
