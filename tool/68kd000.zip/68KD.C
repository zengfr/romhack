/*
 * 68kd: 68000/68010 Disassembler
 * Bart Trzynadlowski, April 19, 2002
 */

/*
 * 68kd.c
 *
 * Stand-alone disassembler
 */

#include <stdio.h>
#include <stdlib.h>
#include "dis_68k.h"

#define VERSION "0.0"


/*****************************************************************************
 Ye Olde DOS (or UNIX, Win32 console, etc.) Code
*****************************************************************************/

void ByteSwapMemory(UINT8 *mem, UINT32 size)
{
    INT32   i;
    UINT8   j;

    for (i = 0; i < size; i += 2)
    {
        j = mem[i];
        mem[i] = mem[i + 1];
        mem[i + 1] = j;
    }
}

void ShowHelp()
{
    puts("68kd Version "VERSION" by Bart Trzynadlowski: 68000/68010 Disassembler");
    puts("Usage:    68kd <file> [options]");
    puts("Options:  -?,-h       Show this help text");
    puts("          -s <offset> Start offset (hexadecimal)");
    puts("          -l <num>    Number of bytes (hexadecimal)");
    puts("          -o <addr>   Set origin (hexadecimal)");
    exit(0);
}

/*
 * main()
 */

int main(int argc, char **argv)
{
    char    dis_op[64], dis_inst[32], dis_arg[24];
    UINT32  start_addr = 0, org = 0, do_org = 0, len = 0, fsize, i, j, k,
            file_i = 0;
    FILE    *fp;
    UINT8   *buffer;
    char    *c;

    /*
     * Process the command line
     */
    if (argc <= 1)
        ShowHelp();

    for (i = 1; i < argc; i++)
    {
        if (argv[i][0] != '-')
        {
            if (file_i)
                fprintf(stderr, "68kd: Garbage on the command line (ignored): %s\n", argv[i]);
            else
                file_i = i;
        }
        else if (!strcmp(argv[i], "-?") || !strcmp(argv[i], "-h"))
            ShowHelp();
        else if (!strcmp(argv[i], "-s"))
        {
            i++;
            if (i >= argc)
                fprintf(stderr, "68kd: Warning: No argument to: %s (ignored)\n", "-s");
            else
                start_addr = strtoul(argv[i], &c, 16);
        }
        else if (!strcmp(argv[i], "-l"))
        {
            i++;
            if (i >= argc)
                fprintf(stderr, "68kd: Warning: No argument to: %s (ignored)\n", "-l");
            else
            {
                len = strtoul(argv[i], &c, 16);
                if (!len)
                    exit(0);    // nothing to do!
            }
        }
        else if (!strcmp(argv[i], "-o"))
        {
            i++;
            if (i >= argc)
                fprintf(stderr, "68kd: Warning: No argument to: %s (ignored)\n", "-o");
            else
            {
                org = strtoul(argv[i], &c, 16);
                do_org = 1;
            }
        }
        else
            fprintf(stderr, "68kd: Warning: Unrecognized option: %s (ignored)\n", argv[i]);
    }

    if (!file_i)
    {
        fprintf(stderr, "68kd: No file specified\n");
        exit(1);
    }

    /*
     * Load file
     */

    if ((fp = fopen(argv[file_i], "rb")) == NULL)
    {
        fprintf(stderr, "68kd: Unable to open %s for writing\n", argv[file_i]);
        exit(1);
    }
    fseek(fp, 0, SEEK_END);
    fsize = ftell(fp);
    rewind(fp);

    if ((buffer = (UINT8 *) malloc(fsize)) == NULL)
    {              
        fprintf(stderr, "68kd: Not enough memory to load input file: %s, %lu bytes\n", argv[file_i], (unsigned long) fsize);
        exit(1);
    }
    fread(buffer, sizeof(UINT8), fsize, fp);
    fclose(fp);

    ByteSwapMemory(buffer, fsize);
    
    /*
     * Disassemble!
     */

    if (!len)
        len = fsize - start_addr;

    if (!do_org)
        org = start_addr;

    for (i = start_addr, j = 0; i < fsize && j < len; )
    {
        k = Dis68000One(org, &buffer[i], dis_op, dis_inst, dis_arg);
        printf("0x%08X: %s %s\n", org, dis_op, dis_inst);
        org += k;
        j += k;
        i += k;
    }
               
    free(buffer);
    return 0;
}

