//*****************************************************************
//* PCX to Neo Geo tile converter. (Paletted)
//*****************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

#define PAL_SIZE		256
#define TILEDIMENSION	16

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#ifndef TRUE
#define TRUE	1
#endif
#ifndef FALSE
#define FALSE	0
#endif

#define BANKSIZE   (1024 * 1024)

DWORD	Width;
DWORD	Height;
char	FileBank1[32];
char	FileBank2[32];
char	FilePal[32];
BYTE    Bank1[BANKSIZE];
BYTE    Bank2[BANKSIZE];
WORD	Palette[PAL_SIZE];
DWORD	Offset		= 0;
DWORD	Palettes	= 1;
BYTE	PcxBuffer[1024 * 1024];
BYTE	PcxPalette[768];

struct PCXHeader
{
	BYTE ID;
	BYTE Version;
	BYTE RLE;
	BYTE BPP;
	WORD StartX;
	WORD StartY;
	WORD EndX;
	WORD EndY;
	WORD HRes;
	WORD VRes;
	BYTE Palette[48];
	BYTE Reserved1;
	BYTE BitPlanes;
	WORD BytesPerLine;
	WORD PaletteType;
	WORD HSize;
	WORD VSize;
	BYTE Reserved2[54];
};

void Usage();
long Rip(char *Filename);
void WriteTiles();
BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette);
void GetTile(BYTE *Tile, DWORD X, DWORD Y);
DWORD CheckTile(BYTE *Tile);

void main(int argc, char *argv[])
{
    printf("PCX to Neo Geo tile converter.\n");

    if (argc < 5)
    {
        Usage();
    }

	if (7 == argc)
	{
		Palettes	= (DWORD)atol(argv[6]);
	}

    memset(Bank1, 0, BANKSIZE);
    memset(Bank2, 0, BANKSIZE);
    memset(Palette, 0, PAL_SIZE * 2);
    
    Offset	= atol(argv[1]);

	strcpy(FileBank1, argv[3]);

    if ("" == FileBank1)
    {
        Usage();
    }

    strcpy(FileBank2, argv[4]);

    if ("" == FileBank2)
    {
        Usage();
    }

	if (Offset > 0)
	{
		FILE	*handle = fopen(FileBank1, "rb");

		if (handle != NULL)
		{
			fread(Bank1, 1, BANKSIZE, handle);
			fclose(handle);
		}

		handle = fopen(FileBank2, "rb");

		if (handle != NULL)
		{
			fread(Bank2, 1, BANKSIZE, handle);
			fclose(handle);
		}
	}

    if (argc > 5)
    {
        strcpy(FilePal, argv[5]);

        if (strlen(FilePal) <= 0)
        {
            printf("Palette will not be saved.\n");
        }
    }

    else
    {
		memset(FilePal, 0, sizeof(FilePal));
    }

    if (-1 == Rip(argv[2]))
    {
        exit(1);
    }

    WriteTiles();

	printf("Next Offset = %d", Offset); 
}

void Usage()
{
    printf("Command syntax is: PcxNG Offset Infile.pcx Rom1 Rom2 [Palette] [Palettes]\n");

    exit(1);
}

long Rip(char *Filename)
{
	BYTE	*Plane1[2];
	BYTE	*Plane2[2];
	BYTE	*Plane3[2];
	BYTE	*Plane4[2];
	BYTE	Tile[TILEDIMENSION * TILEDIMENSION];

    LoadPCX(Filename, PcxBuffer, PcxPalette);

    if ((Width % TILEDIMENSION) != 0 && (Height % TILEDIMENSION) != 0)
    {
        printf("Picture must be a multiple of %d.\n", TILEDIMENSION);
        
		return	-1;
    }

	Plane1[0]	= Bank2 + 1 + Offset;
    Plane2[0]	= Bank2 + Offset;
    Plane3[0]	= Bank1 + 1 + Offset;
    Plane4[0]	= Bank1 + Offset;
    Plane1[1]	= Bank2 + 33 + Offset;
    Plane2[1]	= Bank2 + 32 + Offset;
    Plane3[1]	= Bank1 + 33 + Offset;
    Plane4[1]	= Bank1 + 32 + Offset;

    for (DWORD yloop = 0; yloop < (Height / TILEDIMENSION); yloop++)
    {
        for (DWORD xloop = 0; xloop < (Width / TILEDIMENSION); xloop++)
        {
            DWORD	x	= xloop * TILEDIMENSION;
            DWORD	y	= yloop * TILEDIMENSION;

            GetTile(Tile, x, y);

/*
			if ((xloop + yloop) != 0 && FALSE == CheckTile(Tile))
			{
				continue;
			}
*/
			
            for (DWORD tiley = 0; tiley < TILEDIMENSION; tiley++)
            {
                *Plane1[0]	= 0;
                *Plane2[0]	= 0;
                *Plane3[0]	= 0;
                *Plane4[0]	= 0;
                *Plane1[1]	= 0;
                *Plane2[1]	= 0;
                *Plane3[1]	= 0;
                *Plane4[1]	= 0;
				
				for (DWORD tilex = 0; tilex < TILEDIMENSION / 2; tilex++)
                {
					BYTE Pixel1	= Tile[tiley * TILEDIMENSION + tilex];
					BYTE Pixel2	= Tile[tiley * TILEDIMENSION + tilex + 8];
				
					*Plane4[0]	|= ((Pixel2 & 1) >> 0) << (tilex);
					*Plane3[0]	|= ((Pixel2 & 2) >> 1) << (tilex);
					*Plane2[0]	|= ((Pixel2 & 4) >> 2) << (tilex);
					*Plane1[0]	|= ((Pixel2 & 8) >> 3) << (tilex);
					
					*Plane4[1]	|= ((Pixel1 & 1) >> 0) << (tilex);
					*Plane3[1]	|= ((Pixel1 & 2) >> 1) << (tilex);
					*Plane2[1]	|= ((Pixel1 & 4) >> 2) << (tilex);
					*Plane1[1]	|= ((Pixel1 & 8) >> 3) << (tilex);
				}

				Plane1[0]	+= 2;
				Plane2[0]	+= 2;
				Plane3[0]	+= 2;
				Plane4[0]	+= 2;
								
				Plane1[1]	+= 2;				
				Plane2[1]	+= 2;				
				Plane3[1]	+= 2;				
				Plane4[1]	+= 2;				
			}
        
			Plane1[0]	+= 32;
			Plane2[0]	+= 32;
			Plane3[0]	+= 32;
			Plane4[0]	+= 32;
								
			Plane1[1]	+= 32;				
			Plane2[1]	+= 32;				
			Plane3[1]	+= 32;				
			Plane4[1]	+= 32;				
		}
    }

	Offset	= (long)(Plane2[0] - Bank2);
    
	return	0;
}

void WriteTiles()
{
    for (DWORD loop = 0; loop < PAL_SIZE; loop++)
    {
        BYTE	red    = ((PcxPalette[loop * 3]) >> 2);
        BYTE	green  = ((PcxPalette[loop * 3 + 1]) >> 2);
        BYTE	blue   = ((PcxPalette[loop * 3 + 2]) >> 2);

        red		&= 0x0f;
        green	&= 0x0f;
        blue	&= 0x0f;

		WORD	value	= ((WORD)green << 12) | ((WORD)blue << 8) | ((WORD)red << 0);
        Palette[loop]	= value;	
    }

    FILE	*handle;

	if (strlen(FilePal) > 0)
	{
		handle	= fopen(FilePal, "wb");

		if (NULL == handle)
		{
			return;
		}
		
		fwrite(Palette, 2, (Palettes * 32) / sizeof(WORD), handle);
		fclose(handle);
	}

    // open a binary file for the level array
    handle	= fopen(FileBank1, "wb");

	if (NULL == handle)
	{
		return;
	}

    fwrite(Bank1, 1, BANKSIZE, handle);
    fclose(handle);

    // open a binary file for the level array
    handle	= fopen(FileBank2, "wb");

	if (NULL == handle)
	{
		return;
	}

    fwrite(Bank2, 1, BANKSIZE, handle);
    fclose(handle);
}

BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette)
{
	FILE		*handle;
	PCXHeader   PcxHeader;
	DWORD		Position;
	DWORD		Length;

	handle	= fopen(File, "rb");

	if (NULL == handle)
	{
		return	FALSE;
	}

	Position	= ftell(handle);
	fseek(handle, 0, SEEK_END);
	Length		= ftell(handle);
	rewind(handle);

	fread(&PcxHeader, 1, sizeof(PcxHeader), handle);

	if (PcxHeader.ID != 0x0A || PcxHeader.Version != 5 || PcxHeader.RLE != 1 
		|| (8 == PcxHeader.BPP && PcxHeader.BitPlanes != 1))
	{
		return	FALSE;
	}

	Width   = PcxHeader.EndX - PcxHeader.StartX + 1;
	Height  = PcxHeader.EndY - PcxHeader.StartY + 1;

	if (1 == PcxHeader.BPP && 4 == PcxHeader.BitPlanes)
	{
		 memset(Palette, 0, 768);

		for (DWORD loop = 0; loop < 48; loop++)
		{
			Palette[loop]	= PcxHeader.Palette[loop] >> 2;
		}
	}

	else if (8 == PcxHeader.BPP && 1 == PcxHeader.BitPlanes)
	{
		fseek(handle, Position + Length - 768, SEEK_SET);

		for (DWORD loop = 0; loop < 768; loop++)
		{
			Palette[loop]	= ((BYTE)getc(handle)) >> 2;
		}
	}

	else
	{
		return	FALSE;
	}

	fseek(handle, Position + sizeof(PCXHeader), SEEK_SET);

	DWORD	TmpHeight	= Height;

	while (TmpHeight-- > 0)
	{
		BYTE	Pixel;
		BYTE	*Output;

		Output	= Buffer;

		memset(Buffer, 0, Width);

		for (DWORD Planes = 0; Planes < PcxHeader.BitPlanes; Planes++)
		{
			DWORD	Done	= 0;
			Buffer	= Output;

			do
			{
				Pixel	= (BYTE)getc(handle);

				if ((Pixel & 0xC0) != 0xC0)
				{
					if (1 == PcxHeader.BPP)
					{
						for (DWORD Bits = 7; Bits >= 0; Bits--)
						{
							*Buffer++	|= ((Pixel >> Bits) & 1) << Planes;
						}

						Done	+= 8;
					}

					else
					{
						*Buffer++	= Pixel;
						Done++;
					}
				}

				else
				{
					BYTE	Run	= (BYTE)getc(handle);
					Pixel	&= ~0xC0;

					while (Pixel > 0 && Done < Width)
					{
						if (1 == PcxHeader.BPP)
						{
							for (DWORD Bits = 7; Bits >= 0; Bits--)
							{
								*Buffer++	|= ((Run >> Bits) & 1) << Planes;
							}

							Done	+= 8;
						}

						else
						{
							*Buffer++	= Run;
							Done++;
						}

						Pixel--;
					}
				}
			}
			
			while (Done < Width);
		}
	}

	if (handle != NULL)
	{
		fclose(handle);
	}
	
	return	TRUE;
}

void GetTile(BYTE *Tile, DWORD X, DWORD Y)
{
	BYTE *Buffer	= PcxBuffer;

	Buffer += Y * Width + X;

	for (DWORD outerloop = 0; outerloop < TILEDIMENSION; outerloop++)
	{
		for (DWORD innerloop = 0; innerloop < TILEDIMENSION; innerloop++)
		{
			*Tile	= *Buffer;
			Tile++;
			Buffer++;
		}

		Buffer += Width - TILEDIMENSION;
	}
}

DWORD CheckTile(BYTE *Tile)
{
	for (DWORD Loop = 0; Loop < TILEDIMENSION * TILEDIMENSION; Loop++)
	{
		if (Tile[Loop] != 0)
		{
			return	TRUE;
		}
	}
	
	return	FALSE;
}

