//*****************************************************************
//* PCX to Neo Geo FIX converter.
//*****************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#define PAL_SIZE		16
#define TILESIZE		64
#define TILEWIDTH		8
#define TILEHEIGHT		8
#define	BANKSIZE		(128 * 1024)

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

long Rip(char *Filename);
void WriteFix(char *Filename);
BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette);
void GetTile(BYTE *Tile, DWORD X, DWORD Y);

DWORD	Width;
DWORD	Height;
char	FilePal[32];
BYTE	Bank[BANKSIZE];
WORD	Palette[PAL_SIZE];
long	Offset;
BYTE	XTable[]	= {5, 4, 7, 6, 1, 0, 3, 2};
BYTE	PcxBuffer[1024 * 1024];
BYTE	PcxPalette[768];

struct PCXHeader
{
	BYTE ID;
	BYTE Version;
	BYTE RLE;
	BYTE BPP;
	WORD StartX;
	WORD StartY;
	WORD EndX;
	WORD EndY;
	WORD HRes;
	WORD VRes;
	BYTE Palette[48];
	BYTE Reserved1;
	BYTE BitPlanes;
	WORD BytesPerLine;
	WORD PaletteType;
	WORD HSize;
	WORD VSize;
	BYTE Reserved2[54];
};

void Usage();

void main(int argc, char *argv[])
{
	printf("PCX to Neo Geo FIX converter.\n");

	if (argc < 4)
	{
		Usage();
	}

	memset(Bank, 0, sizeof(Bank));
	memset(Palette, 0, PAL_SIZE * 2);

	Offset = atol(argv[1]);

	if ("" == argv[1])
	{
		Usage();
	}

	long Length;

	FILE	*Handle = fopen(argv[3], "rb");

	if (Handle != NULL)
	{
		fseek(Handle, 0, SEEK_END);
		Length = ftell(Handle);
		rewind(Handle);

		if (Length > BANKSIZE)
		{
			Length	= BANKSIZE;
		}

		fread(Bank, 1, Length, Handle);
		fclose(Handle);
	}

	if (argc > 4)
	{
		strcpy(FilePal, argv[4]);

		if (strlen(FilePal) <= 0)
		{
			printf("Palette will not be saved.\n");
		}
	}

	else
	{
		memset(FilePal, 0, sizeof(FilePal));
	}

	if (-1 == Rip(argv[2]))
	{
		exit(1);
	}

	WriteFix(argv[3]);
}

void Usage()
{
	printf("Command syntax is: FixNG Offset Infile Rom [Palette]\n");

	exit(1);
}

//**************************** Rip *******************************
long Rip(char *Filename)
{
	LoadPCX(Filename, PcxBuffer, PcxPalette);

	if ((Width % TILEWIDTH) != 0 && (Height % TILEWIDTH) != 0)
	{
		printf("FIX character width must be a multiple of 8.\n");

		return -1;
	}

	BYTE	Tile[TILESIZE];
	BYTE	*TilePtr		= Bank + Offset;

	for (DWORD YLoop = 0; YLoop < (Height / 8); YLoop++)
	{
		for (DWORD XLoop = 0; XLoop < (Width / 8); XLoop++)
		{
			long	x	= XLoop * 8;
			long	y	= YLoop * 8;

			GetTile(&Tile[0], x, y);

			for (DWORD TileX = 0; TileX < 8; TileX += 2)
			{
				for (DWORD TileY = 0; TileY < 8; TileY++)
				{

					*TilePtr	=	((Tile[TileY * TILEWIDTH + XTable[TileX]] & 0x0f) << 4) |
								(Tile[TileY * TILEWIDTH + XTable[TileX + 1]] & 0x0f);

					TilePtr++;
					Offset++;
				}
			}
		}
	}


	return 0;
}

void WriteFix(char *Filename)
{
	FILE	*Handle;
	
	if (strlen(FilePal) > 0)
	{
		for (DWORD Loop = 0; Loop < PAL_SIZE; Loop++)
		{
			BYTE Red	= ((PcxPalette[Loop * 3]) >> 2);
			BYTE Green	= ((PcxPalette[Loop * 3 + 1]) >> 2);
			BYTE Blue	= ((PcxPalette[Loop * 3 + 2]) >> 2);

			Red	  &= 0x0f;
			Green &= 0x0f;
			Blue  &= 0x0f;

			Palette[Loop]	= ((WORD)Green << 12) | ((WORD)Blue << 8) | ((WORD)Red << 0);
		}

		Handle	= fopen(FilePal, "wb");

		if (NULL == Handle)
		{
			return;
		}

		fwrite(Palette, 2, sizeof(Palette) / sizeof(WORD), Handle);
		fclose(Handle);
	}

	Handle	= fopen(Filename, "wb");

	if (NULL == Handle)
	{
		return;
	}

	fwrite(Bank, 1, BANKSIZE, Handle);

	fclose(Handle);

	printf("Offset: %d\n", Offset);
}

BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette)
{
	FILE		*Handle;
	PCXHeader   PcxHeader;
	DWORD		Position;
	DWORD		Length;

	Handle	= fopen(File, "rb");

	if (NULL == Handle)
	{
		return	FALSE;
	}

	Position	= ftell(Handle);
	fseek(Handle, 0, SEEK_END);
	Length		= ftell(Handle);
	rewind(Handle);

	fread(&PcxHeader, 1, sizeof(PcxHeader), Handle);

	if (PcxHeader.ID != 0x0A || PcxHeader.Version != 5 || PcxHeader.RLE != 1 
		|| (8 == PcxHeader.BPP && PcxHeader.BitPlanes != 1))
	{
		return	FALSE;
	}

	Width   = PcxHeader.EndX - PcxHeader.StartX + 1;
	Height  = PcxHeader.EndY - PcxHeader.StartY + 1;

	if (1 == PcxHeader.BPP && 4 == PcxHeader.BitPlanes)
	{
		 memset(Palette, 0, 768);

		for (DWORD Loop = 0; Loop < 48; Loop++)
		{
			Palette[Loop]	= PcxHeader.Palette[Loop] >> 2;
		}
	}

	else if (8 == PcxHeader.BPP && 1 == PcxHeader.BitPlanes)
	{
		fseek(Handle, Position + Length - 768, SEEK_SET);

		for (DWORD Loop = 0; Loop < 768; Loop++)
		{
			Palette[Loop]	= ((BYTE)getc(Handle)) >> 2;
		}
	}

	else
	{
		return	FALSE;
	}

	fseek(Handle, Position + sizeof(PCXHeader), SEEK_SET);

	DWORD	TmpHeight	= Height;

	while (TmpHeight-- > 0)
	{
		BYTE	Pixel;
		BYTE	*Output;

		Output	= Buffer;

		memset(Buffer, 0, Width);

		for (DWORD Planes = 0; Planes < PcxHeader.BitPlanes; Planes++)
		{
			DWORD	Done	= 0;
			Buffer	= Output;

			do
			{
				Pixel	= (BYTE)getc(Handle);

				if ((Pixel & 0xC0) != 0xC0)
				{
					if (1 == PcxHeader.BPP)
					{
						for (DWORD Bits = 7; Bits >= 0; Bits--)
						{
							*Buffer++	|= ((Pixel >> Bits) & 1) << Planes;
						}

						Done	+= 8;
					}

					else
					{
						*Buffer++	= Pixel;
						Done++;
					}
				}

				else
				{
					BYTE	Run	= (BYTE)getc(Handle);
					Pixel	&= ~0xC0;

					while (Pixel > 0 && Done < Width)
					{
						if (1 == PcxHeader.BPP)
						{
							for (DWORD Bits = 7; Bits >= 0; Bits--)
							{
								*Buffer++	|= ((Run >> Bits) & 1) << Planes;
							}

							Done	+= 8;
						}

						else
						{
							*Buffer++	= Run;
							Done++;
						}

						Pixel--;
					}
				}
			}
			
			while (Done < Width);
		}
	}

	if (Handle != NULL)
	{
		fclose(Handle);
	}
	
	return	TRUE;
}

void GetTile(BYTE *Tile, DWORD X, DWORD Y)
{
	BYTE *Buffer	= PcxBuffer;

	Buffer += Y * Width + X;

	for (DWORD OuterLoop = 0; OuterLoop < TILEHEIGHT; OuterLoop++)
	{
		for (DWORD InnerLoop = 0; InnerLoop < TILEWIDTH; InnerLoop++)
		{
			*Tile	= *Buffer;
			Tile++;
			Buffer++;
		}

		Buffer	+= Width - TILEWIDTH;
	}
}
