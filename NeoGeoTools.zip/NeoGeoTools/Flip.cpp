// Flips words in a file

#include <stdio.h>
#include <windows.h>

void Usage();

int main(int argc, char *argv[]) 
{
    if (argc < 3)
	{	   
		Usage();
	}

	FILE *Handle	= fopen(argv[1], "rb");

	if (NULL == Handle)
	{
		printf("Unable to open %s.\n", argv[1]);
	
		exit(0);
	}

	fseek(Handle, 0, SEEK_END);

	DWORD	Length	= ftell(Handle);
	rewind(Handle);

	if (0 == Length)
	{
		printf("File %s's length is zero.\n"); 
		
		exit(0);
	}

	BYTE	*Buffer	= NULL;

	Buffer	= new BYTE[Length];

	if (NULL == Buffer)
	{
		printf("Unable to allocate buffer.\n");
		
		fclose(Handle);
		exit(0);
	}
								   
	fread(Buffer, 1, Length, Handle);
	fclose(Handle);

	for (DWORD loop = 0; loop < Length; loop += 2)
	{
		BYTE	Temp		= Buffer[loop];
		Buffer[loop]		= Buffer[loop + 1];
		Buffer[loop + 1]	= Temp;
	}

	Handle	= fopen(argv[2], "wb");

	if (NULL == Handle)
	{
		printf("Unable to create %s.\n", argv[2]);

		exit(0);
	}

	fwrite(Buffer, 1, Length, Handle);
	fclose(Handle);

	if (Buffer != NULL)
	{
		delete Buffer;

		Buffer	= NULL;
	}

	return	0;
}

void Usage()
{
	printf("Command syntax is: Flip Infile Rom\n" );
		
	exit(0);
}
