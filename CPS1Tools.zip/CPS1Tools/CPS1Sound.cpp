#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#define	HEADERSIZE		0x400

BYTE	SoundHeader[HEADERSIZE];

void Usage();
void AddSound(DWORD SoundNumber, DWORD Length);

int main(int argc, char *argv[]) 
{
	DWORD	SoundNumber;
    
	if (argc < 4)
	{	   
		Usage();
	}

	SoundNumber	= atol(argv[1]);

	FILE *Handle	= fopen(argv[3], "rb");

	if (Handle != NULL)
	{
		fread(SoundHeader, 1, HEADERSIZE, Handle);

		fclose(Handle);
	}

	else
	{
		memset(SoundHeader, 0xFF, HEADERSIZE);
		memset(SoundHeader, 0x00, 8);
	}

	Handle	= fopen(argv[2], "rb");

	if (NULL == Handle)
	{
		printf("Unable to open sound file.\n"); 
		
		exit(0);
	}

	fseek(Handle, 0, SEEK_END);

	DWORD	Length	= ftell(Handle);
	fclose(Handle);

	AddSound(SoundNumber, Length);

	Handle	= fopen(argv[3], "wb");

	if (NULL == Handle)
	{
		printf("Unable to create %s.\n", argv[2]);
	}

	fwrite(SoundHeader, 1, HEADERSIZE, Handle);
	fclose(Handle);

	return	0;
}

void Usage()
{
	printf("Command syntax is: CPS1Sound SoundNumber SoundHeader SoundFile\n" );
			
	exit(0);
}

void AddSound(DWORD SoundNumber, DWORD Length)
{
	// Starting position in the header. the first position is unused
	DWORD	Offset	= (SoundNumber + 1) * 8;
	DWORD	Start	= (SoundHeader[SoundNumber * 8 + 3] << 16) | 
		(SoundHeader[SoundNumber * 8 + 4] << 8) | (SoundHeader[SoundNumber * 8 + 5]);

	if (0 == Start)
	{
		Start	= HEADERSIZE;
	}

	else
	{
		Start++;
	}

	DWORD	End	= Start + Length - 1;

	SoundHeader[Offset]		= (BYTE)((Start & 0xFF0000) >> 16);
	SoundHeader[Offset + 1]	= (BYTE)((Start & 0xFF00) >> 8);
	SoundHeader[Offset + 2]	= (BYTE)((Start & 0xFF));

	SoundHeader[Offset + 3]	= (BYTE)((End & 0xFF0000) >> 16);
	SoundHeader[Offset + 4]	= (BYTE)((End & 0xFF00) >> 8);
	SoundHeader[Offset + 5]	= (BYTE)((End & 0xFF));

	SoundHeader[Offset + 6]	= 0;
	SoundHeader[Offset + 7]	= 0;
}

