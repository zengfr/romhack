#ifndef __ROUTINES_H
#define	__ROUTINES_H

extern void LoadPalette(WORD *Source, DWORD Dest, DWORD Length);
  // Load palette

extern void LoadTilemap(DWORD *Source, DWORD Dest, DWORD Width, DWORD Height);
  // Load tilemap

extern void FillTilemap(DWORD Dest, DWORD Width, DWORD Height);
  // Fill tilemap

extern void ClearText();
  // Clear text

extern DWORD ReadJoystickA();
  // Read joystick A

extern DWORD ReadJoystickB();
  // Read joystick B

extern void WaitVBlank();
  // Wait VBlank

extern DWORD AddSprite(DWORD x, DWORD y, DWORD Width, DWORD Height, DWORD Tile, DWORD Palette);
  // Add sprite

extern void RemoveSprite(DWORD Sprite);
  // Remove sprite

extern void SetSpritePosition(DWORD Sprite, DWORD x, DWORD y);
  // Set sprite position

extern void SetSpriteTile(DWORD Sprite, DWORD Tile);
  // Set sprite tile

extern void ClearSpriteList(DWORD NumSprites);
  // Clear sprite list 

extern void SetPaletteRed(DWORD Dest, DWORD Red);
  // Set palette red

extern void SetPaletteGreen(DWORD Dest, DWORD Green);
  // Set palette green

extern void SetPaletteBlue(DWORD Dest, DWORD Blue);
  // Set pallete blue

extern void DrawNumber(DWORD Value, DWORD Palette, DWORD x, DWORD y);
  // Draw number

extern void DrawString(char *String, DWORD Palette, DWORD x, DWORD y);
  // Draw string

extern void InitSound();
  // Init sound

extern void PlaySound(DWORD SoundID);
  // Play sound

extern void StopSound(DWORD SoundID);
  // Stop sound

extern void InitializeZ80(BYTE *Address, DWORD Size, BYTE *Table, DWORD TableSize);
  // Transfer Z80

extern DWORD Random(DWORD Limit);
  // Get a random number

#endif
