#include "Defines.h"
#include "Routines.h"
#include "Sound.h"

extern BYTE	Sound[];
extern BYTE	SndTable[];

void InitSound()
{
	InitializeZ80(Sound, SOUNDSIZE, SndTable, TABLESIZE);
}


