#ifndef __MAIN_H
#define	__MAIN_H

void CopyData();
  // Copy tiles, palettes and, maps.

void ShowScreen1();
  // Show screen 1

void ShowScreen2();
  // Show screen 2

void ShowTitle();
  // Show title

void HideTitle();
  // Hide title

#endif