#ifndef __GAMEDEFINES_H
#define	__GAMEDEFINES_H

// Sprite frames
#define	SPRITE			0
#define	SPLASH			(SPRITE + (48 * 16))
#define	FROGTILE		SPRITE
#define	FROGPALETTE1	0
#define	FROGPALETTE2	0
#define	BACKGROUNDCOLOR	(0xA00800 + 6 * 2)

// Position offsets
#define	FROG1X			82+64
#define	FROG2X			222+64
#define	SPLASHWIDTH		32

// Screen defines
#define	SCREENLEFT		0
#define	SCREENRIGHT		448
#define	LEFTEDGE		(18 + 64)
#define RIGHTEDGE		(278 + 64)
#define	MIDDLELEFT		(118 + 64)
#define	MIDDLERIGHT		(184 + 64)

// Sprite offsets
#define	SWIMSPRITE		(48 * 7)
#define	FACESPRITE		(48 * 8)
#define	JUMPSPRITE		(48 * 1)
#define	FLYSPRITE		(48 * 6)

// Score defines
#define	SCOREY			26
#define	SCORE1X			(4 + 8)
#define	SCORE2X			(35 + 8)
#define	FONTPAL			0
#define	TIMEX			(16 + 8)
#define	TIMEY			(SCOREY + 1)
#define	STARTX			(15 + 8)
#define	STARTY			20
#define	STARTSPRY		20
#define	GAMEOVERX		(15 + 8)
#define	GAMEOVERY		10
#define	PLAYER1X		(112 + 64)
#define	PLAYER2X		(192 + 64)
#define	PLAYERY			((GAMEOVERY + 4) * 8)
#define	ENDSCORE1X		(15 + 8)
#define	ENDSCORE2X		(25 + 8)
#define	ENDSCOREY		(GAMEOVERY + 7)
#define	TIEX			(16 + 8)

// Sound defines
#define	SND_FROG1		0xFF0174	// Frog sound
#define	SND_TONGUE1		0xFF0274	// Tongue sound
#define	SND_GRAB1		0xFF0374	// Grab sound
#define	SND_WATER1		0xFF0474	// Water sound
#define	SND_FROG2		0xFF0174	// Frog sound
#define	SND_TONGUE2		0xFF0274	// Tongue sound
#define	SND_GRAB2		0xFF0374	// Grab sound
#define	SND_WATER2		0xFF0474	// Water sound

// Animation frames
const DWORD TongueFrames[LICKLENGTH]	=
{
	48*2, 48*3, 48*4, 48*5, 48*5, 48*4, 48*3, 48*2
};

const DWORD SkyBlue[SKYLENGTH]	=
{
	9*2, 10*2, 11*2, 13*2, 11*2, 10*2, 9*2
};

const DWORD SkyGreen[SKYLENGTH]	=
{
	6*2, 7*2, 8*2, 10*2, 8*2, 7*2, 6*2
};

#endif