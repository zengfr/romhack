#ifndef __SPRITES_H
#define	__SPRITES_H

#define	SPRITEWORDS		64
#define	FULLZOOM		0x0FFF	

struct tagSpriteTable
{
	WORD	Used;		// Is this Sprite control used?
	WORD	x;			// Sprite x position (<< 7)
	WORD	y;			// Sprite y position (<< 7) and sprites in bank
	WORD	Palette;	// Palette, flip, and unused sprite data offset
	WORD	Offset;		// Data offset
	WORD	Dimension;	// Sprite dimensions
};

#endif
