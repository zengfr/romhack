struct tagSprite	Frogs[2];
struct tagSprite	Flies[MAXFLIES];
struct tagGameEvent	Events[MAXEVENTS];
DWORD				OldJoyVal1;
DWORD				OldJoyVal2;
DWORD				Score[2];
DWORD				Time;
DWORD				ColorTime;
DWORD				ColorIndex;
DWORD				FlySide;
DWORD				Players;
DWORD				LastAction;

const DWORD JumpWave[JUMPLENGTH]	=
{
	0,  2,  4,  7,  9,  11,  14,  16,
	18,  21,  23,  25,  28,  30,  32,  34,
	37,  39,  41,  43,  45,  48,  50,  52,
	54,  56,  58,  60,  62,  64,  66,  68,
	70,  72,  74,  76,  77,  79,  81,  83,
	84,  86,  88,  89,  91,  92,  94,  95,
	97,  98,  99,  101,  102,  103,  104,  105,
	106,  107,  108,  109,  110,  111,  112,  113,
	114,  114,  115,  116,  116,  117,  117,  118,
	118,  118,  119,  119,  119,  119,  119,  119,
	120,  119,  119,  119,  119,  119,  119,  118,
	118,  118,  117,  117,  116,  116,  115,  114,
	114,  113,  112,  111,  110,  109,  108,  107,
	106,  105,  104,  103,  102,  101,  99,  98,
	97,  95,  94,  92,  91,  89,  88,  86,
	84,  83,  81,  79,  77,  76,  74,  72,
	70,  68,  66,  64,  62,  60,  58,  56,
	54,  52,  50,  48,  45,  43,  41,  39,
	37,  34,  32,  30,  28,  25,  23,  21,
	18,  16,  14,  11,  9,  7,  4,  2
};

const DWORD HopWave[HOPLENGTH]	=
{
	2,  3,  5,  6,  6,  5,  3,  2
};

const DWORD TongueLength[LICKLENGTH]	=
{
	3,	5,	7,	9,	9,	7,	5,	3
};

void SelectPlayers()
{
	DWORD	SelectX		= (STARTX * 8) - 24;
	DWORD	SelectY		= ((STARTSPRY + 1) * 8) + 4;
	DWORD	SelectIndex;
	DWORD	JoyVal1;
	DWORD	JoyVal2;

	DrawString("SELECT:", FONTPAL, STARTX, STARTY);
	DrawString("1 PLAYER", FONTPAL, STARTX, STARTY + 2);
	DrawString("2 PLAYERS", FONTPAL, STARTX, STARTY + 4);

	SelectIndex	= AddSprite(SelectX, SelectY, 16, 16, FROGTILE + FACESPRITE, FROGPALETTE1);

	while (TRUE)
	{
		WaitVBlank();

		JoyVal1	= ReadJoystickA();
		JoyVal2	= ReadJoystickB();

		if (JoyVal1	!= OldJoyVal1)
		{
			OldJoyVal1	= JoyVal1;

			if ((OldJoyVal1 & JOYA_A) != 0)
			{
				OldJoyVal2	= JoyVal2;

				break;
			}

			if ((OldJoyVal1 & JOYA_UP) != 0)
			{
				if (2 == Players)
				{
					Players	= 1;
					SelectY	= ((STARTSPRY + 1) * 8) + 4;

					SetSpritePosition(SelectIndex, SelectX, SelectY);
				}
			}

			else if ((OldJoyVal1 & JOYA_DOWN) != 0)
			{
				if (1 == Players)
				{
					Players	= 2;
					SelectY	= ((STARTSPRY + 1) * 8) + 20;

					SetSpritePosition(SelectIndex, SelectX, SelectY);
				}
			}
		}

		if (JoyVal2	!= OldJoyVal2)
		{
			OldJoyVal2	= JoyVal2;

			if ((OldJoyVal2 & JOYA_A) != 0)
			{
				break;
			}

			if ((OldJoyVal2 & JOYA_UP) != 0)
			{
				if (2 == Players)
				{
					Players	= 1;
					SelectY	= ((STARTY + 1) * 8) + 4;

					SetSpritePosition(SelectIndex, SelectX, SelectY);
				}
			}

			else if ((OldJoyVal2 & JOYA_DOWN) != 0)
			{
				if (1 == Players)
				{
					Players	= 2;
					SelectY	= ((STARTY + 1) * 8) + 20;

					SetSpritePosition(SelectIndex, SelectX, SelectY);
				}
			}
		}
	}

	RemoveSprite(SelectIndex);
}

void PlayGame()
{
	ClearEvents();
	ResetFrogs();
	ResetFlies();

	Score[0]	= 0;
	Score[1]	= 0;
	Time		= GAMETIME;
	ColorTime	= GAMETIME / 7;
	ColorIndex	= 0;
	LastAction	= 0;

	SetPaletteBlue(BACKGROUNDCOLOR, SkyBlue[ColorIndex]);
	SetPaletteGreen(BACKGROUNDCOLOR, SkyGreen[ColorIndex]);

	while (TRUE)
	{
		if (FALSE == GameLoop())
		{
			break;
		}
	}

	ShowGameOver();
}

DWORD GameLoop()
{
	WaitVBlank();
	CheckFlies();
	HandleInput();
	ProcessEvents();
	UpdateFrogs();
	UpdateFlies();
	DrawScores();

	Time--;

	if (0 == Time)
	{
		return	FALSE;
	}

	ColorTime--;

	if (0 == ColorTime)
	{
		if (ColorIndex < 6)
		{
			ColorTime	= GAMETIME / 7;

			ColorIndex++;

			SetPaletteBlue(BACKGROUNDCOLOR, SkyBlue[ColorIndex]);
			SetPaletteGreen(BACKGROUNDCOLOR, SkyGreen[ColorIndex]);
		}
	}

	return	TRUE;
}

void ShowGameOver()
{
	DWORD	JoyVal1;
	DWORD	JoyVal2;
	DWORD	Delay	= ENDDELAY;

	ClearSpriteList(MAXSPRITES);

	DrawString("GAME  OVER", FONTPAL, GAMEOVERX, GAMEOVERY);

	if (Score[0] > Score[1])
	{
		DrawString("WINNER", FONTPAL, ENDSCORE1X - 3, GAMEOVERY + 2);

		AddSprite(PLAYER1X, PLAYERY, 16, 16, FROGTILE + FACESPRITE + JUMPSPRITE, FROGPALETTE1);
		AddSprite(PLAYER2X, PLAYERY, 16, 16, FROGTILE, FROGPALETTE2);
	}

	else if (Score[1] > Score[0])
	{
		DrawString("WINNER", FONTPAL, ENDSCORE2X - 3, GAMEOVERY + 2);

		AddSprite(PLAYER1X, PLAYERY, 16, 16, FROGTILE + FACESPRITE, FROGPALETTE1);
		AddSprite(PLAYER2X, PLAYERY, 16, 16, FROGTILE + JUMPSPRITE, FROGPALETTE2);
	}

	else
	{
		DrawString("TIE GAME", FONTPAL, TIEX, GAMEOVERY + 2);

		AddSprite(PLAYER1X, PLAYERY, 16, 16, FROGTILE + FACESPRITE, FROGPALETTE1);
		AddSprite(PLAYER2X, PLAYERY, 16, 16, FROGTILE, FROGPALETTE2);
	}

	DrawNumber(Score[0], FONTPAL, ENDSCORE1X, ENDSCOREY);
	DrawNumber(Score[1], FONTPAL, ENDSCORE2X, ENDSCOREY);

	while (TRUE)
	{
		WaitVBlank();

		JoyVal1	= ReadJoystickA();
		JoyVal2	= ReadJoystickB();

		if (JoyVal1	!= OldJoyVal1)
		{
			OldJoyVal1	= JoyVal1;
		}

		if (JoyVal2	!= OldJoyVal2)
		{
			OldJoyVal2	= JoyVal2;
		}

		Delay--;

		if (0 == Delay)
		{
			break;
		}
	}
}

void CheckFlies()
{
	DWORD	Loop;

	for (Loop = 0; Loop < 2; Loop++)
	{
		if (TRUE == Frogs[Loop].Tonguing)
		{
			CheckTongue(Loop);
		}
	}
}

void HandleInput()
{
	DWORD	Value	= ReadJoystickA();

	if (Value != OldJoyVal1 || TRUE == Frogs[0].InWater)
	{
		OldJoyVal1	= Value;

		if (FALSE == Frogs[0].Jumping && FALSE == Frogs[0].Hopping)
		{
			if (Value & JOYA_LEFT)
			{
				if (1 == Frogs[0].Facing)
				{
					Frogs[0].Facing	= 0;

					SetSpriteTile(Frogs[0].SpriteIndex, Frogs[0].Tile);
				}

				else
				{
					if (FALSE == Frogs[0].InWater)
					{
						Frogs[0].Hopping	= TRUE;
						Frogs[0].JumpTime	= 0;
						Frogs[0].Tile		+= JUMPSPRITE;

						PlaySound(SND_FROG1);
					}

					else
					{
						MoveFrog(0);
					}
				}
			}

			else if (Value & JOYA_RIGHT)
			{
				if (0 == Frogs[0].Facing)
				{
					Frogs[0].Facing	= 1;

					SetSpriteTile(Frogs[0].SpriteIndex, Frogs[0].Tile + FACESPRITE);
				}

				else
				{
					if (FALSE == Frogs[0].InWater)
					{
						Frogs[0].Hopping	= TRUE;
						Frogs[0].JumpTime	= 0;
						Frogs[0].Tile		+= JUMPSPRITE;

						PlaySound(SND_FROG1);
					}

					else
					{
						MoveFrog(0);
					}
				}
			}

			else if (Value & JOYA_A)
			{
				if (FALSE == Frogs[0].InWater)
				{
					Frogs[0].Jumping	= TRUE;
					Frogs[0].JumpTime	= 0;
					Frogs[0].Tile		+= JUMPSPRITE;

					PlaySound(SND_FROG1);
				}
			}
		}

		else if (TRUE == Frogs[0].Jumping)
		{
			if (Value & JOYA_A && FALSE == Frogs[0].Tonguing && FALSE == Frogs[0].InWater)
			{
				Frogs[0].Tonguing		= TRUE;
				Frogs[0].TongueTime		= 0;

				Value	= TongueFrames[0];

				if (1 == Frogs[0].Facing)
				{
					Frogs[0].TongueIndex	= AddSprite(Frogs[0].x + TONGUEX, Frogs[0].y, 16, 16,
						FROGTILE + FACESPRITE + Value, FROGPALETTE1);
				}

				else
				{
					Frogs[0].TongueIndex	= AddSprite(Frogs[0].x - TONGUEX, Frogs[0].y, 16, 16,
						FROGTILE + Value, FROGPALETTE1);
				}

				PlaySound(SND_TONGUE1);
			}
		}
	}

	if (Players == 2)
	{
		Value	= ReadJoystickB();
	}

	else
	{
		Value	= HandleAI(1);
	}

	if (Value != OldJoyVal2 || TRUE == Frogs[1].InWater)
	{
		OldJoyVal2	= Value;

		if (FALSE == Frogs[1].Jumping && FALSE == Frogs[1].Hopping)
		{
			if (Value & JOYA_LEFT)
			{
				if (1 == Frogs[1].Facing)
				{
					Frogs[1].Facing	= 0;

					SetSpriteTile(Frogs[1].SpriteIndex, Frogs[1].Tile);
				}

				else
				{
					if (FALSE == Frogs[1].InWater)
					{
						Frogs[1].Hopping	= TRUE;
						Frogs[1].JumpTime	= 0;
						Frogs[1].Tile		+= JUMPSPRITE;

						PlaySound(SND_FROG2);
					}

					else
					{
						MoveFrog(1);
					}
				}
			}

			else if (Value & JOYA_RIGHT)
			{
				if (0 == Frogs[1].Facing)
				{
					Frogs[1].Facing	= 1;

					SetSpriteTile(Frogs[1].SpriteIndex, Frogs[1].Tile + FACESPRITE);
				}

				else
				{
					if (FALSE == Frogs[1].InWater)
					{
						Frogs[1].Hopping	= TRUE;
						Frogs[1].JumpTime	= 0;
						Frogs[1].Tile		+= JUMPSPRITE;

						PlaySound(SND_FROG2);
					}

					else
					{
						MoveFrog(1);
					}
				}
			}

			else if (Value & JOYA_A)
			{
				if (FALSE == Frogs[1].InWater)
				{
					Frogs[1].Jumping	= TRUE;
					Frogs[1].JumpTime	= 0;
					Frogs[1].Tile		+= JUMPSPRITE;

					PlaySound(SND_FROG2);
				}
			}
		}

		else if (TRUE == Frogs[1].Jumping)
		{
			if (Value & JOYA_A && FALSE == Frogs[1].Tonguing && FALSE == Frogs[1].InWater)
			{
				Frogs[1].Tonguing		= TRUE;
				Frogs[1].TongueTime		= 0;

				Value	= TongueFrames[0];

				if (1 == Frogs[1].Facing)
				{
					Frogs[1].TongueIndex	= AddSprite(Frogs[1].x + TONGUEX, Frogs[1].y, 16, 16,
						FROGTILE + FACESPRITE + Value, FROGPALETTE2);
				}

				else
				{
					Frogs[1].TongueIndex	= AddSprite(Frogs[1].x - TONGUEX, Frogs[1].y, 16, 16,
						FROGTILE + Value, FROGPALETTE2);
				}

				PlaySound(SND_TONGUE2);
			}
		}
	}
}

void UpdateFrogs()
{
	DWORD	Loop;
	DWORD	Value;

	for (Loop = 0; Loop < 2; Loop++)
	{
		if (TRUE == Frogs[Loop].Jumping)
		{
			Frogs[Loop].JumpTime++;

			if (1 == Frogs[Loop].JumpTime)
			{
				if (1 == Frogs[Loop].Facing)
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile + FACESPRITE);
				}

				else
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile);
				}
			}

			else if (JUMPLENGTH == Frogs[Loop].JumpTime)
			{
				Frogs[Loop].Jumping	= FALSE;
				Frogs[Loop].y		= FROGY;

				UpdateFrog(Loop, Frogs[Loop].x, FROGY);

				continue;
			}

			else if ((JUMPLENGTH - 1) == Frogs[Loop].JumpTime)
			{
				Frogs[Loop].Tile	-= JUMPSPRITE;

				if (1 == Frogs[Loop].Facing)
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile + FACESPRITE);
				}

				else
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile);
				}
			}

			if (0 == Frogs[Loop].Facing)
			{
				if (Frogs[Loop].x > SCREENLEFT)
				{
					Frogs[Loop].x--;
				}
			}

			else
			{
				if (Frogs[Loop].x < (SCREENRIGHT - 16))
				{
					Frogs[Loop].x++;
				}
			}

			Value	= JumpWave[Frogs[Loop].JumpTime];

			UpdateFrog(Loop, Frogs[Loop].x, FROGY - Value);
		}

		else if (TRUE == Frogs[Loop].Hopping)
		{
			Frogs[Loop].JumpTime++;

			if (1 == Frogs[Loop].JumpTime)
			{
				if (1 == Frogs[Loop].Facing)
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile + FACESPRITE);
				}

				else
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile);
				}
			}

			else if (HOPLENGTH == Frogs[Loop].JumpTime)
			{
				Frogs[Loop].Hopping	= FALSE;
				Frogs[Loop].y		= FROGY;

				UpdateFrog(Loop, Frogs[Loop].x, FROGY);

				continue;
			}

			else if ((HOPLENGTH - 1) == Frogs[Loop].JumpTime)
			{
				Frogs[Loop].Tile	-= JUMPSPRITE;

				if (1 == Frogs[Loop].Facing)
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile + FACESPRITE);
				}

				else
				{
					SetSpriteTile(Frogs[Loop].SpriteIndex, Frogs[Loop].Tile);
				}
			}

			if (0 == Frogs[Loop].Facing)
			{
				if (Frogs[Loop].x > SCREENLEFT)
				{
					Frogs[Loop].x--;
				}
			}

			else
			{
				if (Frogs[Loop].x < (SCREENRIGHT - 16))
				{
					Frogs[Loop].x++;
				}
			}

			Value	= HopWave[Frogs[Loop].JumpTime];

			UpdateFrog(Loop, Frogs[Loop].x, FROGY - Value);
		}
	}
}

void UpdateFlies()
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		if (TRUE == Flies[Loop].InWater)
		{
			Flies[Loop].JumpTime++;

			if (0 == Flies[Loop].Facing)
			{
				Flies[Loop].x--;

				if (SCREENLEFT == Flies[Loop].x)
				{
					RemoveFly(Loop);

					return;
				}
			}

			else
			{
				Flies[Loop].x++;

				if (SCREENRIGHT - 16 == Flies[Loop].x)
				{
					RemoveFly(Loop);

					return;
				}
			}

			if (Flies[Loop].y < FLYY - FLYRANGE)
			{
				Flies[Loop].y++;
			}

			else if (Flies[Loop].y > FLYY + FLYRANGE)
			{
				Flies[Loop].y--;
			}

			else
			{
				if (Random(2000) < 1000)
				{
					Flies[Loop].y--;
				}

				else
				{
					Flies[Loop].y++;
				}
			}

			SetSpritePosition(Flies[Loop].SpriteIndex, Flies[Loop].x, Flies[Loop].y);

			if (0 == ((Flies[Loop].JumpTime >> 2) & 1))
			{
				SetSpriteTile(Flies[Loop].SpriteIndex, SPRITE + FLYSPRITE);
			}

			else
			{
				SetSpriteTile(Flies[Loop].SpriteIndex, SPRITE + FLYSPRITE + FACESPRITE);
			}
		}
	}
}

void DrawScores()
{
	DWORD	Temp;
	DWORD	Value;

	Temp	= 1;
	DrawNumber(Temp, FONTPAL, SCORE1X, SCOREY - 2);
	DrawNumber(Score[0], FONTPAL, SCORE1X, SCOREY);

	Temp	= 2;
	DrawNumber(Temp, FONTPAL, SCORE2X, SCOREY - 2);
	DrawNumber(Score[1], FONTPAL, SCORE2X, SCOREY);

	DrawString("TIME  :  ", FONTPAL, TIMEX, TIMEY);

	Value	= Time / 60;

	Temp	= Value / 60;
	DrawNumber(Temp, FONTPAL, TIMEX + 5, TIMEY);

	Temp	= (Value % 60) / 10;
	DrawNumber(Temp, FONTPAL, TIMEX + 7, TIMEY);

	Temp	= (Value % 60) % 10;
	DrawNumber(Temp, FONTPAL, TIMEX + 8, TIMEY);
}

void MoveFrog(DWORD Frog)
{
	if (1 == Frogs[Frog].Facing)
	{
		if (Frogs[Frog].x < (SCREENRIGHT - 16))
		{
			Frogs[Frog].x++;

			CheckWater(Frog);
		}
	}

	else
	{
		if (Frogs[Frog].x > SCREENLEFT)
		{
			Frogs[Frog].x--;

			CheckWater(Frog);
		}
	}

	UpdateFrog(Frog, Frogs[Frog].x, Frogs[Frog].y);
}

void UpdateFrog(DWORD Frog, DWORD x, DWORD y)
{
	Frogs[Frog].x	= x;

	SetSpritePosition(Frogs[Frog].SpriteIndex, Frogs[Frog].x, y);

	if (TRUE == Frogs[Frog].InWater)
	{
		SetSpritePosition(Frogs[Frog].SplashIndex, Frogs[Frog].x - SPLASHX, y);
	}

	else if (TRUE == Frogs[Frog].Tonguing)
	{
		if (1 == Frogs[Frog].Facing)
		{
			SetSpritePosition(Frogs[Frog].TongueIndex, Frogs[Frog].x + TONGUEX, y);
		}

		else
		{
			SetSpritePosition(Frogs[Frog].TongueIndex, Frogs[Frog].x - TONGUEX, y);
		}
	}

	if (y == FROGY)
	{
		CheckWater(Frog);
	}

	if (TRUE == Frogs[Frog].Tonguing)
	{
		UpdateTongue(Frog);
	}
}

void UpdateTongue(DWORD Frog)
{
	DWORD	Value;

	Frogs[Frog].TongueTime++;

	if (LICKLENGTH * 2 == Frogs[Frog].TongueTime || FALSE == Frogs[Frog].Jumping)
	{
		Frogs[Frog].Tonguing	= FALSE;

		RemoveSprite(Frogs[Frog].TongueIndex);
	}

	else
	{
		Value	= TongueFrames[Frogs[Frog].TongueTime >> 1];

		if (1 == Frogs[Frog].Facing)
		{
			SetSpriteTile(Frogs[Frog].TongueIndex, FROGTILE + FACESPRITE + Value);
		}

		else
		{
			SetSpriteTile(Frogs[Frog].TongueIndex, FROGTILE + Value);
		}
	}
}

void CheckWater(DWORD Frog)
{
	if (FALSE == Frogs[Frog].InWater)
	{
		if (Frogs[Frog].x < LEFTEDGE || (Frogs[Frog].x > MIDDLELEFT && Frogs[Frog].x < MIDDLERIGHT)
			|| Frogs[Frog].x > RIGHTEDGE)
		{
			Frogs[Frog].InWater		= TRUE;
			Frogs[Frog].JumpTime	= 0;
			Frogs[Frog].Tile		+= SWIMSPRITE;

			if (1 == Frogs[Frog].Facing)
			{
				SetSpriteTile(Frogs[Frog].SpriteIndex, Frogs[Frog].Tile + FACESPRITE);
			}

			else
			{
				SetSpriteTile(Frogs[Frog].SpriteIndex, Frogs[Frog].Tile);
			}

			Frogs[Frog].SplashIndex	= AddSprite(Frogs[Frog].x - SPLASHX, Frogs[Frog].y,
				SPLASHWIDTH, 16, SPLASH, FROGPALETTE1);

			if (0 == Frog)
			{
				PlaySound(SND_WATER1);
			}

			else
			{
				PlaySound(SND_WATER2);
			}
		}
	}

	else
	{
		if ((Frogs[Frog].x >= LEFTEDGE && Frogs[Frog].x <= MIDDLELEFT) ||
			(Frogs[Frog].x >= MIDDLERIGHT && Frogs[Frog].x <= RIGHTEDGE))
		{
			Frogs[Frog].InWater	= FALSE;

			Frogs[Frog].Tile	-= SWIMSPRITE;

			if (1 == Frogs[Frog].Facing)
			{
				SetSpriteTile(Frogs[Frog].SpriteIndex, Frogs[Frog].Tile + FACESPRITE);
			}

			else
			{
				SetSpriteTile(Frogs[Frog].SpriteIndex, Frogs[Frog].Tile);
			}

			RemoveSprite(Frogs[Frog].SplashIndex);
		}
	}
}

void CheckTongue(DWORD Frog)
{
	DWORD	StartX;
	DWORD	EndX;
	DWORD	StartY;
	DWORD	EndY;
	DWORD	Loop;

	if (1 == Frogs[Frog].Facing)
	{
		StartX	= Frogs[Frog].x + TONGUEX;
		EndX	= StartX + TongueLength[Frogs[Frog].TongueTime >> 1];
	}

	else
	{
		EndX	= Frogs[Frog].x;
		StartX	= EndX - TongueLength[Frogs[Frog].TongueTime >> 1];
	}

	StartY	= Frogs[Frog].y - JumpWave[Frogs[Frog].JumpTime] + 2;
	EndY	= StartY + 5;

	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		if (TRUE == Flies[Loop].InWater)
		{
			DWORD	FlyStartX	= Flies[Loop].x;
			DWORD	FlyEndX		= FlyStartX + 16;
			DWORD	FlyStartY	= Flies[Loop].y;
			DWORD	FlyEndY		= FlyStartY + 16;

			if (((StartX >= FlyStartX && StartX <= FlyEndX) ||
				(EndX >= FlyStartX && EndX <= FlyEndX)))
			{
				if (((StartY >= FlyStartY && StartY <= FlyEndY) ||
					(EndY >= FlyStartY && EndY <= FlyEndY)))
				{
					RemoveFly(Loop);

					Score[Frog]	+= FLYSCORE;

					if (Score[Frog] > 99)
					{
						Score[Frog]	= 99;
					}


					if (0 == Frog)
					{
						PlaySound(SND_GRAB1);
					}

					else
					{
						PlaySound(SND_GRAB2);
					}

					return;
				}
			}
		}
	}
}

void ResetFrogs()
{
	Frogs[0].x				= FROG1X;
	Frogs[0].y				= FROGY;
	Frogs[0].Tile			= FROGTILE;
	Frogs[0].Facing			= 1;
	Frogs[0].InWater		= FALSE;
	Frogs[0].Tonguing		= FALSE;
	Frogs[0].Hopping		= FALSE;
	Frogs[0].Jumping		= FALSE;
	Frogs[0].JumpTime		= 0;
	Frogs[0].TongueTime		= 0;
	Frogs[0].State			= ST_SIT;

	Frogs[0].SpriteIndex	= AddSprite(Frogs[0].x, Frogs[0].y, 16, 16, FROGTILE + FACESPRITE, 
		FROGPALETTE1);

	Frogs[1].x				= FROG2X;
	Frogs[1].y				= FROGY;
	Frogs[1].Tile			= FROGTILE;
	Frogs[1].Facing			= 0;
	Frogs[1].InWater		= FALSE;
	Frogs[1].Tonguing		= FALSE;
	Frogs[1].Hopping		= FALSE;
	Frogs[1].Jumping		= FALSE;
	Frogs[1].JumpTime		= 0;
	Frogs[1].TongueTime		= 0;
	Frogs[1].State			= ST_SIT;

	Frogs[1].SpriteIndex	= AddSprite(Frogs[1].x, Frogs[1].y, 16, 16, FROGTILE, FROGPALETTE2);
}

void AddFly()
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		if (FALSE == Flies[Loop].InWater)
		{
			if (0 == FlySide)
			{
				Flies[Loop].x		= SCREENLEFT;
				Flies[Loop].Facing	= 1;
			}

			else
			{
				Flies[Loop].x		= SCREENRIGHT - 16;
				Flies[Loop].Facing	= 0;
			}

			Flies[Loop].y			= FLYY;
			Flies[Loop].Tile		= FROGTILE;
			Flies[Loop].InWater		= TRUE;
			Flies[Loop].Tonguing	= FALSE;
			Flies[Loop].Hopping		= FALSE;
			Flies[Loop].Jumping		= FALSE;
			Flies[Loop].JumpTime	= 0;
			Flies[Loop].TongueTime	= 0;

			Flies[Loop].SpriteIndex	= AddSprite(Flies[Loop].x, Flies[Loop].y, 16, 16,
				SPRITE + FLYSPRITE, FROGPALETTE1);

			FlySide	= (FlySide + 1) & 1;

			return;
		}
	}
}

void RemoveFly(DWORD Index)
{
	Flies[Index].InWater	= FALSE;

	RemoveSprite(Flies[Index].SpriteIndex);

	AddEvent(Random(10) + 10, EV_ADDFLY);
}

void ResetFlies()
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		Flies[Loop].InWater	= FALSE;
	}

	FlySide	= 0;

	AddEvent(Random(10) + 10, EV_ADDFLY);
	AddEvent(Random(10) + 40, EV_ADDFLY);
}

void ProcessEvents()
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXEVENTS; Loop++)
	{
		if (TRUE == Events[Loop].Used)
		{
			Events[Loop].Delay--;

			if (0 == Events[Loop].Delay)
			{
				switch (Events[Loop].Type)
				{
					case EV_ADDFLY:
						AddFly();

						break;
				}

				Events[Loop].Used	= FALSE;
			}
		}
	}
}

void AddEvent(DWORD Delay, DWORD Type)
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXEVENTS; Loop++)
	{
		if (FALSE == Events[Loop].Used)
		{
			Events[Loop].Delay	= Delay;
			Events[Loop].Type	= Type;
			Events[Loop].Used	= TRUE;

			return;
		}
	}
}

void ClearEvents()
{
	DWORD	Loop;

	for (Loop = 0; Loop < MAXEVENTS; Loop++)
	{
		Events[Loop].Used	= FALSE;
	}
}

DWORD HandleAI(DWORD Frog)
{
	DWORD	Input	= 0;

	switch (Frogs[Frog].State)
	{
		case ST_SIT:
			HandleSit(Frog, &Input);

			break;

		case ST_JUMP:
			HandleJump(Frog, &Input);

			break;

		case ST_CENTER:
			HandleCenter(Frog, &Input);

			break;

		case ST_SWIM:
			HandleSwim(Frog, &Input);

			break;

		case ST_TONGUE:
			HandleTongue(Frog, &Input);

			break;

		case ST_LAND:
			HandleLand(Frog, &Input);

			break;
	}

	return	Input;
}

void HandleSit(DWORD Frog, DWORD *Input)
{
	DWORD	Value;

	Value	= Random(100);

	if (TRUE == FlyInJumpRange(Frog))
	{
		*Input				= JOYA_A;
		Frogs[Frog].State	= ST_JUMP;
	}

	else if (80 == Value && LastAction != 1)
	{
		Frogs[Frog].State	= ST_CENTER;

		LastAction	= 1;
	}

	else if (30 == Value && LastAction < 2)
	{
		if ((Frogs[Frog].x > LEFTEDGE + 3 && Frogs[Frog].x < MIDDLELEFT + 3) ||
			(Frogs[Frog].x < RIGHTEDGE - 3 && Frogs[Frog].x > MIDDLERIGHT + 3))
		{
			*Input			= JOYA_LEFT;
		}

		LastAction	= 2;
	}

	else if (44 == Value && LastAction < 2)
	{
		if ((Frogs[Frog].x > LEFTEDGE + 3 && Frogs[Frog].x < MIDDLELEFT + 3) ||
			(Frogs[Frog].x < RIGHTEDGE - 3 && Frogs[Frog].x > MIDDLERIGHT + 3))
		{
			*Input			= JOYA_RIGHT;
		}

		LastAction	= 3;
	}

	else if (Value > 3 && Value < 5)
	{
		FaceCenter(Frog, Input);

		*Input				|= JOYA_A;
		Frogs[Frog].State	= ST_JUMP;

		LastAction	= 5;
	}

	else if (93 == Value)
	{
		LastAction	= 0;
	}
}

void HandleJump(DWORD Frog, DWORD *Input)
{
	DWORD	Loop;
	DWORD	StartY;

	if (FALSE == Frogs[Frog].Jumping)
	{
		Frogs[Frog].State	= ST_LAND;

		return;
	}

	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		if (TRUE == Flies[Loop].InWater)
		{
			if (Frogs[Frog].x - Flies[Loop].x <= TONGUERANGE ||
				Flies[Loop].x - Frogs[Frog].x <= TONGUERANGE)
			{
				StartY	= Frogs[Frog].y - JumpWave[Frogs[Frog].JumpTime] + 2;

				if (StartY - Flies[Loop].y <= HEIGHTRANGE ||
					Flies[Loop].y - StartY <= HEIGHTRANGE)
				{
					*Input				= JOYA_A;
					Frogs[Frog].State	= ST_TONGUE;

					break;
				}
			}
		}
	}
}

void HandleCenter(DWORD Frog, DWORD *Input)
{
	/* Return if in hopping motion */
	if (TRUE == Frogs[Frog].Hopping)
	{
		return;
	}

	/* Jump for fly if in range */
	else if (TRUE == FlyInJumpRange(Frog))
	{
		*Input				= JOYA_A;
		Frogs[Frog].State	= ST_JUMP;
	}

	/* Move toward center of pad */
	else if (0 == Frogs[Frog].Facing && Frogs[Frog].x < (SCREENRIGHT - SCREENLEFT) / 2 &&
		Frogs[Frog].x > LEFTEDGE + (MIDDLELEFT - LEFTEDGE) / 2)
	{
		*Input	= JOYA_LEFT;
	}

	else if (1 == Frogs[Frog].Facing && Frogs[Frog].x > (SCREENRIGHT - SCREENLEFT) / 2
		&& Frogs[Frog].x < MIDDLERIGHT + (RIGHTEDGE - MIDDLERIGHT) / 2)
	{
		*Input	= JOYA_RIGHT;
	}

	/* Return to sit state */
	else
	{
		CheckFacing(Frog, Input);

		Frogs[Frog].State	= ST_SIT;
	}
}

void HandleSwim(DWORD Frog, DWORD *Input)
{
	DWORD	Value;

	if (TRUE == Frogs[Frog].InWater)
	{
		SwimTowardsPad(Frog, Input);
	}

	else
	{
		Value	= Random(100);

		if (Value < 60)
		{
			Frogs[Frog].State	= ST_SIT;
		}

		else
		{
			Frogs[Frog].State	= ST_CENTER;
		}
	}
}

void HandleTongue(DWORD Frog, DWORD *Input)
{
	if (FALSE == Frogs[Frog].Tonguing)
	{
		if (TRUE == Frogs[Frog].Jumping)
		{
			Frogs[Frog].State	= ST_JUMP;
		}

		else
		{
			Frogs[Frog].State	= ST_LAND;
		}
	}
}

void HandleLand(DWORD Frog, DWORD *Input)
{
	/* Set swim state and move towards pad */
	if (TRUE == Frogs[Frog].InWater)
	{
		SwimTowardsPad(Frog, Input);

		Frogs[Frog].State	= ST_SWIM;
	}

	else
	{
		CheckFacing(Frog, Input);

		Frogs[Frog].State	= ST_SIT;
	}
}

BOOL FlyInJumpRange(DWORD Frog)
{
	DWORD	Loop;
	DWORD	Difference1;
	DWORD	Difference2;
	DWORD	Value;

	/* Check if in jumping range of fly (considering facing direction) */
	for (Loop = 0; Loop < MAXFLIES; Loop++)
	{
		if (TRUE == Flies[Loop].InWater)
		{
			if (Score[1] > Score[0])
			{
				Difference1	= Score[1] - Score[0];

				if (Difference1 < 3)
				{
					Value	= 2;
				}

				else
				{
					if (Difference1 > 6)
					{
						Difference1	=- 6;
					}

					Value		= Random(Difference1 + 2);
				}
			}

			else
			{
				Value		= 2;
			}

			Difference1	= Frogs[Frog].x - Flies[Loop].x;
			Difference2	= Flies[Loop].x - Frogs[Frog].x;

			if (0 == Frogs[Frog].Facing)
			{
				if (0 == Flies[Loop].Facing && Difference1 > JUMPAWAY &&
					Difference1 < JUMPAWAY + Value)
				{
					return	TRUE;
				}

				else if (1 == Flies[Loop].Facing && Difference1 > JUMPTOWARDS &&
					Difference1 < JUMPTOWARDS + Value)
				{
					return	TRUE;
				}
			}

			else
			{
				if (1 == Flies[Loop].Facing && Difference2 > JUMPAWAY && Difference2 <
					JUMPAWAY + Value)
				{
					return	TRUE;
				}

				else if (0 == Flies[Loop].Facing && Difference2 > JUMPTOWARDS &&
					Difference2 < JUMPTOWARDS + Value)
				{
					return	TRUE;
				}
			}
		}
	}

	return	FALSE;
}

void SwimTowardsPad(DWORD Frog, DWORD *Input)
{
	if (Frogs[Frog].x < LEFTEDGE)
	{
		*Input			= JOYA_RIGHT;
	}

	else if (Frogs[Frog].x > MIDDLELEFT && Frogs[Frog].x < MIDDLERIGHT)
	{
		if (Frogs[Frog].x < SCREENLEFT + (SCREENRIGHT - SCREENLEFT) / 2)
		{
			*Input		= JOYA_LEFT;
		}

		else
		{
			*Input		= JOYA_RIGHT;
		}
	}

	else if (Frogs[Frog].x > RIGHTEDGE)
	{
		*Input			= JOYA_LEFT;
	}
}

void CheckFacing(DWORD Frog, DWORD *Input)
{
	/* Turn around if needed */
	if (0 == Frogs[Frog].Facing && Frogs[Frog].x < SCREENLEFT +
		(SCREENRIGHT - SCREENLEFT) / 2 && Frogs[Frog].x < LEFTEDGE +
		(MIDDLELEFT - LEFTEDGE) / 2)
	{
		*Input				= JOYA_RIGHT;
	}

	else if (1 == Frogs[Frog].Facing && Frogs[Frog].x > SCREENLEFT +
		(SCREENRIGHT - SCREENLEFT) / 2 && Frogs[Frog].x > MIDDLERIGHT +
		(RIGHTEDGE - MIDDLERIGHT) / 2)
	{
		*Input				= JOYA_LEFT;
	}
}

void FaceCenter(DWORD Frog, DWORD *Input)
{
	/* Turn around if needed */
	if (0 == Frogs[Frog].Facing && Frogs[Frog].x < SCREENLEFT + (SCREENRIGHT - SCREENLEFT) / 2)
	{
		*Input				= JOYA_RIGHT;
	}

	else if (1 == Frogs[Frog].Facing && Frogs[Frog].x > SCREENLEFT +
		(SCREENRIGHT - SCREENLEFT) / 2)
	{
		*Input				= JOYA_LEFT;
	}
}
