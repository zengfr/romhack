#include "Defines.h"
#include "Main.h"
#include "Routines.h"
#include "Sprites.h"
#include "GamePlay.h"

extern WORD		Screen1Pal[];
extern WORD		TitlePal[];
extern WORD		BackPal[];
extern WORD		FontPal[];
extern WORD		SpritePal[];
extern WORD		Sprite2Pal[];
extern DWORD	Screen1Map[];
extern DWORD	TitleMap[];
extern DWORD	BackMap[];
extern DWORD	OldJoyVal1;
extern DWORD	OldJoyVal2;
extern DWORD	Players;

#define	BACKVRAM	0x900000	// Background VRAM location
#define	BACKPAL		0xA00800	// Background palette location
#define	TEXTPAL		0xA01000	// Text palette location
#define	SPRITEPAL	0xA00000	// Sprite palette location
#define	SCREENDELAY	(3 * 60)
#define	TITLE_SND	0xFF0674

int main()
{
	CopyData();

	ShowScreen1();

	Players	= 1;

	while (TRUE)
	{
		ClearSpriteList(MAXSPRITES);
		ClearText();

		ShowTitle();
		HideTitle();
		
		PlayGame();
	}

	return	0;
}

void CopyData()
{
	// Initialize sound
	InitSound();

	// Load text palette
	LoadPalette(FontPal, TEXTPAL, 0x10);

	// Load sprite palette
	LoadPalette(SpritePal, SPRITEPAL, 0x20);
}

void ShowScreen1()
{
	DWORD	Delay	= SCREENDELAY;
	DWORD	JoyVal1;
	DWORD	JoyVal2;

	WaitVBlank();

	// Load background tilemap
	LoadTilemap(Screen1Map, BACKVRAM, MAPWIDTH, MAPHEIGHT);
	
	// Load palette
	LoadPalette(Screen1Pal, BACKPAL, 0x20);

	while (TRUE)
	{
		WaitVBlank();

		Delay--;

		if (0 == Delay)
		{
			break;
		}

		JoyVal1	= ReadJoystickA();
		JoyVal2	= ReadJoystickB();
		
		if (JoyVal1	!= OldJoyVal1)
		{
			OldJoyVal1	= JoyVal1;
				
			if ((OldJoyVal1 & JOYA_A) != 0)
			{
				OldJoyVal2	= JoyVal2;

				break;
			}
		}

		if (JoyVal2	!= OldJoyVal2)
		{
			OldJoyVal2	= JoyVal2;
				
			if ((OldJoyVal2 & JOYA_A) != 0)
			{
				break;
			}
		}
	}
}

void ShowTitle()
{
	// Play audio track
	PlaySound(TITLE_SND);

	// Load title tilemap
	LoadTilemap(TitleMap, BACKVRAM, MAPWIDTH, MAPHEIGHT);

	// Load title palette
	LoadPalette(TitlePal, BACKPAL, 0x20);

	// Select players
	SelectPlayers();

	// Initialize sound
	InitSound();
}

void HideTitle()
{
	// Clear text screen
	ClearText();

	// Load background tilemap
	LoadTilemap(BackMap, BACKVRAM, MAPWIDTH, MAPHEIGHT);

	// Load background palette
	LoadPalette(BackPal, BACKPAL, 0x20);

}