// FM/ADPCM HEADER FILE created by MVSTracker

inline void send_sound_command(BYTE CommandNo)
{
	(*((PBYTE)0x320000)) = CommandNo;
}

// FM Music commands
#define SOUND_FM_OFF	(0xff)

// ADPCM Sample commands
#define SOUND_ADPCM_FROG	(0x04)
#define SOUND_ADPCM_TONGUE	(0x05)
#define SOUND_ADPCM_FLYGRAB	(0x06)
#define SOUND_ADPCM_WATER	(0x07)
#define SOUND_ADPCM_OFF	(0x7f)

