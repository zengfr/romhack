#ifndef __DEFINES_H
#define	__DEFINES_H

#define	JOYA_START	0x01
#define	JOYA_UP		0x02
#define	JOYA_DOWN	0x04
#define	JOYA_LEFT	0x08
#define	JOYA_RIGHT	0x10
#define	JOYA_A		0x20
#define	JOYA_B		0x40
#define	JOYA_C		0x80

#define	FALSE		0
#define	TRUE		1
#define	NULL		0

#define	BYTE		unsigned char
#define	WORD		unsigned short
#define	DWORD		unsigned int
#define	BOOL		unsigned int
#define	PBYTE		BYTE *

#define	MAXSPRITES	64			// Number of system sprites
#define	MAPWIDTH	14			// Map width
#define	MAPHEIGHT	7			// Map height

#define	SOUNDSIZE	0x5000		// Size of sound rom
#define	TABLESIZE	0x1278		// Size of sound table

#endif