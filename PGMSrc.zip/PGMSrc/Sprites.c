#include "Defines.h"
#include "Sprites.h"

struct	tagSpriteTable	Sprites[MAXSPRITES];
BOOL					SpritesChanged	= FALSE;

DWORD AddSprite(DWORD x, DWORD y, DWORD Width, DWORD Height, DWORD Tile, DWORD Palette)
{	
	long	Loop;

	for (Loop = MAXSPRITES - 1; Loop >= 0; Loop--)
	{
		if (FALSE == Sprites[Loop].Used)
		{
			break;
		}
	}

	if (Loop < 0)
	{
		return	0xFFFFFFFF;
	}

	Sprites[Loop].x			= x | 0x8000;
	Sprites[Loop].y			= y | 0x8000;
	Sprites[Loop].Palette	= Palette << 8;
	Sprites[Loop].Offset	= (Tile / 2);
	Sprites[Loop].Dimension	= (((Width / 16) << 9) | (Height));
	
	Sprites[Loop].Used		= TRUE;

	SpritesChanged			= TRUE;

	return	Loop;
}

void RemoveSprite(DWORD Sprite)
{
	Sprites[Sprite].Used	= FALSE;

	SpritesChanged			= TRUE;
}

void SetSpritePosition(DWORD Sprite, DWORD x, DWORD y)
{
	Sprites[Sprite].x	= x | 0x8000;
	Sprites[Sprite].y	= y | 0x8000;

	SpritesChanged		= TRUE;
}

void SetSpriteTile(DWORD Sprite, DWORD Tile)
{
	Sprites[Sprite].Offset	= (Tile / 2);

	SpritesChanged	= TRUE;
}

void ClearSpriteList(DWORD NumSprites)
{
	DWORD	Loop;

	for (Loop = 0; Loop < NumSprites; Loop++)
	{
		Sprites[Loop].Used	= FALSE;
	}
}
