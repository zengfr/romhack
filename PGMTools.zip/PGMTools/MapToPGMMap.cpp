//*****************************************************************
//* Mappy MAR to IGS PGM map converter.
//*****************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#ifndef TRUE
#define TRUE	1
#endif
#ifndef FALSE
#define FALSE	0
#endif

#define	TILEDIMENSION	8
#define MAXTILES		4096

char	FileIn[32];
char	FileOut[32];
DWORD	Offset			= 0;
DWORD	Length;
DWORD	Width;
DWORD	Height;
DWORD	MapWidth;
DWORD	MapHeight;
WORD	PaletteOverride	= 0xFFFF;
DWORD	BankIn[64 * 64];
DWORD	BankOut[64 * 64];

void Usage();
void ConvertMap();

void main(int argc, char *argv[])
{
	printf("Mappy Map to IGS PGM map converter.\n");

    if (argc < 6)
    {
        Usage();
    }

	if (7 == argc)
	{
		PaletteOverride	= (WORD)atol(argv[6]);
	}

	memset(BankIn, 0, sizeof(BankIn));
	memset(BankOut, 0, sizeof(BankOut));
    
	Offset		= atoi(argv[1]);
	MapWidth	= atoi(argv[2]);
	MapHeight	= atoi(argv[3]);

    strcpy(FileIn, argv[4]);
    strcpy(FileOut, argv[5]);

    if ("" == FileIn || "" == FileOut)
    {
        Usage();
    }

    FILE *handle = fopen(FileIn, "rb");

	if (handle != NULL)
    {
		fseek(handle, 0, SEEK_END);
        Length	= (ftell(handle) - 8) / 4;
		rewind(handle);

		if (Length > sizeof(BankIn) / 4)
		{
			Length = sizeof(BankIn) / 4;
		}

		// Skip width and height
		fseek(handle, 8, SEEK_SET);
        fread(BankIn, 4, Length, handle);
		fclose(handle);
    }

    ConvertMap();
}

void Usage()
{
    printf("Command syntax is: MapToPGMMap Offset MapWidth MapHeight Infile Outfile [Palette]\n");

    exit(1);
}

void ConvertMap()
{
	DWORD	Counter	= 0;

	for (DWORD OuterLoop = 0; OuterLoop < MapHeight; OuterLoop++)
	{
		for (DWORD InnerLoop = 0; InnerLoop < MapWidth; InnerLoop++)
		{
			DWORD Map	= BankIn[OuterLoop * MapWidth + InnerLoop] + Offset;

			BankOut[Counter]		= (DWORD)(((Map & 0xFF00) >> 8) | ((Map & 0xFF) << 8));
			BankOut[Counter]		|= PaletteOverride << 17;

			Counter++;
		}
	}
			
	FILE *handle = fopen(FileOut, "wb");

	if (NULL == handle)
	{
		return;
	}

	fwrite(BankOut, 4, MapWidth * MapHeight, handle);
	fclose(handle);
}
