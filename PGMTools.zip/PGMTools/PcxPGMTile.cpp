//*****************************************************************
//* PCX to IGS PGM tile converter. (Paletted)
//*****************************************************************

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include <math.h>

#define PAL_SIZE		32
#define TILEDIMENSION	32
#define	BANKSIZE		(4096 * 1024)

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef BYTE			BOOL;

#ifndef	TRUE
#define	TRUE	1
#endif
#ifndef	FALSE
#define	FALSE	0
#endif

DWORD	Width;
DWORD	Height;
char	FilePal[32];
BYTE	*Bank;
WORD	Palette[PAL_SIZE];
DWORD	Offset		= 0;
DWORD	Palettes	= 1;
BYTE	PcxBuffer[1024 * 1024];
BYTE	PcxPalette[768];

struct PCXHeader
{
	BYTE ID;
	BYTE Version;
	BYTE RLE;
	BYTE BPP;
	WORD StartX;
	WORD StartY;
	WORD EndX;
	WORD EndY;
	WORD HRes;
	WORD VRes;
	BYTE Palette[48];
	BYTE Reserved1;
	BYTE BitPlanes;
	WORD BytesPerLine;
	WORD PaletteType;
	WORD HSize;
	WORD VSize;
	BYTE Reserved2[54];
};

void Usage();
long Rip(char *Filename);
void ConvertTileToBuffer(BYTE *Tile, BYTE *Buffer);
void WriteTiles(char *Filename);
BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette);
void GetTile(BYTE *Tile, DWORD X, DWORD Y);

void main(int argc, char *argv[])
{
	printf("PCX to IGS PGM tile converter.\n");

	if (argc < 4)
	{
		Usage();
	}

	if (6 == argc)
	{
		Palettes	= (DWORD)atol(argv[5]);
	}

	memset(Palette, 0, PAL_SIZE * 2);
    
	Offset	= atol(argv[1]);

	Bank	= new BYTE[BANKSIZE];

	if (NULL == Bank)
	{
		printf("Unable to allocate memory.\n");
			
		return;
	}

	memset(Bank, 0, BANKSIZE);

	FILE	*Handle = fopen(argv[3], "rb");

	if (Handle != NULL)
	{
		fseek(Handle, 0, SEEK_END);

		DWORD	Length	= ftell(Handle);
		rewind(Handle);

		fread(Bank, 1, Length, Handle);
		fclose(Handle);
	}

	if (argc > 4)
	{
		strcpy(FilePal, argv[4]);

		if (strlen(FilePal) <= 0)
		{
			printf("Palette will not be saved.\n");
		}
	}

	else
	{
		memset(FilePal, 0, sizeof(FilePal));
	}

	if (-1 == Rip(argv[2]))
	{
		exit(1);
	}

	WriteTiles(argv[3]);

	printf("Next Offset = %d\n", Offset); 
}

void Usage()
{
	printf("Command syntax is: PcxPGMTile Offset Infile.pcx Outfile.bin [Palette] [Palettes]\n");

	exit(1);
}

long Rip(char *Filename)
{
	BYTE	*Buffer	= Bank + Offset;
	BYTE	Tile[TILEDIMENSION * TILEDIMENSION];

	LoadPCX(Filename, PcxBuffer, PcxPalette);

	if ((Width % TILEDIMENSION) != 0 && (Height % TILEDIMENSION) != 0)
	{
		printf("Picture must be a multiple of %d.\n", TILEDIMENSION);
        
		return	-1;
	}

	for (DWORD yloop = 0; yloop < (Height / TILEDIMENSION); yloop++)
	{
		for (DWORD xloop = 0; xloop < (Width / TILEDIMENSION); xloop++)
		{
			DWORD	x	= xloop * TILEDIMENSION;
			DWORD	y	= yloop * TILEDIMENSION;

			GetTile(Tile, x, y);

			for (DWORD TileY = 0; TileY < TILEDIMENSION; TileY++)
			{
				ConvertTileToBuffer(&Tile[TILEDIMENSION * TileY], Buffer);

				Buffer	+= 20;
				Offset	+= 20;
			}
		}
	}
    
	return	0;
}

void ConvertTileToBuffer(BYTE *Tile, BYTE *Buffer)
{
	DWORD	DestBit		= 0;
	DWORD	DestByte	= 0;

	memset(Buffer, 0, TILEDIMENSION * 5 / 8);

	for (DWORD Loop = 0; Loop < 32 * 5; Loop++)
	{	
		BYTE	SrcBit	= (BYTE)(Tile[Loop / 5] & (DWORD)pow(2, (Loop % 5)));
		
		SrcBit	>>= ((Loop % 5));

		Buffer[DestByte]	|= (SrcBit << DestBit);
	
		if (7 == DestBit)
		{
			DestByte++;

			DestBit	= 0;
		}

		else
		{
			DestBit++;
		}
	}
}

void WriteTiles(char *Filename)
{
	for (DWORD Loop = 0; Loop < PAL_SIZE; Loop++)
	{
		BYTE	Red    = ((PcxPalette[Loop * 3]) >> 1);
		BYTE	Green  = ((PcxPalette[Loop * 3 + 1]) >> 1);
		BYTE	Blue   = ((PcxPalette[Loop * 3 + 2]) >> 1);

		Red		&= 0x1F;
		Green	&= 0x1F;
		Blue	&= 0x1F;

		WORD	Value	= ((WORD)Blue << 0) | ((WORD)Green << 5) | ((WORD)Red << 10);
		Palette[Loop]	= ((Value & 0xFF) << 8) | ((Value & 0xFF00) >> 8);	
	}

	FILE	*Handle;

	if (strlen(FilePal) > 0)
	{
		Handle	= fopen(FilePal, "wb");

		if (NULL == Handle)
		{
			return;
		}
		
		fwrite(Palette, 2, (Palettes * PAL_SIZE * 2) / sizeof(WORD), Handle);
		fclose(Handle);
	}

	Handle	= fopen(Filename, "wb");

	if (NULL == Handle)
	{
		return;
	}

	fwrite(Bank, 1, BANKSIZE, Handle);
	fclose(Handle);
}

BOOL LoadPCX(char *File, BYTE *Buffer, BYTE *Palette)
{
	PCXHeader   PcxHeader;
	DWORD		Position;
	DWORD		Length;

	FILE	*Handle	= fopen(File, "rb");

	if (NULL == Handle)
	{
		printf("Unable to open %s.\n", File);

		return	FALSE;
	}

	Position	= ftell(Handle);
	fseek(Handle, 0, SEEK_END);
	Length		= ftell(Handle);
	rewind(Handle);

	fread(&PcxHeader, 1, sizeof(PcxHeader), Handle);

	if (PcxHeader.ID != 0x0A || PcxHeader.Version != 5 || PcxHeader.RLE != 1 
		|| (8 == PcxHeader.BPP && PcxHeader.BitPlanes != 1))
	{
		return	FALSE;
	}

	Width   = PcxHeader.EndX - PcxHeader.StartX + 1;
	Height  = PcxHeader.EndY - PcxHeader.StartY + 1;

	if (1 == PcxHeader.BPP && 4 == PcxHeader.BitPlanes)
	{
		 memset(Palette, 0, 768);

		for (DWORD loop = 0; loop < 48; loop++)
		{
			Palette[loop]	= PcxHeader.Palette[loop] >> 2;
		}
	}

	else if (8 == PcxHeader.BPP && 1 == PcxHeader.BitPlanes)
	{
		fseek(Handle, Position + Length - 768, SEEK_SET);

		for (DWORD loop = 0; loop < 768; loop++)
		{
			Palette[loop]	= ((BYTE)getc(Handle)) >> 2;
		}
	}

	else
	{
		return	FALSE;
	}

	fseek(Handle, Position + sizeof(PCXHeader), SEEK_SET);

	DWORD	TmpHeight	= Height;

	while (TmpHeight-- > 0)
	{
		BYTE	Pixel;
		BYTE	*Output;

		Output	= Buffer;

		memset(Buffer, 0, Width);

		for (DWORD Planes = 0; Planes < PcxHeader.BitPlanes; Planes++)
		{
			DWORD	Done	= 0;
			Buffer	= Output;

			do
			{
				Pixel	= (BYTE)getc(Handle);

				if ((Pixel & 0xC0) != 0xC0)
				{
					if (1 == PcxHeader.BPP)
					{
						for (DWORD Bits = 7; Bits >= 0; Bits--)
						{
							*Buffer++	|= ((Pixel >> Bits) & 1) << Planes;
						}

						Done	+= 8;
					}

					else
					{
						*Buffer++	= Pixel;
						Done++;
					}
				}

				else
				{
					BYTE	Run	= (BYTE)getc(Handle);
					Pixel	&= ~0xC0;

					while (Pixel > 0 && Done < Width)
					{
						if (1 == PcxHeader.BPP)
						{
							for (DWORD Bits = 7; Bits >= 0; Bits--)
							{
								*Buffer++	|= ((Run >> Bits) & 1) << Planes;
							}

							Done	+= 8;
						}

						else
						{
							*Buffer++	= Run;
							Done++;
						}

						Pixel--;
					}
				}
			}
			
			while (Done < Width);
		}
	}

	if (Handle != NULL)
	{
		fclose(Handle);
	}
	
	return	TRUE;
}

void GetTile(BYTE *Tile, DWORD X, DWORD Y)
{
	BYTE *Buffer	= PcxBuffer;

	Buffer += Y * Width + X;

	for (DWORD OuterLoop = 0; OuterLoop < TILEDIMENSION; OuterLoop++)
	{
		for (DWORD InnerLoop = 0; InnerLoop < TILEDIMENSION; InnerLoop++)
		{
			*Tile	= *Buffer;
			Tile++;
			Buffer++;
		}

		Buffer += Width - TILEDIMENSION;
	}
}
