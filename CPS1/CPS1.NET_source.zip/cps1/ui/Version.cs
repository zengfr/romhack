﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ui
{
    public class Version
    {
        public static string build_version = "CPS1.NET (build 20181227)";
        public static string author = "shunninghuang";
    }
}