﻿Detail: http://www.codeproject.com/Articles/998595/CPS-NET-a-Csharp-based-CPS-MAME-emulator
You should install Microsoft .NET Framework 3.5 or higher before running the program. You should download CPS1.NET ROM files in roms directory.
Hotkey: F3 -- soft reset, F7 -- load state, Shift+F7 -- save state, F8 -- replay input, Shift+F8 -- record input (start and stop), 0-9 and A-Z after state related hotkey -- handle certain files, F10 -- toggle global throttle, P -- pause and continue, shift+P -- skip a frame.
Control key: 1 -- P1 start, 2 -- P2 start, 5 -- P1 coin, 6 -- P2 coin, R -- Service 1, T -- Service, W -- P1 up, S -- P1 down, A -- P1 left, D -- P1 right, J -- P1 button1, K -- P1 button 2, L -- P1 button 3, U -- P1 button 4, I -- P1 button 5, O -- P1 button 6, Up -- P2 up, Down -- P2 down, Left -- P2 left, Right -- P2 right, NumPad1 -- P2 button 1, NumPad2 -- P2 button 2, NumPad3 -- P2 button 3, NumPad4 -- P2 button 4, NumPad5 -- P2 button 5, NumPad6 -- P2 button 6.
When the ROMs of a game are loaded, the emulator is auto paused. Press P to continue.
Occasionally GDI+ error occurs and a red cross is shown. You can click "File-Reset picturebox" to handle the error.
CPS1.NET ROM files: https://pan.baidu.com/s/1i5Il8Ct
vcmameUI and DirectX SDK: http://pan.baidu.com/s/1x5oAi
program reference: http://pan.baidu.com/s/1sj5ilFR
Email: shunninghuang@gmail.com
