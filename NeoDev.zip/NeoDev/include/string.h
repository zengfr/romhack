/* # $Id: string.h,v 1.1 2001/05/31 08:31:54 fma Exp $ */

#ifndef __STRING_H__
#define __STRING_H__

#include <stdlib.h>

#endif /* __STRING_H__ */
