To configure the environment to your machine you will need to edit
1 batchfile:

setmvs.bat (in the environment root directory)
----------
This file sets an environment variable to the root of the neo dev 
environment e.g. if you have unzipped this to d:\neodev then the
line should read
        set neodev=d:\neodev
It also puts the compiler binaries on the path, so again you need
to change the path to match where you have unzipped the dev
environment to plus \m68k\bin e.g. if you have unzipped this to
d:\neodev then the line should read
        path=d:\neodev\m68k\bin;%path%

