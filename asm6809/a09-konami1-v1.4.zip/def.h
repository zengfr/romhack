typedef unsigned char UINT8;
typedef unsigned short UINT16;
