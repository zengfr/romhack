#ifndef __SPRITE_H
#define	__SPRITE_H

typedef struct
{
	WORD	x;			// Sprite x position
	WORD	y;			// Sprite y position
	WORD	Tile;		// Sprite tile
	WORD	Attribute;	// Sprite attribute
	WORD	Used;		// Is this SpriteBlock used?
} tagSpriteBlock;

#endif
