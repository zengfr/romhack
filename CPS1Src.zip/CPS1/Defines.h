#ifndef __DEFINES_H
#define	__DEFINES_H

#define	JOYA_RIGHT	0x01
#define	JOYA_LEFT	0x02
#define	JOYA_DOWN	0x04
#define	JOYA_UP		0x08
#define	JOYA_A		0x10
#define	JOYA_B		0x20
#define	JOYA_START	0x40

#define	FALSE		0
#define	TRUE		1
#define	NULL		0

#define	BYTE		unsigned char
#define	WORD		unsigned short
#define	DWORD		unsigned int
#define	BOOL		unsigned int

#define	MAXSPRITES	8

#endif