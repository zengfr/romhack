#include "Defines.h"
#include "Main.h"
#include "Routines.h"
#include "GamePlay.h"

#define	MAPSIZE		3072
#define	PALSIZE		(16 * 2)
#define	TEXTVRAM	0x908000
#define	TITLEVRAM	0x90C000
#define	BACKVRAM	0x910000
#define	SPRITEPAL	0x914000
#define	TEXTPAL		0x914400
#define	TITLEPAL	0x914800
#define	BACKPAL		0x914C00
#define	SCREENDELAY	(3 * 60)

extern WORD		Screen1Pal[];
extern WORD		TitlePal[];
extern WORD		BackPal[];
extern WORD		FontPal[];
extern WORD		SpritePal[];
extern WORD		SpriteAltPal[];
extern WORD		Sprite2Pal[];
extern WORD		Screen1Map[];
extern WORD		TitleMap[];
extern WORD		BackMap[];
extern DWORD	OldJoyVal1;
extern DWORD	OldJoyVal2;
extern DWORD	Players;

int main()
{
	TurnOffScreen();

	CopyData();

	ShowScreen1();

	// Initialize sound
	InitSound();

	// DMA background map
	LoadVRAM(BackMap, BACKVRAM, MAPSIZE * 2);

	// Default players to 1
	Players	= 1;

	while (TRUE)
	{
		ClearSpriteList(MAXSPRITES);

		ShowTitle();
		HideTitle();

		PlayGame();
	}

	return	0;
}

void CopyData()
{
	// Set palettes
	LoadPalette(SpritePal, SPRITEPAL, PALSIZE);
	LoadPalette(Sprite2Pal, SPRITEPAL + PALSIZE, PALSIZE);
	LoadPalette(FontPal, TEXTPAL, PALSIZE);
	LoadPalette(TitlePal, TITLEPAL, PALSIZE);
	LoadPalette(Screen1Pal, BACKPAL, PALSIZE);
	LoadPalette(BackPal, BACKPAL + PALSIZE, PALSIZE);
}

void ShowScreen1()
{
	DWORD	Delay	= SCREENDELAY;
	DWORD	JoyVal1;
	DWORD	JoyVal2;

	// Clear front screen
	FillVRAM(TITLEVRAM, 0x0000, 64 * 64);

	// Clear text screen
	FillVRAM(TEXTVRAM, 0x0000, 64 * 64);

	// DMA screen 1 map
	LoadVRAM(Screen1Map, BACKVRAM, MAPSIZE * 2);

	TurnOnScreen();

	while (TRUE)
	{
		WaitVBlank();

		Delay--;

		if (0 == Delay)
		{
			break;
		}

		JoyVal1	= ReadJoystickA();
		JoyVal2	= ReadJoystickB();

		if (JoyVal1	!= OldJoyVal1)
		{
			OldJoyVal1	= JoyVal1;

			if ((OldJoyVal1 & JOYA_A) != 0)
			{
				OldJoyVal2	= JoyVal2;

				break;
			}
		}

		if (JoyVal2	!= OldJoyVal2)
		{
			OldJoyVal2	= JoyVal2;

			if ((OldJoyVal2 & JOYA_A) != 0)
			{
				break;
			}
		}
	}
}

void ShowTitle()
{
	WaitVBlank();
	TurnOffScreen();

	// DMA title map
	LoadVRAM(TitleMap, TITLEVRAM, MAPSIZE);

	TurnOnScreen();

	// Select players
	SelectPlayers();
}

void HideTitle()
{
	WaitVBlank();
	TurnOffScreen();

	// Clear front screen
	FillVRAM(TITLEVRAM, 0x00000000, 64 * 64);

	// Clear text screen
	FillVRAM(TEXTVRAM, 0x00000000, 64 * 64);

	TurnOnScreen();
}