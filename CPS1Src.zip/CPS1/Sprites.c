#include "Defines.h"
#include "Sprites.h"

tagSpriteBlock	SpriteBlock[MAXSPRITES];
BOOL			SpritesChanged	= FALSE;

DWORD AddSprite(DWORD x, DWORD y, DWORD Width, DWORD Height, DWORD Tile, DWORD Palette)
{
	DWORD	Loop;

	x	+= 64;
	y	+= 16;

	for (Loop = 0; Loop < MAXSPRITES; Loop++)
	{
		if (FALSE == SpriteBlock[Loop].Used)
		{
			break;
		}
	}

	if (Loop >= MAXSPRITES)
	{
		return	0xFFFFFFFF;
	}

	SpriteBlock[Loop].x			= x;
	SpriteBlock[Loop].y			= y;
	SpriteBlock[Loop].Tile		= Tile;
	SpriteBlock[Loop].Attribute	= Palette;
	SpriteBlock[Loop].Used		= TRUE;

	if (Width > 16)
	{
		SpriteBlock[Loop].Attribute	|= 1 << 8;
	}

	if (Height > 16)
	{
		SpriteBlock[Loop].Attribute	|= 1 << 12;
	}

	SpritesChanged			= TRUE;

	return	Loop;
}

void SetSpritePosition(DWORD Sprite, DWORD x, DWORD y)
{
	x	+= 64;
	y	+= 16;

	SpriteBlock[Sprite].x	= x;
	SpriteBlock[Sprite].y	= y;

	SpritesChanged			= TRUE;
}

void SetSpriteTile(DWORD Sprite, DWORD Tile)
{
	SpriteBlock[Sprite].Tile	= Tile;

	SpritesChanged				= TRUE;
}

void RemoveSprite(DWORD Sprite)
{
	SpriteBlock[Sprite].x		= 0xFFFF;
	SpriteBlock[Sprite].y		= 0xFFFF;
	SpriteBlock[Sprite].Used	= FALSE;

	SpritesChanged				= TRUE;
}

void ClearSpriteList(DWORD NumSprites)
{
	DWORD	Loop;

	for (Loop = 0; Loop < NumSprites; Loop++)
	{
		SpriteBlock[Loop].x			= 0xFFFF;
		SpriteBlock[Loop].y			= 0xFFFF;
		SpriteBlock[Loop].Used		= FALSE;
	}

	// Mark as last sprite in the list
	SpriteBlock[Loop].Attribute	= 0xFF00;
	
	SpritesChanged				= TRUE;
}
