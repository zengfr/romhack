#ifndef __GAMEDEFINES_H
#define	__GAMEDEFINES_H

// Sprite frames
#define	SPRITE			624
#define	SPLASH			640
#define	FROGTILE		SPRITE
#define	FROGPALETTE1	0
#define	FROGPALETTE2	1
#define	BACKGROUNDCOLOR	(4 * 2)

// Position offsets
#define	FROG1X			(82 + 32)
#define	FROG2X			(222 + 32)
#define	SPLASHWIDTH		24

// Screen defines
#define	SCREENLEFT		0
#define	SCREENRIGHT		384
#define	LEFTEDGE		(18 + 32)
#define RIGHTEDGE		(278 + 32)
#define	MIDDLELEFT		(118 + 32)
#define	MIDDLERIGHT		(184 + 32)

// Sprite offsets
#define	SWIMSPRITE		7
#define	FACESPRITE		8
#define	JUMPSPRITE		1
#define	FLYSPRITE		6

// Score defines
#define	SCOREY			25
#define	SCORE1X			(4 + 4)
#define	SCORE2X			(35 + 4)
#define	FONTPAL			0
#define	TIMEX			(16 + 4)
#define	TIMEY			SCOREY + 1
#define	STARTX			(15 + 4)
#define	STARTY			20
#define	STARTSPRY		20
#define	GAMEOVERX		(15 + 4)
#define	GAMEOVERY		12
#define	PLAYER1X		(112 + 32)
#define	PLAYER2X		(192 + 32)
#define	PLAYERY			((GAMEOVERY + 4) * 8)
#define	ENDSCORE1X		(15 + 4)
#define	ENDSCORE2X		(25 + 4)
#define	ENDSCOREY		GAMEOVERY + 7
#define	TIEX			(16 + 4)

// Sound defines
#define	SND_FROG1		0		// Frog sound
#define	SND_TONGUE1		1		// Tongue sound
#define	SND_GRAB1		2		// Grab sound
#define	SND_WATER1		3		// Water sound
#define	SND_FROG2		0		// Frog sound
#define	SND_TONGUE2		1		// Tongue sound
#define	SND_GRAB2		2		// Grab sound
#define	SND_WATER2		3		// Water sound

// Animation frames
const DWORD TongueFrames[LICKLENGTH]	=
{
	2, 3, 4, 5, 5, 4, 3, 2
};

const DWORD SkyBlue[SKYLENGTH]	=
{
	8, 9, 11, 13, 11, 9, 8
};

const DWORD SkyGreen[SKYLENGTH]	=
{
	6, 7, 8, 10, 8, 7, 6
};

#endif