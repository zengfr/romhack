#include "Defines.h"
#include "Main.h"
#include "Routines.h"
#include "Sprites.h"
#include "..\Common\Game.h"

extern WORD		Screen1Pal[];
extern WORD		TitlePal[];
extern WORD		TitlePal[];
extern WORD		BackPal[];
extern WORD		FontPal[];
extern WORD		SpritePal[];
extern WORD		Sprite2Pal[];
extern WORD		Screen1Map[];
extern WORD		TitleMap[];
extern WORD		BackMap[];
extern DWORD	OldJoyVal1;
extern DWORD	OldJoyVal2;
extern DWORD	Players;

#define	TITLEVRAM	0x0902		// Title VRAM location
#define	BACKVRAM	0x0402		// Background VRAM location
#define	SCREENDELAY	(3 * 60)

int main()
{
	CopyData();

	ShowScreen1();

	// Load background tilemap
	LoadTilemap(BackMap, BACKVRAM, MAPWIDTH, MAPHEIGHT, SPRITETILE1);
	
	Players	= 1;

	while (TRUE)
	{
		ClearSpriteList(MAXSPRITES);
		ClearText();

		ShowTitle();
		HideTitle();
		
		PlayGame();
	}

	return	0;
}

void CopyData()
{
	// Setup background tilemap
	SetupTilemap(TILEY1, SPRITETILE1);

	LoadPalette(BackPal, 0x400020, 0x20);
	LoadPalette(FontPal, 0x400040, 0x20);
	LoadPalette(SpritePal, 0x400060, 0x20);
	LoadPalette(Sprite2Pal, 0x400080, 0x20);

	// Initialize sound
	InitSound();
}

void ShowScreen1()
{
	DWORD	Delay	= SCREENDELAY;
	DWORD	JoyVal1;
	DWORD	JoyVal2;

	WaitVBlank();

	// Load background tilemap
	LoadTilemap(Screen1Map, BACKVRAM, MAPWIDTH, MAPHEIGHT, SPRITETILE1);
	
	// Set palettes
	LoadPalette(Screen1Pal, 0x400000, 0x20);

	while (TRUE)
	{
		WaitVBlank();

		Delay--;

		if (0 == Delay)
		{
			break;
		}

		JoyVal1	= ReadJoystickA();
		JoyVal2	= ReadJoystickB();
		
		if (JoyVal1	!= OldJoyVal1)
		{
			OldJoyVal1	= JoyVal1;
				
			if ((OldJoyVal1 & JOYA_A) != 0)
			{
				OldJoyVal2	= JoyVal2;

				break;
			}
		}

		if (JoyVal2	!= OldJoyVal2)
		{
			OldJoyVal2	= JoyVal2;
				
			if ((OldJoyVal2 & JOYA_A) != 0)
			{
				break;
			}
		}
	}
}

void ShowTitle()
{
	// Stop audio
	StopAudio();

	// Play title music
	PlayAudio(0);

	// Set palettes
	LoadPalette(TitlePal, 0x400000, 0x20);

	// Setup title tilemap
	SetupTilemap(TILEY2, SPRITETILE2);

	// Load title tilemap
	LoadTilemap(TitleMap, TITLEVRAM, MAPWIDTH, MAPHEIGHT, SPRITETILE2);

	// Select players
	SelectPlayers();
}

void HideTitle()
{
	// Stop audio
	StopAudio();

	// Play background audio
	PlayAudio(1);

	// Clear text screen
	ClearText();
	
	// Clear title tile map
	FillTilemap(TITLEVRAM, MAPWIDTH, MAPHEIGHT, SPRITETILE2);
}