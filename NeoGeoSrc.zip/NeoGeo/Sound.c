#include "Defines.h"
#include "Routines.h"
#include "Sound.h"

void InitSound()
{
	send_sound_command(3);
}

void PlaySound(DWORD SoundID)
{	
	send_sound_command(SoundID + SOUND_ADPCM_FROG);
	send_sound_command(SOUND_ADPCM_OFF);
}

void PlayAudio(DWORD Track)
{
	send_sound_command(Track + SOUND_ADPCM_PT_5182);
	send_sound_command(SOUND_ADPCM_OFF);
}

void StopAudio()
{
}