#ifndef __ROUTINES_H
#define	__ROUTINES_H

extern void LoadPalette(WORD *Source, DWORD Dest, DWORD Length);
  // Load palette data

extern void SetupTilemap(DWORD y, DWORD Tile);
  // Setup tilemap

extern void LoadTilemap(WORD *Source, DWORD Dest, DWORD Width, DWORD Height, DWORD Tile);
  // Load tilemap

extern void FillTilemap(DWORD Dest, DWORD Width, DWORD Height, DWORD Tile);
  // Fill tilemap

extern void ClearText();
  // Clear text

extern DWORD ReadJoystickA();
  // Read joystick A

extern DWORD ReadJoystickB();
  // Read joystick B

extern void WaitVBlank();
  // Wait VBlank

extern DWORD AddSprite(DWORD x, DWORD y, DWORD Width, DWORD Height, DWORD Tile, DWORD Palette);
  // Add sprite

extern void RemoveSprite(DWORD Sprite);
  // Remove sprite

extern void SetSpritePosition(DWORD Sprite, DWORD x, DWORD y);
  // Set sprite position

extern void SetSpriteTile(DWORD Sprite, DWORD Tile);
  // Set sprite tile

extern void ClearSpriteList(DWORD NumSprites);
  // Clear sprite list 

extern void SetPaletteRed(DWORD Dest, DWORD Red);
  // Set palette red

extern void SetPaletteGreen(DWORD Dest, DWORD Green);
  // Set palette green

extern void SetPaletteBlue(DWORD Dest, DWORD Blue);
  // Set pallete blue

extern void DrawNumber(DWORD Value, DWORD Palette, DWORD x, DWORD y);
  // Draw number

extern void DrawString(char *String, DWORD Palette, DWORD x, DWORD y);
  // Draw string

extern void PlayAudio(DWORD Track);
  // Play audio

extern void StopAudio();
  // Stop audio

extern void InitSound();
  // Init sound

extern void PlaySound(DWORD SoundID);
  // Play sound

extern DWORD Random(DWORD Limit);
  // Get a random number

#endif
