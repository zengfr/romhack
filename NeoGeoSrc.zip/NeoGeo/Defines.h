#ifndef __DEFINES_H
#define	__DEFINES_H

#define	JOYA_UP		0x001
#define	JOYA_DOWN	0x002
#define	JOYA_LEFT	0x004
#define	JOYA_RIGHT	0x008
#define	JOYA_A		0x010
#define	JOYA_B		0x020
#define	JOYA_C		0x040
#define	JOYA_D		0x080
#define	JOYA_START	0x100
#define	JOYA_SELECT	0x200

#define	FALSE		0
#define	TRUE		1
#define	NULL		0

#define	BYTE		unsigned char
#define	WORD		unsigned short
#define	DWORD		unsigned int
#define	BOOL		unsigned int
#define	PBYTE		BYTE *

#define	TILEY1		0x000F		// Starting Y position to use for the tilemap. Normally $F80E
#define	TILEY2		0x000F		// Starting Y position to use for the tilemap. Normally $F80E
#define	SPRITETILE1	0x8010		// Starting sprite to use for the first tilemap
#define	SPRITETILE2	0x8024		// Starting sprite to use for the second tilemap
#define	SPRITESPR	0x8038		// Starting sprite to use for the sprites
#define	MAXSPRITES	64			// Number of system sprites
#define	MAPWIDTH	19			// Map width
#define	MAPHEIGHT	14			// Map height

#endif