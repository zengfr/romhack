#include "Defines.h"
#include "..\Common\Game.h"
#include "GameDefs.h"
#include "Routines.h"

#include "..\Common\Game.c"