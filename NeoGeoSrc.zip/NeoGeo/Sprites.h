#ifndef __SPRITES_H
#define	__SPRITES_H

#define	SPRITEWORDS		64
#define	FULLZOOM		0x0FFF	

struct tagSpriteControl
{
	WORD	Used;		// Is this Sprite control used?
	WORD	Zoom;		// Sprite zoom
	WORD	y;			// Sprite y position (<< 7) and sprites in bank
	WORD	x;			// Sprite x position (<< 7)
};

struct tagSpriteBlock
{
	WORD	Tile;		// Tile number for this sprite
	WORD	Palette;	// Palette number and attribute
						// Sprite attribute
						// Bit 0: X flip
						// Bit 1: Y flip
						// Bit 2-7 not used in library
};

#endif
