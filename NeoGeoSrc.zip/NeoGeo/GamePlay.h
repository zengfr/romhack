#ifndef __GAMEPLAY_H
#define	__GAMEPLAY_H

/* Position offsets */
#define	SPLASHX		4
#define	TONGUEX		16
#define	FROGY		140
#define	FLYY		60
#define	FLYRANGE	20

/* Animation lengths */
#define	LICKLENGTH	8
#define	JUMPLENGTH	160
#define	HOPLENGTH	8
#define	SKYLENGTH	7

/* Game defines */
#define	MAXFLIES	6
#define	FLYSCORE	2
#define	GAMETIME	(1.5 * 60 * 60)
#define	ENDDELAY	(10 * 60)

/* Event defines */
#define	MAXEVENTS	8

#define	EV_NONE		0		/* No event */
#define	EV_ADDFLY	1		/* Add fly */

struct tagSprite
{
	DWORD	x;				/* X position */
	DWORD	y;				/* Y position */
	DWORD	Tile;			/* Starting tile number */
	DWORD	SpriteIndex;	/* Sprite index */
	DWORD	SplashIndex;	/* Splash index */
	DWORD	TongueIndex;	/* Tongue index */
	DWORD	Facing;			/* Facing direction */
	BOOL	InWater;		/* In water */
	BOOL	Tonguing;		/* Tonguing? */
	BOOL	Hopping;		/* Hopping? */
	BOOL	Jumping;		/* Jumping? */
	DWORD	JumpTime;		/* Time since start of jump */
	DWORD	TongueTime;		/* Time since start of tongue */
	DWORD	State;			/* Frog state, only used for AI */
};

struct tagGameEvent
{
	DWORD	Delay;			/* Delay until event kicks off */
	DWORD	Type;			/* Type of event */
	BOOL	Used;			/* Is this event used ? */
};

/* States */
#define	ST_SIT		0x00000000	/* Siting */
#define	ST_JUMP		0x00000001	/* Jumping */
#define	ST_CENTER	0x00000002	/* Hopping toward center */
#define	ST_SWIM		0x00000003	/* Swimming */
#define	ST_TONGUE	0x00000004	/* Licking at fly */
#define	ST_LAND		0x00000005	/* Landed */

/* AI Vaiables */
#define	JUMPTOWARDS	32			/* Fly jump range */
#define	JUMPAWAY	42			/* Fly jump range */
#define	TONGUERANGE	24			/* Fly tongue range */
#define	HEIGHTRANGE	16			/* Fly height range */

void SelectPlayers();
  /* Select players */

void PlayGame();  
  /* Play game */

DWORD GameLoop();
  /* Game loop */

void ShowGameOver();
  /* Show game over */

void CheckFlies();
  /* Check flies */

void HandleInput();
  /* Handle input */

void UpdateFrogs();
  /* Update frogs */

void UpdateFlies();
  /* Update flies */

void DrawScores();
  /* Draw scores */

void MoveFrog(DWORD Frog);
  /* Move frog */

void UpdateFrog(DWORD Frog, DWORD x, DWORD y);
  /* Update frog */

void UpdateTongue(DWORD Frog);
  /* Update tongue */

void CheckWater(DWORD Frog);
  /* Check water */

void CheckTongue(DWORD Frog);
  /* Check tongue */

void ResetFrogs();
  /* Reset frogs */

void AddFly();
  /* Add fly */

void RemoveFly(DWORD Index);
  /* Remove fly */

void ResetFlies();
  /* Reset flies */

void ProcessEvents();
  /* Process events */

void AddEvent(DWORD Delay, DWORD Type);
  /* Add event */

void ClearEvents();
  /* Clear events */

DWORD HandleAI(DWORD Frog);
  /* Handle AI */

void HandleSit(DWORD Frog, DWORD *Input);
  /* Handle sit */

void HandleJump(DWORD Frog, DWORD *Input);
  /* Handle jump */

void HandleCenter(DWORD Frog, DWORD *Input);
  /* Handle center */

void HandleSwim(DWORD Frog, DWORD *Input);
  /* Handle swim */

void HandleTongue(DWORD Frog, DWORD *Input);
  /* Handle tongue */

void HandleLand(DWORD Frog, DWORD *Input);
  /* Handle land */

BOOL FlyInJumpRange(DWORD Frog);
  /* Is fly within JUMPRANGE? */

void SwimTowardsPad(DWORD Frog, DWORD *Input);
  /* Swim towards pad */

void CheckFacing(DWORD Frog, DWORD *Input);
 /* Check facing */

void FaceCenter(DWORD Frog, DWORD *Input);
 /* Face center */

#endif
