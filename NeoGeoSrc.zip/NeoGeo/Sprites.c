#include "Defines.h"
#include "Sprites.h"

struct	tagSpriteControl	SpriteControl[MAXSPRITES];
struct	tagSpriteBlock		SpriteBlock[MAXSPRITES];
BOOL						SpritesChanged	= FALSE;

DWORD AddSprite(DWORD x, DWORD y, DWORD Width, DWORD Height, DWORD Tile, DWORD Palette)
{	
	long	Loop;

	if (32 == Width)
	{
		for (Loop = MAXSPRITES - 2; Loop >= 0; Loop -= 2)
		{
			if (FALSE == SpriteControl[Loop].Used && FALSE == SpriteControl[Loop + 1].Used)
			{
				break;
			}
		}
	}

	else
	{
		for (Loop = MAXSPRITES - 1; Loop >= 0; Loop--)
		{
			if (FALSE == SpriteControl[Loop].Used)
			{
				break;
			}
		}
	}

	if (Loop < 0)
	{
		return	0xFFFFFFFF;
	}

	SpriteControl[Loop].Zoom	= FULLZOOM;
	SpriteControl[Loop].y		= ((496 - y) << 7) | (Height >> 4);
	SpriteControl[Loop].x		= (x << 7);
	SpriteControl[Loop].Used	= TRUE;

	if (32 == Width)
	{
		// Mark as attached sprites
		SpriteControl[Loop].Used		|= 0x8000;
		
		// Attach sprite
		SpriteControl[Loop + 1].Zoom	= FULLZOOM;
		SpriteControl[Loop + 1].y		= 0x40;
		SpriteControl[Loop + 1].Used	= TRUE;
	}

	SpriteBlock[Loop].Tile		= Tile;
	SpriteBlock[Loop].Palette	= (Palette << 8);

	if (32 == Width)
	{
		SpriteBlock[Loop + 1].Tile		= Tile + 1;
		SpriteBlock[Loop + 1].Palette	= (Palette << 8);
	}

	SpritesChanged	= TRUE;

	return	Loop;
}

void RemoveSprite(DWORD Sprite)
{
	if ((SpriteControl[Sprite].Used & 0x8000) != 0)
	{
		SpriteControl[Sprite + 1].Used	= FALSE;
	}

	SpriteControl[Sprite].Used	= FALSE;

	SpritesChanged	= TRUE;
}

void SetSpritePosition(DWORD Sprite, DWORD x, DWORD y)
{
	SpriteControl[Sprite].x	= (x << 7);
	SpriteControl[Sprite].y	= ((496 - y) << 7) | (SpriteControl[Sprite].y & 0x7F);

	SpritesChanged	= TRUE;
}

void SetSpriteTile(DWORD Sprite, DWORD Tile)
{
	SpriteBlock[Sprite].Tile	= Tile;

	if ((SpriteControl[Sprite].Used & 0x8000) != 0)
	{
		SpriteBlock[Sprite + 1].Tile	= Tile + 1;
	}

	SpritesChanged	= TRUE;
}

void ClearSpriteList(DWORD NumSprites)
{
	DWORD	Loop;

	for (Loop = 0; Loop < NumSprites; Loop++)
	{
		SpriteControl[Loop].Used	= FALSE;
	}
}

