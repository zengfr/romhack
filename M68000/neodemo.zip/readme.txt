Simple NeoGeo demo by Charles Doty (cdoty@netzero.net)

This is, as far as I can tell, a fully functioning NeoGeo rom. It works under
MAME and NeoRageX(6b). It's a simple demo, but includes all the information
to write a full game (minus sound).

Included in this archive is the demo, source, and tools used to create the
program.

To view the demo, copy the PUZZLEDP.ZIP to the ROMS directory under mame, and
type 'MAME PUZZLEDP'. It also works under NeoRage(X) as an unidentified rom.

You will also need to get the following if you want to recompile the demo:
SGCC (http://www.classicgaming.com/epr/genesis.htm)
    ld.exe needs to be renamed segald.exe to work with the .bat files, and is
    the only file needed.

modified JAS assembler (http://arcadedev.vintagegaming.com)

Maccer (http://www.earthling.net.nz/~michaelh/old/)

Thanks to:
            The MAMEDEV Team (Specifically the NeoGeo crew)
                - The source code provided a lot of information about 
                  the NeoGeo, and the debugger is invaluable.

            Scott "Jerry" Lawrence  (Created Turaco)
            Ivan Mackintosh            
                - Invaluable in figuring out the format of the graphic and
                  fix roms..


A site dedicated to arcade system development is available at 
http://arcadedev.vintagegaming.com.

