Simple Taito F2 demo by Charles Doty (cdoty@netzero.net)

Included in this archive is the demo, source, and tools used to create the 
demo. 

To view the demo, copy the LIQUIDK.ZIP to the ROMS directory under mame, and
type 'MAME LIQUIDK'. This demo also runs under Raine, but there is some
problems with the sprite, and the X Scroll Offset is different.

You will also need to get the following if you want to recompile the demo:
SGCC (http://www.classicgaming.com/epr/genesis.htm)
    ld.exe needs to be renamed segald.exe to work with the .bat files, and is
    the only file needed.

modified JAS assembler (http://arcadedev.vintagegaming.com)	

Maccer (http://www.earthling.net.nz/~michaelh/old/)

Thanks to:
    The MAMEDEV Team (Specifically the Taito F2 crew)
        - The source code provided a lot of information about 
          Taito F2, and the debugger is invaluable.

    Scott "Jerry" Lawrence  (Created Turaco)
    Ivan Mackintosh
        - Invaluable in figuring out the format of the graphic roms.

A site dedicated to arcade system development is available at 
http://arcadedev.vintagegaming.com.
