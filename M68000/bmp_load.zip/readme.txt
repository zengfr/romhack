
 This programme is copyright Lee Davison and free for educational or personal use only.
 For commercial use please contact me at leeedavison@googlemail.com for conditions.

 For more information on this program and other projects please visit my site at ..

	 http://mycorner.no-ip.org/index.html

