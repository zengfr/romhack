Simple Capcom System 1 demo by Charles Doty (cdoty@netzero.net)

Included in this archive is the demo, source, and tools used to create the 
demo. 

To view the demo, copy the FFIGHT.ZIP to the ROMS directory under mame, and
type 'MAME FFIGHT'. This demo also runs under Callus, with the exception of
the first tile fo the sprite is missing. I'm not sure if this is a code
or emulation error.

You will also need to get the following if you want to recompile the demo:
SGCC (http://www.classicgaming.com/epr/genesis.htm)
    ld.exe needs to be renamed segald.exe to work with the .bat files, and is
    the only file needed.

modified JAS assembler (http://arcadedev.vintagegaming.com)	

Maccer (http://www.earthling.net.nz/~michaelh/old/)

Thanks to:
            Paul Leaman  (Wrote CPS-1 driver for MAME)
                - Sent an informative e-mail about the CPS-1 System..

            The MAMEDEV Team (Specifically the CPS-1 crew)
                - The source code provided a lot of information about the
                  CPS-1 system, and the debugger is invaluable.

            Scott "Jerry" Lawrence  (Created Turaco)
            Ivan Mackintosh
                - Invaluable in figuring out the format of the graphic roms.


A site dedicated to arcade system development is available at 
http://arcadedev.vintagegaming.com.


