﻿街机dino恐龙快打.框架版1V3(美版hack)
Cadillacs and Dinosaurs (Framework 2021 1V3 Edition 2021-04-03)(hacked by zengfr)

copy压缩包roms文件夹的zip格式rom文件dinou.zip,到你安装的模拟器的roms文件夹中,重启模拟器即可。（有些模拟器需忽略文件crc校验才能正常加载）
试玩下载地址:https://zengfr.gitee.io/home/emu/dinofr.html
2:https://gitee.com/zengfr/romhack/tree/master/hackrom
下载地址3:https://github.com/zengfr/romhack/tree/master/hackrom
游戏介绍:(hacked by zengfr)
dino恐龙快打框架版1V3(美版hack)(dinou.zip)
游戏特点:原版风,1V3
dino框架版1V3，是框架版2020大改版的回归,美版最精简改动,保持原版风,1V3,个别模式加强,版本适合竞赛练习竞技直播。
1、美版原版1V3,F2菜单最大难度0703开启demo sound,保持原版风,无其他额外修改.
2、只3P时=mode0,保持原版风1V3，2P时=mode1,关底+1boss，1P时=mode3,关底+1boss+场景精英兵复制。
3、场景上方屏幕显示3P暴击数值、场景值、卷轴值、拳击计数、血量值。
4、按投币键8个币过关,方便练习跳关.
5、引入打击伤害统计显示系统,方便专业玩家精算打击伤害.
6、试玩视频录像:https://space.bilibili.com/492484080/video