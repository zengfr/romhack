This directory contains the files to generate the documentation SQL files. Some of them are in the https://github.com/nologic/x86doc project.
