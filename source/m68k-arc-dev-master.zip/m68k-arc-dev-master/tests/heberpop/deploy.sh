#!/bin/sh
cp test1.ic31 ../../../mame/roms/heberpop/hbp_ic31.ic31
cp test1.ic32 ../../../mame/roms/heberpop/hbp_ic32.ic32
