
This program converts mame's cps2.c (driver) and cps2crpt.c (machine) to a format 
that is useable by the cps2dec program (cps2.dat).

***************************************************************
*  License

This program is licensed under the WTFPL license (http://sam.zoy.org/wtfpl/) 


