#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#define WRITE_MASK
#define LOG

// main.cpp
extern int error;
extern unsigned char *mem;

// file.cpp
extern int nLen;
extern char setname[2][32];
extern char romname[2][16][32];
extern unsigned int crcstore[2][16];
extern unsigned int romsize[2][16];
extern unsigned int keystore[2][2];
extern unsigned int uppr;
void parse_dat();

extern void do_read(unsigned char *dst);
void do_write (unsigned char *dst);

// cps2crypt.cpp
extern int dLen;
void decrypt(int game, unsigned char *src);

// mask.cpp
void mask(unsigned char *src);

// macros

// check for errors and exit cleanly if they're found
#define error_stop() \
	if (error) { \
		printf ("Press enter to exit.\n"); \
		getchar(); \
		if (mem) free (mem); \
		return 0; \
	} \

