#include "shared.h"

int error = 0;
unsigned char *mem;

int main()
{
	parse_dat();					// get info for set 1
	error_stop();

	parse_dat();					// get info for set 2
	error_stop();

	mem = (unsigned char*)calloc( nLen * 5, 1 );	// allocate and zero all ram
	if (mem == NULL) {
		printf ("Not enough ram!\n");
		error = 1;
		error_stop();
	}

	do_read(mem);					// read files
	error_stop();

	decrypt(0, mem + (nLen * 0));			// decrypt set 1
	error_stop();

	decrypt(1, mem + (nLen * 1));			// decrypt set 2
	error_stop();

	mask(mem);					// create and apply mask
	error_stop();

	do_write (mem + (nLen * 2));			// write files
	error_stop();

	free (mem);

	printf ("Please do not report any problems/questions regarding these\n");
	printf ("roms to anyone except IQ_132 (http://neosource.1emu.net)\n");

	error = 1;					// re-use error exit message for exit
	error_stop();
}
